import React from 'react';
import { Search, X } from 'lucide-react';
import '../styles/CandidateFilterSidebar.css';

const CandidateFilterSidebar = ({
  totalCount,
  overallTotal,
  filters,
  setFilters,
  onClearAll,
  availableLocations = [],
  availableStatuses = [],
  availableWorkTypes = [],
  availableSources = [],
  availableEmploymentTypes = [],
  availableIndustries = [],
  availableGenders = [],
  onClose
}) => {
  
  const handleCheckboxChange = (category, value) => {
    const current = filters[category] || [];
    const updated = current.includes(value)
      ? current.filter(item => item !== value)
      : [...current, value];
    
    setFilters({ ...filters, [category]: updated });
  };

  const handleRadioChange = (category, value) => {
    setFilters({ ...filters, [category]: value });
  };

  const handleSearchChange = (e) => {
    setFilters({ ...filters, search: e.target.value });
  };

  return (
    <aside className="candidate-filter-sidebar">
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '-10px' }}>
        <button 
          onClick={onClose}
          style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: '4px' }}
          title="Close Sidebar"
        >
          <X size={18} />
        </button>
      </div>

      {/* Total Count Card */}
      <div className="filter-stats-card">
        <div className="filter-stats-label">Results Found</div>
        <div className="filter-stats-value">{totalCount}</div>
        <div className="filter-stats-subtext">out of {overallTotal || totalCount} total records</div>
      </div>

      {/* Search Input */}
      <div className="filter-search-container">
        <Search size={16} className="filter-search-icon" />
        <input
          type="text"
          className="filter-search-input"
          placeholder="Search name, job..."
          value={filters.search || ''}
          onChange={handleSearchChange}
        />
      </div>

      {/* Status Filter */}
      {availableStatuses.length > 0 && (
        <div className="filter-section">
          <h4 className="filter-section-title">Status</h4>
          <div className="filter-options-list">
            {availableStatuses.map(status => (
              <label key={status} className="filter-option-item">
                <input
                  type="checkbox"
                  checked={(filters.status || []).includes(status)}
                  onChange={() => handleCheckboxChange('status', status)}
                />
                <span className="filter-option-label">{status}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Person Type Filter */}
      <div className="filter-section">
        <h4 className="filter-section-title">Type</h4>
        <div className="filter-options-list">
          {[
            { label: 'All', value: 'all' },
            { label: 'Candidates', value: 'candidates' },
            { label: 'Employees', value: 'employees' }
          ].map(opt => (
            <label key={opt.value} className="filter-option-item">
              <input
                type="radio"
                name="personType"
                checked={(filters.personType || 'all') === opt.value}
                onChange={() => handleRadioChange('personType', opt.value)}
              />
              <span className="filter-option-label">{opt.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Bench Status Filter */}
      <div className="filter-section">
        <h4 className="filter-section-title">Bench Status</h4>
        <div className="filter-options-list">
          {[
            { label: 'All', value: 'all' },
            { label: 'Bench Only', value: 'bench' },
            { label: 'Non-Bench', value: 'non-bench' }
          ].map(opt => (
            <label key={opt.value} className="filter-option-item">
              <input
                type="radio"
                name="isBench"
                checked={(filters.isBench || 'all') === opt.value}
                onChange={() => handleRadioChange('isBench', opt.value)}
              />
              <span className="filter-option-label">{opt.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Work Type Filter */}
      {availableWorkTypes.length > 0 && (
        <div className="filter-section">
          <h4 className="filter-section-title">Work Type</h4>
          <div className="filter-options-list">
            {availableWorkTypes.map(type => (
              <label key={type} className="filter-option-item">
                <input
                  type="checkbox"
                  checked={(filters.workType || []).includes(type)}
                  onChange={() => handleCheckboxChange('workType', type)}
                />
                <span className="filter-option-label">{type}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Experience Filter */}
      <div className="filter-section">
        <h4 className="filter-section-title">Experience</h4>
        <div className="filter-options-list">
          {[
            { label: 'All', value: 'all' },
            { label: 'Entry (0-2y)', value: '0-2' },
            { label: 'Mid (3-5y)', value: '3-5' },
            { label: 'Senior (5-10y)', value: '5-10' },
            { label: 'Expert (10y+)', value: '10+' }
          ].map(opt => (
            <label key={opt.value} className="filter-option-item">
              <input
                type="radio"
                name="experience"
                checked={(filters.experience || 'all') === opt.value}
                onChange={() => handleRadioChange('experience', opt.value)}
              />
              <span className="filter-option-label">{opt.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Gender Filter */}
      {availableGenders.length > 0 && (
        <div className="filter-section">
          <h4 className="filter-section-title">Gender</h4>
          <div className="filter-options-list">
            {availableGenders.map(gender => (
              <label key={gender} className="filter-option-item">
                <input
                  type="checkbox"
                  checked={(filters.gender || []).includes(gender)}
                  onChange={() => handleCheckboxChange('gender', gender)}
                />
                <span className="filter-option-label">{gender}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Relocation Filter */}
      <div className="filter-section">
        <h4 className="filter-section-title">Relocation</h4>
        <div className="filter-options-list">
          {[
            { label: 'All', value: 'all' },
            { label: 'Willing', value: 'yes' },
            { label: 'Not Willing', value: 'no' }
          ].map(opt => (
            <label key={opt.value} className="filter-option-item">
              <input
                type="radio"
                name="relocate"
                checked={(filters.relocate || 'all') === opt.value}
                onChange={() => handleRadioChange('relocate', opt.value)}
              />
              <span className="filter-option-label">{opt.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Source Filter */}

      {/* Source Filter */}
      {availableSources.length > 0 && (
        <div className="filter-section">
          <h4 className="filter-section-title">Source</h4>
          <div className="filter-options-list">
            {availableSources.map(source => (
              <label key={source} className="filter-option-item">
                <input
                  type="checkbox"
                  checked={(filters.sources || []).includes(source)}
                  onChange={() => handleCheckboxChange('sources', source)}
                />
                <span className="filter-option-label">{source}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Employment Type Filter */}
      {availableEmploymentTypes.length > 0 && (
        <div className="filter-section">
          <h4 className="filter-section-title">Employment Type</h4>
          <div className="filter-options-list">
            {availableEmploymentTypes.map(type => (
              <label key={type} className="filter-option-item">
                <input
                  type="checkbox"
                  checked={(filters.employmentTypes || []).includes(type)}
                  onChange={() => handleCheckboxChange('employmentTypes', type)}
                />
                <span className="filter-option-label">{type}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Industry Filter */}
      {availableIndustries.length > 0 && (
        <div className="filter-section">
          <h4 className="filter-section-title">Industry</h4>
          <div className="filter-options-list">
            {availableIndustries.slice(0, 8).map(ind => (
              <label key={ind} className="filter-option-item">
                <input
                  type="checkbox"
                  checked={(filters.industries || []).includes(ind)}
                  onChange={() => handleCheckboxChange('industries', ind)}
                />
                <span className="filter-option-label">{ind}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Location Filter */}
      {availableLocations.length > 0 && (
        <div className="filter-section">
          <h4 className="filter-section-title">Location</h4>
          <div className="filter-options-list">
            {availableLocations.slice(0, 10).map(loc => (
              <label key={loc} className="filter-option-item">
                <input
                  type="checkbox"
                  checked={(filters.locations || []).includes(loc)}
                  onChange={() => handleCheckboxChange('locations', loc)}
                />
                <span className="filter-option-label">{loc}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      <button className="clear-filters-btn" onClick={onClearAll}>
        Clear all filters
      </button>
    </aside>
  );
};

export default CandidateFilterSidebar;
