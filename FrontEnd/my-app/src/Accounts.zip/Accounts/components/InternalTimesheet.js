import React, { useState, useEffect } from "react";
import "../styles/InternalTimesheet.css";
import axios from 'axios';
import BASE_URL from '../../url';
import { LuClipboardList } from "react-icons/lu";

const InternalTimesheet = () => {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [timesheetData, setTimesheetData] = useState([]);
  const [editingCell, setEditingCell] = useState(null);
  const [editValue, setEditValue] = useState("");
  const [contextMenu, setContextMenu] = useState(null);
  const [savedTimesheetId, setSavedTimesheetId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [taskModal, setTaskModal] = useState(null);
  const [taskInput, setTaskInput] = useState("");
  const [dailyTasks, setDailyTasks] = useState({});
  const [submittedWeeks, setSubmittedWeeks] = useState(new Set());
  const [allowEditing, setAllowEditing] = useState(false);
  const [hasExplicitPermission, setHasExplicitPermission] = useState(false);
  const [permissionLoading, setPermissionLoading] = useState(true);
  const [dataLoading, setDataLoading] = useState(true);

  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const years = Array.from({ length: 10 }, (_, i) => new Date().getFullYear() - 2 + i);

  const statusTypes = [
    { label: "Filled Hours (8h)", color: "#86cb89" },
    { label: "Not Filled Hours (0h)", color: "#f44336" },
    { label: "Partially Filled Hours", color: "#FFC107" },
    { label: "Approved Leave", color: "#2196F3" },
    { label: "Holiday", color: "#9C27B0" }
  ];

  const today = new Date();
  const isCurrentMonth = selectedMonth === today.getMonth() + 1 && selectedYear === today.getFullYear();

  // ✅ Helper to format date to YYYY-MM-DD in local time
  const formatDateKey = (date) => {
    if (!date) return "";
    const d = new Date(date);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  const isDateEditable = (date) => {
    if (!date) return false;
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    
    const localToday = new Date();
    localToday.setHours(0, 0, 0, 0);

    // If it's a future date, don't allow editing (grayed-out/locked)
    if (d > localToday) return false;
    
    return true;
  };

  const isWeekSubmittable = (week) => {
    if (!week || !week.fullDates) return false;
    return week.fullDates.some((date, idx) => {
      if (!date) return false;
      if (!isDateEditable(date)) return false;
      return week.hours[idx] > 0;
    });
  };

  const isWeekSubmitted = (weekIndex, week) => {
    if (!week) week = timesheetData[weekIndex];
    if (!week || !week.fullDates) return false;
    // Find the first non-null date to identify the week
    const firstDate = week.fullDates.find(d => d !== null);
    if (!firstDate) return false;
    // Align to Monday of that week
    const monday = getMondayOfDate(firstDate);
    const key = formatDateKey(monday);
    return submittedWeeks.has(key);
  };

  const isCellEditable = (weekIndex, date) => {
    if (!isDateEditable(date)) return false;
    
    // If manager has explicitly set a permission (Allow or Revoke)
    if (hasExplicitPermission) {
      // If Allowed (true), unfreeze all. If Revoked (false), freeze all.
      return allowEditing;
    }
    
    // Default flow: If no explicit permission, allow editing only for UN-SUBMITTED weeks
    return !isWeekSubmitted(weekIndex, timesheetData[weekIndex]);
  };

  useEffect(() => {
    const checkEditingPermission = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(
          `${BASE_URL}/api/timesheets/check-editing-permission`,
          {
            headers: { Authorization: `Bearer ${token}` }
          }
        );
        
        if (response.data.success) {
          setAllowEditing(response.data.allowEditing);
          setHasExplicitPermission(!!response.data.permission);
          console.log('✅ Editing permission:', response.data.allowEditing, 'Explicit:', !!response.data.permission);
        }
      } catch (error) {
        console.error("Error checking editing permission:", error);
        setAllowEditing(false);
      } finally {
        setPermissionLoading(false);
      }
    };

    checkEditingPermission();

    const permissionCheckInterval = setInterval(() => {
      checkEditingPermission();
    }, 5000);

    return () => clearInterval(permissionCheckInterval);
  }, []);

  useEffect(() => {
    const loadData = async () => {
      setDataLoading(true);
      try {
        generateTimesheetData();
        await loadTimesheetData();
      } catch (error) {
        console.error("Error loading data:", error);
      } finally {
        setDataLoading(false);
      }
    };
    loadData();
  }, [selectedMonth, selectedYear]);

  useEffect(() => {
    if (timesheetData.length > 0) {
       loadTimesheetData();
    }
  }, [timesheetData.length, selectedMonth, selectedYear]);

  async function loadTimesheetData() {
    try {
      const token = localStorage.getItem('token');
      console.log('📋 Fetching timesheets for month:', { month: selectedMonth, year: selectedYear });
      
      const response = await axios.get(`${BASE_URL}/api/timesheets`, {
        headers: { Authorization: `Bearer ${token}` },
        params: {
          month: selectedMonth,
          year: selectedYear
        }
      });

      if (response.data && response.data.length > 0) {
        console.log('✅ Found', response.data.length, 'weekly timesheets');
        
        setSavedTimesheetId(response.data[0].id);
        
        let allEntries = [];
        const submittedWeeksSet = new Set();

        for (const weekRecord of response.data) {
          const detailResponse = await axios.get(`${BASE_URL}/api/timesheets/${weekRecord.id}`, {
            headers: { Authorization: `Bearer ${token}` }
          });
          
          const fullWeek = detailResponse.data;
          if (fullWeek.entries) {
            allEntries = [...allEntries, ...fullWeek.entries];
          }
          
          if (weekRecord.Status !== 'DRAFT') {
            // weekRecord.WeekStartDate is likely 'YYYY-MM-DD...'
            // We want to force it to local midnight for consistent keys
            const [y, m, d] = weekRecord.WeekStartDate.split('T')[0].split('-').map(Number);
            const monday = new Date(y, m - 1, d);
            submittedWeeksSet.add(formatDateKey(monday));
          }
        }
        
        if (allEntries.length > 0) {
          console.log('📝 Populating month with', allEntries.length, 'total entries');
          populateTimesheetFromEntries(allEntries);
          loadDailyTasks(allEntries);
        }

        // Always apply submitted weeks regardless of whether entries exist
        setSubmittedWeeks(submittedWeeksSet);
      } else {
        console.log('ℹ️ No timesheets found for this month/year');
        setSavedTimesheetId(null);
        setSubmittedWeeks(new Set());
      }
    } catch (error) {
      console.error("Error loading timesheet:", error);
      setSavedTimesheetId(null);
    }
  }

  function getMondayOfDate(date) {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(d.getFullYear(), d.getMonth(), diff);
  }

  function loadDailyTasks(entries) {
    const tasks = {};
    entries.forEach(entry => {
      const entryDate = new Date(entry.date || entry.Date);
      const day = String(entryDate.getUTCDate()).padStart(2, '0');
      const month = String(entryDate.getUTCMonth() + 1).padStart(2, '0');
      const year = entryDate.getUTCFullYear();
      const dateKey = `${year}-${month}-${day}`;
      
      const taskText = entry.description || entry.Description || entry.task || entry.Notes;
      if (taskText && taskText.trim() !== '' && taskText !== 'General Work') {
        tasks[dateKey] = taskText;
      }
    });
    setDailyTasks(tasks);
  }

  function populateTimesheetFromEntries(entries) {
    const entriesMap = {};
    entries.forEach(entry => {
      const entryDate = entry.date || entry.Date;
      const date = new Date(entryDate);
      const key = formatDateKey(date);
      entriesMap[key] = {
        hours: parseFloat(entry.hours || entry.Hours),
        type: (entry.dayType || entry.HourType || 'regular').toLowerCase()
      };
    });

    setTimesheetData(prevData => {
      return prevData.map(week => ({
        ...week,
        hours: week.fullDates.map((date, idx) => {
          const key = formatDateKey(date);
          if (date !== null && entriesMap[key]) {
            return entriesMap[key].hours;
          }
          return week.hours[idx];
        }),
        types: week.fullDates.map((date, idx) => {
          const key = formatDateKey(date);
          if (date !== null && entriesMap[key]) {
            return entriesMap[key].type;
          }
          return week.types[idx];
        })
      }));
    });
  }

  const generateTimesheetData = () => {
    const firstOfMonth = new Date(selectedYear, selectedMonth - 1, 1);
    const lastOfMonth = new Date(selectedYear, selectedMonth, 0);
    let currentDay = getMondayOfDate(firstOfMonth);
    
    const weeks = [];
    // Include any week that starts on or before the last day of the month
    while (currentDay <= lastOfMonth) {
      let currentWeek = {
        dates: [],
        fullDates: [],
        hours: [],
        dayNames: [],
        types: []
      };

      for (let i = 0; i < 7; i++) {
        const dayCopy = new Date(currentDay);
        currentWeek.dates.push(dayCopy.getDate());
        currentWeek.fullDates.push(dayCopy);
        const dayOfWeek = dayCopy.getDay();
        currentWeek.dayNames.push(getDayName(dayOfWeek));
        
        const isFuture = dayCopy.getTime() > today.getTime();
        currentWeek.hours.push((isFuture || dayOfWeek === 0 || dayOfWeek === 6) ? 0 : 8);
        currentWeek.types.push('regular');
        
        currentDay.setDate(currentDay.getDate() + 1);
      }
      weeks.push(currentWeek);
    }
    
    setTimesheetData(weeks);
  };

  const getDayName = (dayIndex) => {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    return days[dayIndex];
  };

  const getHourStatus = (hours, date, type) => {
    if (date === null || type === 'empty') return "empty";
    if (type === 'leave') return "leave";
    if (type === 'holiday') return "holiday";
    if (hours === 8) return "filled";
    if (hours === 0) return "not-filled";
    if (hours > 0 && hours < 8) return "partial";
    return "not-filled";
  };

  const handleHourClick = (weekIndex, dayIndex, currentHours, date, type) => {
    if (date === null || type === 'leave' || type === 'holiday' || !isDateEditable(date)) return;
    if (!isCellEditable(weekIndex, date)) return;
    
    setEditingCell({ weekIndex, dayIndex });
    setEditValue(currentHours.toString());
  };

  const handleRightClick = (e, weekIndex, dayIndex, date) => {
    e.preventDefault();
    if (date === null || !isDateEditable(date) || !isCellEditable(weekIndex, date)) return;
    
    setContextMenu({
      weekIndex,
      dayIndex
    });
  };

  const handleSetDayType = (type) => {
    if (contextMenu) {
      const { weekIndex, dayIndex } = contextMenu;
      const newData = [...timesheetData];
      newData[weekIndex].types[dayIndex] = type;
      
      if (type === 'leave' || type === 'holiday') {
        newData[weekIndex].hours[dayIndex] = 0;
      } else if (type === 'regular') {
        const dateObj = newData[weekIndex].fullDates[dayIndex];
        const dayOfWeek = dateObj.getDay();
        const isFuture = dateObj.getTime() > today.getTime();
        newData[weekIndex].hours[dayIndex] = (isFuture || dayOfWeek === 0 || dayOfWeek === 6) ? 0 : 8;
      }
      
      setTimesheetData(newData);
    }
    setContextMenu(null);
  };

  const handleHourChange = (e) => {
    const value = e.target.value;
    if (value === "" || (/^\d*\.?\d*$/.test(value) && parseFloat(value) <= 24)) {
      setEditValue(value);
    }
  };

  const handleHourSave = () => {
    if (editingCell && editValue !== "") {
      const { weekIndex, dayIndex } = editingCell;
      const newData = [...timesheetData];
      newData[weekIndex].hours[dayIndex] = parseFloat(editValue) || 0;
      setTimesheetData(newData);
    }
    setEditingCell(null);
    setEditValue("");
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      handleHourSave();
    } else if (e.key === "Escape") {
      setEditingCell(null);
      setEditValue("");
    }
  };

  const openTaskModal = (weekIndex, date) => {
    if (!isDateEditable(date) || !isCellEditable(weekIndex, date)) return;
    
    const dateKey = formatDateKey(date);
    setTaskModal(date);
    setTaskInput(dailyTasks[dateKey] || "");
  };

  const getCurrentWeekIndex = (day) => {
    return timesheetData.findIndex(week => week.dates.includes(day));
  };

  const saveTask = () => {
    const dateKey = formatDateKey(taskModal);
    const newTasks = { ...dailyTasks };
    if (taskInput.trim()) {
      newTasks[dateKey] = taskInput.trim();
    } else {
      delete newTasks[dateKey];
    }
    setDailyTasks(newTasks);
    setTaskModal(null);
    setTaskInput("");
  };

  const getTaskDisplay = (date) => {
    const dateKey = formatDateKey(date);
    const task = dailyTasks[dateKey];
    return task ? "📋" : "Add Task";
  };

  const getTaskTooltip = (date) => {
    const dateKey = formatDateKey(date);
    return dailyTasks[dateKey] || '';
  };

  const getTaskDateKey = (date) => {
    return formatDateKey(date);
  };

  const calculateWeeklyTotal = (week) => {
    return week.hours.reduce((sum, hours) => sum + hours, 0);
  };

  const calculateMonthlyTotal = () => {
    return timesheetData.reduce((sum, week) => sum + calculateWeeklyTotal(week), 0);
  };

  const handleWeeklySubmit = async (weekIndex) => {
    setLoading(true);
    try {
      const week = timesheetData[weekIndex];
      // The start of the week IS the first date in the fullDates array (Monday)
      const weekStartDate = week.fullDates[0];
      
      const entries = [];
      week.fullDates.forEach((date, dayIndex) => {
        if (date !== null && isDateEditable(date)) {
          const dateKey = getTaskDateKey(date);
          const taskForDay = dailyTasks[dateKey] || "General Work";
          
          entries.push({
            // Send exact localized date to avoid timezone shifts
            date: formatDateKey(date), 
            hours: week.hours[dayIndex] || 0,
            dayType: week.types[dayIndex] || 'regular',
            task: taskForDay
          });
        }
      });

      const token = localStorage.getItem('token');
      
      // 1. Save weekly record
      await axios.post(`${BASE_URL}/api/timesheets/internal`, {
        weekStartDate: formatDateKey(weekStartDate), 
        entries: entries,
        notes: `Week ${weekIndex + 1} submission`
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      // 2. Refresh to find the new ID and submit it
      const refreshResponse = await axios.get(`${BASE_URL}/api/timesheets`, {
        headers: { Authorization: `Bearer ${token}` },
        params: { month: selectedMonth, year: selectedYear }
      });

      const targetKey = formatDateKey(weekStartDate);
      const savedWeek = refreshResponse.data.find(w => {
        // Handle potential ISO string or date object from backend
        const d = new Date(w.WeekStartDate || w.PeriodStart);
        return formatDateKey(d) === targetKey;
      });
      
      if (savedWeek && savedWeek.id) {
        await axios.put(`${BASE_URL}/api/timesheets/${savedWeek.id}/submit`, {}, {
          headers: { Authorization: `Bearer ${token}` }
        });
      }

      setSubmittedWeeks(prev => new Set([...prev, targetKey]));
      alert(`Week ${weekIndex + 1} submitted successfully!`);
      loadTimesheetData(); 
    } catch (error) {
      console.error("Error submitting week:", error);
      alert(`Failed to submit week: ${error.response?.data?.message || error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const entries = [];
      
      timesheetData.forEach((week, weekIndex) => {
        week.dates.forEach((date, dayIndex) => {
          if (date !== null && isDateEditable(date)) {
            const dayName = week.dayNames[dayIndex];
            const dateKey = getTaskDateKey(week.fullDates[dayIndex]);
            const taskForDay = dailyTasks[dateKey] || "General Work";
            
            entries.push({
              date: week.fullDates[dayIndex],
              hours: week.hours[dayIndex] || 0,
              dayType: week.types[dayIndex] || 'regular',
              project: "Default Project",
              task: taskForDay,
              description: `${dayName} work`
            });
          }
        });
      });

      const payload = {
        month: selectedMonth,
        year: selectedYear,
        entries: entries,
        notes: "Internal timesheet"
      };

      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${BASE_URL}/api/timesheets/internal`, 
        payload,
        {
          headers: { 
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      setSavedTimesheetId(response.data.timesheetId);
      alert(`Timesheet saved successfully!`);
    } catch (error) {
      console.error("Error saving timesheet:", error);
      alert(`Failed to save timesheet: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!savedTimesheetId) {
      alert("Please save the timesheet before submitting.");
      return;
    }

    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      await axios.put(`${BASE_URL}/api/timesheets/${savedTimesheetId}/submit`, 
        {},
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      // Re-check permissions to update the UI (it should now be frozen)
      const permResponse = await axios.get(
        `${BASE_URL}/api/timesheets/check-editing-permission`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      
      if (permResponse.data.success) {
        setAllowEditing(permResponse.data.allowEditing);
        setHasExplicitPermission(permResponse.data.permission !== null);
      }

      alert("Timesheet submitted for approval and locked for editing!");
    } catch (error) {
      console.error("Error submitting timesheet:", error);
      alert("Failed to submit timesheet: " + (error.response?.data?.message || error.message));
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    if (!savedTimesheetId) {
      alert("Please save the timesheet before exporting.");
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/timesheets/${savedTimesheetId}/export`, {
        headers: { Authorization: `Bearer ${token}` },
        responseType: 'blob'
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `timesheet-${selectedMonth}-${selectedYear}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error("Error exporting timesheet:", error);
      alert("Failed to export timesheet.");
    }
  };

  const getCellDisplay = (hours, type) => {
    if (type === 'leave') return 'Leave';
    if (type === 'holiday') return 'Holiday';
    return `${hours}h`;
  };

  useEffect(() => {
    const handleClick = () => setContextMenu(null);
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  const getHourCellClass = (status) => {
    const classMap = {
      filled: 'timesheet-hour-cell timesheet-hour-filled',
      'not-filled': 'timesheet-hour-cell timesheet-hour-not-filled',
      partial: 'timesheet-hour-cell timesheet-hour-partial',
      leave: 'timesheet-hour-cell timesheet-hour-leave',
      holiday: 'timesheet-hour-cell timesheet-hour-holiday',
      empty: 'timesheet-hour-cell timesheet-hour-empty'
    };
    return classMap[status] || 'timesheet-hour-cell';
  };

  return (
    <div className="timesheet-container">
      <div className="timesheet-header">
        <div className="timesheet-header-main">
          <h2 className="timesheet-title">Internal Timesheet</h2>
          <div className="timesheet-header-controls">
            <div className="timesheet-selectors">
              <select 
                value={selectedMonth} 
                onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                className="timesheet-select"
              >
                {months.map((month, index) => (
                  <option key={index} value={index + 1}>{month}</option>
                ))}
              </select>
              <select 
                value={selectedYear} 
                onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                className="timesheet-select"
              >
                {years.map((year) => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
        <div className="timesheet-header-right">
          <p className="editable-info">
            {isCurrentMonth 
              ? `Editable till ${today.getDate()}${today.getDate() % 10 === 1 && today.getDate() !== 11 ? 'st' : today.getDate() % 10 === 2 && today.getDate() !== 12 ? 'nd' : today.getDate() % 10 === 3 && today.getDate() !== 13 ? 'rd' : 'th'} ${months[selectedMonth - 1]} ${selectedYear}` 
              : `All dates editable for ${months[selectedMonth - 1]} ${selectedYear}`}
          </p>
        </div>
      </div>

      {hasExplicitPermission && allowEditing && (
        <div className="editing-mode-banner">
           <strong>Editing Mode:</strong> Manager has granted permission to edit submitted weeks
        </div>
      )}

      {hasExplicitPermission && !allowEditing && (
        <div className="editing-mode-banner locked">
           <strong>Locked Mode:</strong> Manager has frozen all timesheet editing for this period
        </div>
      )}

      <div className="timesheet-legend">
        {statusTypes.map((status, index) => (
          <div key={index} className="timesheet-legend-item">
            <div 
              className="timesheet-legend-color"
              style={{ backgroundColor: status.color }}
            ></div>
            <span className="timesheet-legend-text">{status.label}</span>
          </div>
        ))}
      </div>

      {dataLoading ? (
        <div style={{ textAlign: 'center', padding: '40px' }}>
          <p>Loading timesheet...</p>
        </div>
      ) : (
        <div className="timesheet-table-container">
          <table className="timesheet-table">
            <thead>
              <tr>
                <th className="timesheet-th">Week</th>
                <th className="timesheet-th">Mon</th>
                <th className="timesheet-th">Tue</th>
                <th className="timesheet-th">Wed</th>
                <th className="timesheet-th">Thu</th>
                <th className="timesheet-th">Fri</th>
                <th className="timesheet-th">Sat</th>
                <th className="timesheet-th">Sun</th>
                <th className="timesheet-th">Total</th>
                <th className="timesheet-th">Action</th>
              </tr>
            </thead>
            <tbody>
              {timesheetData.map((week, weekIndex) => (
                <React.Fragment key={weekIndex}>
                  <tr className="timesheet-date-row">
                    <td className="timesheet-td" rowSpan={3}>
                      <div className="week-label-container">
                        <strong>Week {weekIndex + 1}</strong>
                        <div className="tasks-label">Tasks</div>
                      </div>
                    </td>
                    {week.dates.map((date, dayIndex) => (
                      <td key={dayIndex} className="timesheet-td">
                        {date !== null ? (
                          <div>
                            <div className="timesheet-date-number">{date}</div>
                            <div className="timesheet-day-name">{week.dayNames[dayIndex]}</div>
                          </div>
                        ) : ""}
                      </td>
                    ))}
                    <td className="timesheet-weekly-total" rowSpan={3}>
                      <div className="total-hours-display">
                        {calculateWeeklyTotal(week)}h
                      </div>
                    </td>
                    <td className="timesheet-td" rowSpan={3}>
                      <button 
                        onClick={() => handleWeeklySubmit(weekIndex)}
                        disabled={
                          (hasExplicitPermission && !allowEditing) || 
                          (isWeekSubmitted(weekIndex, week) && !allowEditing) || 
                          !isWeekSubmittable(week) || 
                          loading
                        }
                        className={`timesheet-btn timesheet-btn-primary ${
                          ((hasExplicitPermission && !allowEditing) || (isWeekSubmitted(weekIndex, week) && !allowEditing) || !isWeekSubmittable(week)) 
                          ? 'timesheet-btn-disabled' : ''
                        }`}
                      >
                        {loading ? 'Submitting...' : isWeekSubmitted(weekIndex, week) ? '✓ Submitted' : 'Submit'}
                      </button>
                    </td>
                  </tr>
                  <tr className="timesheet-hours-row">
                    {week.hours.map((hours, dayIndex) => (
                      <td key={dayIndex} className="timesheet-td">
                        {week.dates[dayIndex] !== null ? (
                          editingCell?.weekIndex === weekIndex && editingCell?.dayIndex === dayIndex ? (
                            <input
                              type="text"
                              value={editValue}
                              onChange={handleHourChange}
                              onBlur={handleHourSave}
                              onKeyDown={handleKeyDown}
                              autoFocus
                              className="timesheet-input"
                            />
                          ) : contextMenu?.weekIndex === weekIndex && contextMenu?.dayIndex === dayIndex ? (
                            <div className="context-menu-inline" onClick={(e) => e.stopPropagation()}>
                              <div className="context-menu-item-inline" onClick={() => handleSetDayType('regular')}>Regular Day</div>
                              <div className="context-menu-item-inline" onClick={() => handleSetDayType('leave')}>Leave</div>
                              <div className="context-menu-item-inline" onClick={() => handleSetDayType('holiday')}>Holiday</div>
                            </div>
                          ) : (
                            <div
                              className={`${getHourCellClass(getHourStatus(hours, week.fullDates[dayIndex], week.types[dayIndex]))} ${!isDateEditable(week.fullDates[dayIndex]) ? 'timesheet-cell-locked' : ''}`}
                              onClick={() => handleHourClick(weekIndex, dayIndex, hours, week.fullDates[dayIndex], week.types[dayIndex])}
                              onContextMenu={(e) => handleRightClick(e, weekIndex, dayIndex, week.fullDates[dayIndex])}
                              style={{
                                cursor: isCellEditable(weekIndex, week.fullDates[dayIndex]) ? 'pointer' : 'not-allowed',
                                opacity: isCellEditable(weekIndex, week.fullDates[dayIndex]) ? 1 : 0.4,
                                filter: isCellEditable(weekIndex, week.fullDates[dayIndex]) ? 'none' : 'grayscale(100%)'
                              }}
                            >
                              {getCellDisplay(hours, week.types[dayIndex])}
                            </div>
                          )
                        ) : (
                          <div className={getHourCellClass('empty')}></div>
                        )}
                      </td>
                    ))}
                  </tr>
                  <tr className="timesheet-tasks-row">
                    {week.dates.map((date, dayIndex) => (
                      <td key={dayIndex} className="timesheet-td">
                        {date !== null ? (
                          <button
                            onClick={() => openTaskModal(weekIndex, week.fullDates[dayIndex])}
                            title={getTaskTooltip(week.fullDates[dayIndex])}
                            disabled={!isCellEditable(weekIndex, date)}
                            className={`timesheet-task-btn ${!isCellEditable(weekIndex, date) ? 'timesheet-task-btn-disabled' : ''}`}
                          >
                            {getTaskDisplay(week.fullDates[dayIndex])}
                          </button>
                        ) : (
                          <div className={getHourCellClass('empty')}></div>
                        )}
                      </td>
                    ))}
                  </tr>
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}



      {taskModal && (
        <div 
          className="task-modal-overlay"
          onClick={() => setTaskModal(null)}
        >
          <div 
            className="task-modal"
            onClick={(e) => e.stopPropagation()}
          >
            <h3>Add Task for Day {taskModal.getDate()}</h3>
            <textarea
              value={taskInput}
              onChange={(e) => setTaskInput(e.target.value)}
              placeholder="Enter tasks completed today..."
              rows="4"
              className="task-textarea"
            />
            <div className="task-modal-buttons">
              <button 
                onClick={saveTask}
                className="task-btn-save"
              >
                Save
              </button>
              <button 
                onClick={() => setTaskModal(null)}
                className="task-btn-cancel"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="timesheet-actions">
        <button 
          onClick={handleSave}
          disabled={loading}
          className={`timesheet-btn timesheet-btn-primary ${loading ? 'timesheet-btn-disabled' : ''}`}
        >
          {loading ? "Saving..." : "Save Timesheet"}
        </button>
        <button 
          onClick={handleSubmit}
          disabled={loading}
          className={`timesheet-btn timesheet-btn-secondary ${loading ? 'timesheet-btn-disabled' : ''}`}
        >
          {loading ? "Submitting..." : "Submit for Approval"}
        </button>
        <button 
          onClick={handleExport}
          className="timesheet-btn timesheet-btn-outline"
        >
          Export to CSV
        </button>
      </div>

      <div className="timesheet-info">
        <p className="timesheet-info-text">
          <strong>Note:</strong> {isCurrentMonth ? `Editable dates: 1st to today (${today.getDate()}th). Future dates are frozen and cannot be edited.` : `All dates in ${months[selectedMonth - 1]} ${selectedYear} are editable.`}
          {!allowEditing ? " Submitted weeks remain locked unless manager grants permission." : " ⚡ Manager has granted permission to edit submitted weeks."}
          Left-click on hour cells to edit hours. 
          Right-click to mark as Leave or Holiday.
          Click task buttons to add daily tasks.
        </p>
      </div>
    </div>
  );
};

export default InternalTimesheet;