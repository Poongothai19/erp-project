import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { 
  CheckCircle, 
  XCircle, 
  Clock, 
  User, 
  Mail, 
  Phone, 
  Calendar, 
  ThumbsUp, 
  ThumbsDown,
  Filter,
  Search,
  MoreVertical,
  ClipboardList,
  ChevronRight,
  ChevronLeft,
  Building,
  AlertCircle
} from 'lucide-react';
import BASE_URL from "../../url";
import Swal from 'sweetalert2';
import '../styles/ManagerDashboard.css';

const TimeSheetApprovals = () => {
    const navigate = useNavigate();
    const [timesheets, setTimesheets] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterStatus, setFilterStatus] = useState('all');
    const [selectedCompany, setSelectedCompany] = useState('all');
    const [companies, setCompanies] = useState([]);

    // Fetch timesheets for a specific company
    const fetchTimesheetsByCompany = useCallback(async (companyId) => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`${BASE_URL}/api/timesheets/company/${companyId}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (response.data.success) {
                return response.data.data.map(ts => ({ ...ts, selected: false }));
            }
            return [];
        } catch (error) {
            console.error(`Error fetching timesheets for company ${companyId}:`, error);
            return [];
        }
    }, []);

    // Fetch timesheets from ALL companies
    const fetchAllTimesheets = useCallback(async (allCompanies) => {
        try {
            setLoading(true);
            const results = await Promise.all(
                allCompanies.map(c => fetchTimesheetsByCompany(c.id))
            );
            const merged = results.flat();
            setTimesheets(merged);
        } catch (error) {
            console.error('Error fetching all timesheets:', error);
            Swal.fire({ title: 'Error', text: 'Failed to load timesheets', icon: 'error' });
        } finally {
            setLoading(false);
        }
    }, [fetchTimesheetsByCompany]);

    // Fetch timesheets for a single selected company
    const fetchTimesheets = useCallback(async (companyId) => {
        try {
            setLoading(true);
            const data = await fetchTimesheetsByCompany(companyId);
            setTimesheets(data);
        } catch (error) {
            console.error('Error fetching timesheets:', error);
        } finally {
            setLoading(false);
        }
    }, [fetchTimesheetsByCompany]);

    // Fetch all companies for filtering
    const fetchCompanies = useCallback(async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`${BASE_URL}/api/companies`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (response.data) {
                const data = Array.isArray(response.data) ? response.data : (response.data.data || []);
                setCompanies(data);
                return data;
            }
            return [];
        } catch (error) {
            console.error('Error fetching companies:', error);
            return [];
        }
    }, []);

    // On mount: load all companies then load all timesheets
    useEffect(() => {
        const initialize = async () => {
            const allCompanies = await fetchCompanies();
            if (allCompanies.length > 0) {
                await fetchAllTimesheets(allCompanies);
            } else {
                setLoading(false);
            }
        };
        initialize();
    }, [fetchCompanies, fetchAllTimesheets]);

    // When company dropdown changes
    const handleCompanyChange = async (e) => {
        const value = e.target.value;
        setSelectedCompany(value);
        if (value === 'all') {
            await fetchAllTimesheets(companies);
        } else {
            await fetchTimesheets(parseInt(value));
        }
    };


    // Handlers
    const handleApprove = async (timesheetId, companyId) => {
        const confirm = await Swal.fire({
            title: 'Approve Timesheet?',
            text: 'Are you sure you want to approve this timesheet?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#10b981',
            cancelButtonColor: '#6b7280',
            confirmButtonText: 'Yes, Approve'
        });

        if (confirm.isConfirmed) {
            try {
                const token = localStorage.getItem('token');
                const response = await axios.patch(
                    `${BASE_URL}/api/timesheets/company/${companyId}/${timesheetId}/approve`,
                    {},
                    {
                        headers: { 'Authorization': `Bearer ${token}` }
                    }
                );

                if (response.data.success) {
                    const currentUsername = localStorage.getItem('username') || 'You';
                    setTimesheets(prev => prev.map(ts => 
                        ts.Id === timesheetId 
                        ? { ...ts, Status: 'Approved', ApproverName: currentUsername, status: 'Approved' } 
                        : ts
                    ));
                    Swal.fire({
                        title: 'Approved!',
                        text: 'Timesheet has been approved.',
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    });
                }
            } catch (error) {
                Swal.fire('Error', 'Failed to approve timesheet', 'error');
            }
        }
    };

    const handleReject = async (timesheetId, companyId) => {
        const { value: reason } = await Swal.fire({
            title: 'Reject Timesheet',
            input: 'textarea',
            inputLabel: 'Reason for rejection',
            inputPlaceholder: 'Type your reason here...',
            inputAttributes: {
                'aria-label': 'Type your reason here'
            },
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            confirmButtonText: 'Reject'
        });

        if (reason) {
            try {
                const token = localStorage.getItem('token');
                const response = await axios.patch(
                    `${BASE_URL}/api/timesheets/company/${companyId}/${timesheetId}/reject`,
                    { reason },
                    {
                        headers: { 'Authorization': `Bearer ${token}` }
                    }
                );

                if (response.data.success) {
                    setTimesheets(prev => prev.map(ts => 
                        ts.Id === timesheetId 
                        ? { ...ts, Status: 'Rejected', status: 'Rejected' } 
                        : ts
                    ));
                    Swal.fire({
                        title: 'Rejected',
                        text: 'Timesheet has been rejected.',
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    });
                }
            } catch (error) {
                Swal.fire('Error', 'Failed to reject timesheet', 'error');
            }
        }
    };

    const handleSelectAll = (e) => {
        const checked = e.target.checked;
        setTimesheets(prev => prev.map(ts => ({ ...ts, selected: checked })));
    };

    const handleSelect = (id) => {
        setTimesheets(prev => prev.map(ts => 
            ts.Id === id ? { ...ts, selected: !ts.selected } : ts
        ));
    };

    const handleBulkApprove = async () => {
        const selectedIds = timesheets.filter(ts => ts.selected).map(ts => ts.Id);
        if (selectedIds.length === 0) return;

        // Group by company because bulk API currently expects a companyId
        // Wait, the bulk API in managerTimesheetController.js expects ONE companyId.
        // If we have timesheets from multiple companies, we need to call it multiple times or modify it.
        // For simplicity, let's group by company and call multiple times.
        const byCompany = timesheets.filter(ts => ts.selected).reduce((acc, ts) => {
            acc[ts.CompanyId] = acc[ts.CompanyId] || [];
            acc[ts.CompanyId].push(ts.Id);
            return acc;
        }, {});

        const confirm = await Swal.fire({
            title: 'Bulk Approve?',
            text: `Approve ${selectedIds.length} selected timesheets?`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#10b981',
            confirmButtonText: 'Yes, Approve All'
        });

        if (confirm.isConfirmed) {
            try {
                const token = localStorage.getItem('token');
                setLoading(true);
                
                for (const companyId in byCompany) {
                    await axios.post(
                        `${BASE_URL}/api/timesheets/bulk/approve`,
                        { timesheetIds: byCompany[companyId], companyId: parseInt(companyId) },
                        { headers: { 'Authorization': `Bearer ${token}` } }
                    );
                }

                // Refresh list
                if (selectedCompany === 'all') {
                    await fetchAllTimesheets(companies);
                } else {
                    await fetchTimesheets(parseInt(selectedCompany));
                }
                
                Swal.fire('Success', 'Selected timesheets approved', 'success');
            } catch (error) {
                Swal.fire('Error', 'Bulk approval failed', 'error');
            } finally {
                setLoading(false);
            }
        }
    };

    // Export timesheet to CSV
    const exportTimesheetToCSV = (timesheet, entries) => {
        const csvRows = [];
        
        // Add header information
        csvRows.push(`Timesheet Tasks - ${timesheet.EmployeeName}`);
        csvRows.push(`Period:,${new Date(timesheet.PeriodStart).toLocaleDateString()} - ${new Date(timesheet.PeriodEnd).toLocaleDateString()}`);
        csvRows.push(`Total Hours:,${timesheet.TotalHours || 0} hours`);
        csvRows.push(`Status:,${timesheet.Status}`);
        if (timesheet.Notes) {
            csvRows.push(`Notes:,${timesheet.Notes}`);
        }
        csvRows.push(''); // Empty row
        
        // Add table headers
        csvRows.push('Date,Day,Hours,Type,Task');
        
        // Add entries
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        entries.forEach(entry => {
            const entryDate = new Date(entry.Date);
            const dayName = dayNames[entryDate.getDay()];
            const task = (entry.Task || 'General Work').replace(/,/g, ';'); // Replace commas in task
            
            // Format date with tab character to force text format in Excel
            const formattedDate = `="${entryDate.toLocaleDateString()}"`;
            
            csvRows.push(`${formattedDate},${dayName},${entry.Hours || 0},${entry.DayType || 'Regular'},${task}`);
        });
        
        // Create CSV content
        const csvContent = csvRows.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        
        link.setAttribute('href', url);
        link.setAttribute('download', `Timesheet_${timesheet.EmployeeName}_${new Date(timesheet.PeriodStart).toLocaleDateString().replace(/\//g, '-')}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleViewTasks = async (ts) => {
        try {
            const token = localStorage.getItem('token');
            const timesheetId = ts.Id;

            // Fetch the entries for this timesheet
            const entriesResponse = await axios.get(
                `${BASE_URL}/api/timesheets/${timesheetId}/entries`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                }
            );

            const entries = entriesResponse.data.entries || entriesResponse.data || [];

            // Format entries for display
            let entriesHtml = '<div style="max-height: 400px; overflow-y: auto;">';
            
            if (entries.length > 0) {
                entriesHtml += '<table style="width: 100%; border-collapse: collapse; text-align: left;">';
                entriesHtml += '<thead><tr style="background: #f3f4f6; border-bottom: 2px solid #e5e7eb;">';
                entriesHtml += '<th style="padding: 12px;">Date</th>';
                entriesHtml += '<th style="padding: 12px;">Day</th>';
                entriesHtml += '<th style="padding: 12px;">Hours</th>';
                entriesHtml += '<th style="padding: 12px;">Type</th>';
                entriesHtml += '<th style="padding: 12px;">Task</th>';
                entriesHtml += '</tr></thead><tbody>';
                
                entries.forEach(entry => {
                    const entryDate = new Date(entry.Date);
                    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                    const dayName = dayNames[entryDate.getDay()];
                    
                    entriesHtml += '<tr style="border-bottom: 1px solid #e5e7eb;">';
                    entriesHtml += `<td style="padding: 10px;">${entryDate.toLocaleDateString()}</td>`;
                    entriesHtml += `<td style="padding: 10px;">${dayName}</td>`;
                    entriesHtml += `<td style="padding: 10px; font-weight: 600;">${entry.Hours || 0} hrs</td>`;
                    entriesHtml += `<td style="padding: 10px;">${entry.DayType || 'Regular'}</td>`;
                    entriesHtml += `<td style="padding: 10px; max-width: 300px; white-space: normal; word-wrap: break-word;">${entry.Task || 'General Work'}</td>`;
                    entriesHtml += '</tr>';
                });
                
                entriesHtml += '</tbody></table>';
            } else {
                entriesHtml += '<p style="text-align: center; padding: 20px; color: #6b7280;">No entries found for this timesheet.</p>';
            }
            
            entriesHtml += '</div>';

            Swal.fire({
                title: `Timesheet Tasks - ${ts.EmployeeName || ts.employeeName || 'Unknown'}`,
                html: `
                    <div style="text-align: left; margin-bottom: 20px;">
                        <p><strong>Period:</strong> ${new Date(ts.PeriodStart || ts.periodStart).toLocaleDateString()} - ${new Date(ts.PeriodEnd || ts.periodEnd).toLocaleDateString()}</p>
                        <p><strong>Total Hours:</strong> ${ts.TotalHours || 0} hours</p>
                        <p><strong>Status:</strong> <span style="padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; background: #fff3cd; color: #856404;">${ts.Status || ts.status}</span></p>
                        ${ts.Notes ? `<p><strong>Notes:</strong> ${ts.Notes}</p>` : ''}
                    </div>
                    ${entriesHtml}
                `,
                width: '900px',
                showCancelButton: true,
                confirmButtonText: 'Export CSV',
                cancelButtonText: 'Close',
                confirmButtonColor: '#10b981',
                cancelButtonColor: '#6b7280'
            }).then((result) => {
                if (result.isConfirmed) {
                    exportTimesheetToCSV(ts, entries);
                    Swal.fire({
                        title: 'Exported!',
                        text: 'Timesheet has been exported to CSV',
                        icon: 'success',
                        timer: 2000,
                        showConfirmButton: false
                    });
                }
            });
        } catch (error) {
            console.error('Error fetching timesheet tasks:', error);
            Swal.fire('Error', 'Failed to load timesheet tasks', 'error');
        }
    };

    // Filters
    const filteredData = useMemo(() => {
        return timesheets.filter(ts => {
            const matchesSearch = 
                (ts.EmployeeName || ts.employeeName || '')?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                (ts.EmployeeCode || ts.EmployeeId || '')?.toString().toLowerCase().includes(searchTerm.toLowerCase()) ||
                (ts.CompanyName || '')?.toLowerCase().includes(searchTerm.toLowerCase());
            
            const matchesCompany = selectedCompany === 'all' || ts.CompanyId === parseInt(selectedCompany);
            
            // Allow display based on status filter
            const matchesStatus = filterStatus === 'all' || 
                (ts.Status || ts.status)?.toLowerCase() === filterStatus.toLowerCase();
            
            return matchesSearch && matchesCompany && matchesStatus;
        });
    }, [timesheets, searchTerm, selectedCompany, filterStatus]);

    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleDateString();
    };

    return (
        <div className="mts-dashboard-container" style={{ padding: '20px', backgroundColor: '#f9fafb', minHeight: '100vh' }}>
            {/* Header */}
            <div className="mts-header" style={{ marginBottom: '24px', background: 'white', padding: '24px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        <h1 style={{ fontSize: '24px', fontWeight: '700', color: '#111827', margin: 0, display: 'flex', alignItems: 'center', gap: '12px' }}>
                            <ClipboardList className="text-teal-600" size={28} />
                            Timesheet Approvals
                        </h1>
                        <p style={{ color: '#6b7280', marginTop: '4px' }}>Review and approve pending timesheets across all companies</p>
                    </div>
                </div>

                {/* Filters */}
                <div style={{ display: 'flex', gap: '16px', marginTop: '24px', flexWrap: 'wrap' }}>
                    <div style={{ position: 'relative', flex: 1, minWidth: '200px' }}>
                        <Search style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#9ca3af' }} size={18} />
                        <input 
                            type="text" 
                            placeholder="Search by employee, ID or company..." 
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            style={{ width: '100%', padding: '10px 10px 10px 40px', borderRadius: '8px', border: '1px solid #d1d5db', outline: 'none' }}
                        />
                    </div>
                    
                    <select 
                        value={selectedCompany}
                        onChange={handleCompanyChange}
                        style={{ padding: '10px 16px', borderRadius: '8px', border: '1px solid #d1d5db', outline: 'none', minWidth: '180px' }}
                    >
                        <option value="all">All Companies</option>
                        {companies.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                        ))}
                    </select>

                    <select 
                        value={filterStatus}
                        onChange={(e) => setFilterStatus(e.target.value)}
                        style={{ padding: '10px 16px', borderRadius: '8px', border: '1px solid #d1d5db', outline: 'none', minWidth: '150px' }}
                    >
                        <option value="all">All Statuses</option>
                        <option value="Pending">Pending</option>
                        <option value="Approved">Approved</option>
                        <option value="Rejected">Rejected</option>
                    </select>

                    <button 
                        onClick={handleBulkApprove}
                        disabled={!timesheets.some(ts => ts.selected)}
                        className="mts-bulk-approve-btn"
                        style={{ 
                            display: 'flex', 
                            alignItems: 'center', 
                            gap: '8px', 
                            padding: '10px 20px', 
                            borderRadius: '8px', 
                            backgroundColor: timesheets.some(ts => ts.selected) ? '#10b981' : '#d1d5db',
                            color: 'white', 
                            border: 'none', 
                            fontWeight: '600',
                            cursor: timesheets.some(ts => ts.selected) ? 'pointer' : 'not-allowed'
                        }}
                    >
                        <ThumbsUp size={18} />
                        Approve Selected ({timesheets.filter(ts => ts.selected).length})
                    </button>
                </div>
            </div>

            {/* Table */}
            <div className="mts-employee-table" style={{ background: 'white', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', overflow: 'hidden' }}>
                <div className="mts-employee-table-table-header" style={{ display: 'grid', gridTemplateColumns: '50px 2fr 1.5fr 1.2fr 1.5fr 1fr 1fr 1fr 1.2fr', padding: '16px', backgroundColor: '#f9fafb', borderBottom: '1px solid #e5e7eb', fontWeight: '600', color: '#374151' }}>
                    <div>
                        <input type="checkbox" onChange={handleSelectAll} checked={timesheets.length > 0 && timesheets.every(ts => ts.selected)} />
                    </div>
                    <div>Employee and Id</div>
                    <div>Email</div>
                    <div>Phone</div>
                    <div>Period</div>
                    <div>Hours</div>
                    <div>Status</div>
                    <div>Approved By</div>
                    <div>Action</div>
                </div>

                {loading ? (
                    <div style={{ padding: '40px', textAlign: 'center' }}>
                        <div className="loading-spinner" style={{ margin: '0 auto' }}></div>
                        <p style={{ marginTop: '12px', color: '#6b7280' }}>Loading pending timesheets...</p>
                    </div>
                ) : filteredData.length > 0 ? (
                    <div className="mts-employee-table-table-rows">
                        {filteredData.map(ts => (
                            <div key={ts.Id} className="mts-employee-table-table-row" style={{ display: 'grid', gridTemplateColumns: '50px 2fr 1.5fr 1.2fr 1.5fr 1fr 1fr 1fr 1.2fr', padding: '16px', borderBottom: '1px solid #f3f4f6', alignItems: 'center' }}>
                                <div>
                                    <input type="checkbox" checked={ts.selected} onChange={() => handleSelect(ts.Id)} />
                                </div>
                                <div>
                                    <div 
                                        onClick={() => handleViewTasks(ts)}
                                        style={{ 
                                            fontWeight: '600', 
                                            color: '#10b981', 
                                            cursor: 'pointer',
                                            textDecoration: 'none'
                                        }}
                                        onMouseOver={(e) => e.target.style.textDecoration = 'underline'}
                                        onMouseOut={(e) => e.target.style.textDecoration = 'none'}
                                    >
                                        {ts.EmployeeName || ts.employeeName || 'Unknown'}
                                    </div>
                                    <div style={{ fontSize: '12px', color: '#6b7280' }}>ID: {ts.EmployeeCode || ts.EmployeeId}</div>
                                    <div style={{ fontSize: '11px', color: '#10b981', marginTop: '2px' }}>{ts.CompanyName}</div>
                                </div>
                                <div style={{ fontSize: '14px', color: '#4b5563', wordBreak: 'break-all' }}>
                                    {ts.EmployeeEmail || ts.employeeEmail || ts.EmployeeEmail || 'N/A'}
                                </div>
                                <div style={{ fontSize: '14px', color: '#4b5563' }}>
                                    {ts.EmployeePhone || ts.employeePhone || 'N/A'}
                                </div>
                                <div style={{ fontSize: '14px', color: '#4b5563' }}>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                        <Calendar size={14} className="text-gray-400" />
                                        <span>{formatDate(ts.PeriodStart || ts.periodStart)} - {formatDate(ts.PeriodEnd || ts.periodEnd)}</span>
                                    </div>
                                </div>
                                <div>
                                    <div style={{ fontWeight: '600', color: '#111827' }}>{ts.TotalHours}h</div>
                                    {ts.OvertimeHours > 0 && <div style={{ fontSize: '11px', color: '#ef4444' }}>OT: {ts.OvertimeHours}h</div>}
                                </div>
                                <div>
                                    <span style={{ 
                                        padding: '4px 10px', 
                                        borderRadius: '9999px', 
                                        fontSize: '12px', 
                                        fontWeight: '600',
                                        backgroundColor: (ts.Status || ts.status) === 'Approved' ? '#ecfdf5' : (ts.Status || ts.status) === 'Rejected' ? '#fef2f2' : '#fef3c7',
                                        color: (ts.Status || ts.status) === 'Approved' ? '#10b981' : (ts.Status || ts.status) === 'Rejected' ? '#ef4444' : '#d97706'
                                    }}>
                                        {ts.Status || ts.status}
                                    </span>
                                </div>
                                <div style={{ fontSize: '13px', color: '#6b7280' }}>
                                    {ts.ApproverName || '—'}
                                </div>
                                <div style={{ display: 'flex', gap: '8px' }}>
                                    {(ts.Status || ts.status) === 'Pending' && (
                                        <>
                                            <button 
                                                onClick={() => handleApprove(ts.Id, ts.CompanyId)}
                                                style={{ padding: '6px', borderRadius: '6px', backgroundColor: '#ecfdf5', color: '#10b981', border: '1px solid #d1fae5', cursor: 'pointer' }}
                                                title="Approve"
                                            >
                                                <ThumbsUp size={16} />
                                            </button>
                                            <button 
                                                onClick={() => handleReject(ts.Id, ts.CompanyId)}
                                                style={{ padding: '6px', borderRadius: '6px', backgroundColor: '#fef2f2', color: '#ef4444', border: '1px solid #fee2e2', cursor: 'pointer' }}
                                                title="Reject"
                                            >
                                                <ThumbsDown size={16} />
                                            </button>
                                        </>
                                    )}
                                    {(ts.Status || ts.status) !== 'Pending' && (
                                        <span style={{ fontSize: '12px', color: '#9ca3af', fontStyle: 'italic' }}>Processed</span>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div style={{ padding: '60px', textAlign: 'center' }}>
                        <div style={{ backgroundColor: '#f3f4f6', width: '64px', height: '64px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                            <ClipboardList size={32} style={{ color: '#9ca3af' }} />
                        </div>
                        <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#374151' }}>No pending timesheets</h3>
                        <p style={{ color: '#6b7280', marginTop: '4px' }}>Everything is up to date!</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default TimeSheetApprovals;
