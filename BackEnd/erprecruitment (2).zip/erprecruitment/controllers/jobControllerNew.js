// BackEnd/erprecruitment/controllers/jobControllerNew.js

const { poolPromise, sql } = require("../../config/db");

/**
 * Generate unique job code
 */
const generateJobCode = async () => {
  const pool = await poolPromise;
  const result = await pool.request().query(`
    SELECT 'JOB-' + RIGHT('000000' + CAST(ISNULL(MAX(JobId), 0) + 1 AS VARCHAR(6)), 6) AS JobCode
    FROM recruit.Job
  `);
  return result.recordset[0].JobCode;
};

/**
 * Get user ID by username
 */
const getUserIdByUsername = async (username) => {
  if (!username) return null;
  const pool = await poolPromise;
  const result = await pool.request()
    .input("username", sql.NVarChar, username)
    .query(`SELECT id FROM userinfo WHERE username = @username`);
  return result.recordset.length > 0 ? result.recordset[0].id : null;
};

/**
 * Process location data
 */
const processLocation = (city, state, country, roleLocation) => {
  let location = '';
  if (roleLocation === 'Remote') {
    location = `Remote, ${country || ''}`;
  } else {
    const cityPart = city || '';
    const statePart = state || '';
    location = `${cityPart}${cityPart && statePart ? ', ' : ''}${statePart}${(cityPart || statePart) ? ', ' : ''}${country}`.trim();
    if (location === ',') location = country;
  }
  return location;
};

/**
 * Process visa types
 */
const processVisaTypes = (visaTypes) => {
  if (!visaTypes) return '';
  if (Array.isArray(visaTypes)) {
    return visaTypes.join(', ');
  }
  return visaTypes;
};

/**
 * CREATE JOB
 */
/**
 * CREATE JOB - Fixed with Region Handling
 */
const createJob = async (req, res) => {
  try {
    const pool = await poolPromise;
    
    const {
      title,
      jobId,
      gbamsId,
      roleType,
      country,
      state,
      city,
      currency,
      minRate,
      maxRate,
      client,
      clientPOC,
      roleLocation,
      experience,
      urgency,
      status,
      assignTo,
      assignedRecruiters,
      jobDescription,
      startDate,
      endDate,
      profilesNeeded,
      expensePaid,
      specialNotes,
      visaTypes,
      vendor,
      createdBy
    } = req.body;
    
    // Validation
    if (!title) {
      return res.status(400).json({ success: false, message: "Title is required" });
    }
    if (!client) {
      return res.status(400).json({ success: false, message: "Client is required" });
    }
    if (!country) {
      return res.status(400).json({ success: false, message: "Country is required" });
    }
    
    // ========== GET OR CREATE REGION ==========
    let regionId = null;
    
    try {
      // First, try to get an existing region
      const regionResult = await pool.request().query(`
        SELECT TOP 1 RegionId FROM core.Region WHERE IsActive = 1
      `);
      
      if (regionResult.recordset.length > 0) {
        regionId = regionResult.recordset[0].RegionId;
        console.log(`Using existing region: ${regionId}`);
      } else {
        // If no region exists, create a default one
        console.log('No regions found, creating default region...');
        
        const insertResult = await pool.request()
          .input("regionCode", sql.NVarChar, 'DEFAULT')
          .input("regionName", sql.NVarChar, 'Default Region')
          .input("isActive", sql.Bit, 1)
          .query(`
            INSERT INTO core.Region (RegionCode, RegionName, IsActive, CreatedAtUtc)
            VALUES (@regionCode, @regionName, @isActive, GETUTCDATE());
            SELECT SCOPE_IDENTITY() AS RegionId;
          `);
        
        regionId = insertResult.recordset[0].RegionId;
        console.log(`Created new region with ID: ${regionId}`);
      }
    } catch (regionError) {
      console.error('Error handling region:', regionError);
      return res.status(500).json({
        success: false,
        message: "Error setting up region. Please ensure core.Region table exists and has at least one record.",
        error: regionError.message
      });
    }
    
    // ========== GET OR CREATE TEAM ==========
    let assignedTeamId = null;
    
    try {
      const teamResult = await pool.request().query(`
        SELECT TOP 1 TeamId FROM core.Team WHERE IsActive = 1
      `);
      
      if (teamResult.recordset.length > 0) {
        assignedTeamId = teamResult.recordset[0].TeamId;
      } else {
        // Create default team
        const insertTeam = await pool.request()
          .input("teamCode", sql.NVarChar, 'DEFAULT')
          .input("teamName", sql.NVarChar, 'Default Team')
          .input("teamType", sql.NVarChar, 'GENERAL')
          .input("regionId", sql.Int, regionId)
          .query(`
            INSERT INTO core.Team (TeamCode, TeamName, TeamType, RegionId, IsActive, CreatedAtUtc)
            VALUES (@teamCode, @teamName, @teamType, @regionId, 1, GETUTCDATE());
            SELECT SCOPE_IDENTITY() AS TeamId;
          `);
        
        assignedTeamId = insertTeam.recordset[0].TeamId;
        console.log(`Created default team with ID: ${assignedTeamId}`);
      }
    } catch (teamError) {
      console.error('Error handling team:', teamError);
      assignedTeamId = null;
    }
    
    // Get Job Source - Use MANUAL
    let jobSourceId = 3;
    try {
      const sourceResult = await pool.request()
        .input("sourceCode", sql.NVarChar, 'MANUAL')
        .query(`SELECT JobSourceId FROM recruit.JobSource WHERE SourceCode = @sourceCode`);
      
      if (sourceResult.recordset.length > 0) {
        jobSourceId = sourceResult.recordset[0].JobSourceId;
      }
    } catch (err) {
      console.log('Using default job source ID: 3');
    }
    
    // Generate job code
    const jobCode = await generateJobCode();
    
    // Get user IDs
    const assignToUserId = await getUserIdByUsername(assignTo);
    let createdByUserId = await getUserIdByUsername(createdBy);
    if (!createdByUserId && req.user) {
      createdByUserId = await getUserIdByUsername(req.user.username);
    }
    
    // Process data
    const location = processLocation(city, state, country, roleLocation);
    const visaTypesString = processVisaTypes(visaTypes);
    
    // Map status
    let statusCode = 'OPEN';
    const legacyStatusLabel = status || 'Active';
    
    if (legacyStatusLabel === 'Active') statusCode = 'OPEN';
    else if (legacyStatusLabel === 'On Hold') statusCode = 'ON_HOLD';
    else if (legacyStatusLabel === 'Inactive') statusCode = 'CLOSED';
    else if (legacyStatusLabel === 'Cancelled') statusCode = 'CANCELLED';
    else if (legacyStatusLabel === 'Filled') statusCode = 'CLOSED';
    
    // Insert job
    const result = await pool.request()
      .input("jobCode", sql.NVarChar, jobCode)
      .input("externalJobReference", sql.NVarChar, jobId || null)
      .input("gbamsId", sql.NVarChar, gbamsId || null)
      .input("title", sql.NVarChar, title)
      .input("roleTypeCode", sql.NVarChar, roleType || 'Full-time')
      .input("statusCode", sql.NVarChar, statusCode)
      .input("legacyStatusLabel", sql.NVarChar, legacyStatusLabel)
      .input("workModeCode", sql.NVarChar, roleLocation || 'Onsite')
      .input("payRateMin", sql.Decimal(18, 2), minRate || 0)
      .input("payRateMax", sql.Decimal(18, 2), maxRate || 0)
      .input("currencyCode", sql.NVarChar, currency || 'USD')
      .input("startDate", sql.Date, startDate || null)
      .input("endDate", sql.Date, endDate || null)
      .input("positionsTotal", sql.Int, profilesNeeded || 1)
      .input("jobDescription", sql.NVarChar(sql.MAX), jobDescription || null)
      .input("specialNotes", sql.NVarChar(sql.MAX), specialNotes || null)
      .input("assignToUserName", sql.NVarChar, assignTo || null)
      .input("createdByUserId", sql.Int, createdByUserId)
      .input("createdByUserName", sql.NVarChar, req.user?.username || createdBy || 'System')
      .input("clientName", sql.NVarChar, client)
      .input("clientPOC", sql.NVarChar, clientPOC || null)
      .input("countryName", sql.NVarChar, country)
      .input("stateNames", sql.NVarChar, state || null)
      .input("cityNames", sql.NVarChar, city || null)
      .input("locationText", sql.NVarChar, location)
      .input("experienceText", sql.NVarChar, experience || null)
      .input("urgencyCode", sql.NVarChar, urgency || 'Normal')
      .input("expensePaid", sql.Bit, expensePaid || false)
      .input("visaTypes", sql.NVarChar, visaTypesString || null)
      .input("vendor", sql.NVarChar, vendor || null)
      .input("jobSourceId", sql.Int, jobSourceId)
      .input("regionId", sql.Int, regionId)  // Now this will NOT be NULL
      .input("assignedTeamId", sql.Int, assignedTeamId)
      .input("primaryRecruiterUserId", sql.Int, assignToUserId || createdByUserId)
      .input("isRestricted", sql.Bit, 0)
      .input("isInternalOnly", sql.Bit, 1)
      .input("allowCareersPublishing", sql.Bit, 0)
      .input("allowSocialPublishing", sql.Bit, 0)
      .query(`
        INSERT INTO recruit.Job (
          JobCode, ExternalJobReference, GBAMSId, Title, RoleTypeCode,
          StatusCode, LegacyStatusLabel, WorkModeCode, PayRateMin, PayRateMax, CurrencyCode,
          StartDate, EndDate, PositionsTotal, JobDescription, SpecialNotes, 
          AssignToUserName, CreatedByUserId, CreatedByUserName, 
          ClientName, ClientPOC, CountryName, StateNames, CityNames, LocationText, 
          ExperienceText, UrgencyCode, ExpensePaid, VisaTypes, Vendor,
          JobSourceId, RegionId, AssignedTeamId, PrimaryRecruiterUserId,
          IsRestricted, IsInternalOnly, AllowCareersPublishing, AllowSocialPublishing,
          CreatedAtUtc
        ) VALUES (
          @jobCode, @externalJobReference, @gbamsId, @title, @roleTypeCode,
          @statusCode, @legacyStatusLabel, @workModeCode, @payRateMin, @payRateMax, @currencyCode,
          @startDate, @endDate, @positionsTotal, @jobDescription, @specialNotes,
          @assignToUserName, @createdByUserId, @createdByUserName,
          @clientName, @clientPOC, @countryName, @stateNames, @cityNames, @locationText,
          @experienceText, @urgencyCode, @expensePaid, @visaTypes, @vendor,
          @jobSourceId, @regionId, @assignedTeamId, @primaryRecruiterUserId,
          @isRestricted, @isInternalOnly, @allowCareersPublishing, @allowSocialPublishing,
          GETUTCDATE()
        );
        SELECT SCOPE_IDENTITY() AS newId;
      `);
    
    const newJobId = result.recordset[0].newId;
    
    // Generate system ID
    const systemId = `JOB-${newJobId.toString().padStart(5, '0')}`;
    await pool.request()
      .input("jobId", sql.Int, newJobId)
      .input("systemId", sql.NVarChar, systemId)
      .query(`UPDATE recruit.Job SET SystemId = @systemId WHERE JobId = @jobId`);
    
    // Assign recruiters if provided
    if (assignedRecruiters && assignedRecruiters.length > 0) {
      const assignedByUserName = req.user?.username || 'System';
      
      for (const recruiterId of assignedRecruiters) {
        const recruiterResult = await pool.request()
          .input("userId", sql.Int, recruiterId)
          .query(`SELECT username FROM userinfo WHERE id = @userId`);
        
        const recruiterName = recruiterResult.recordset.length > 0 
          ? recruiterResult.recordset[0].username 
          : null;
        
        if (recruiterName) {
          await pool.request()
            .input("jobId", sql.Int, newJobId)
            .input("userName", sql.NVarChar, recruiterName)
            .input("assignedByUserName", sql.NVarChar, assignedByUserName)
            .input("assignmentRoleCode", sql.NVarChar, 'SECONDARY')
            .input("createdByUserName", sql.NVarChar, assignedByUserName)
            .query(`
              INSERT INTO recruit.JobRecruiterAssignment (
                JobId, UserName, AssignmentRoleCode, AssignedAtUtc, 
                AssignedByUserName, IsActive, CreatedByUserName, CreatedAtUtc
              ) VALUES (
                @jobId, @userName, @assignmentRoleCode, GETUTCDATE(),
                @assignedByUserName, 1, @createdByUserName, GETUTCDATE()
              )
            `);
        }
      }
    }
    
    res.status(201).json({
      success: true,
      message: "Job created successfully",
      jobId: newJobId,
      jobCode: jobCode,
      systemId: systemId
    });
    
  } catch (error) {
    console.error("Error creating job:", error);
    res.status(500).json({
      success: false,
      message: "Server error while creating job",
      error: error.message
    });
  }
};
/**
 * GET ALL JOBS
 */
const getAllJobs = async (req, res) => {
  try {
    const pool = await poolPromise;
    const { status, client, assignTo, limit = 100, offset = 0 } = req.query;
    
    let query = `
      SELECT 
        JobId, JobCode, SystemId, Title, RoleTypeCode, LegacyStatusLabel AS StatusCode,
        WorkModeCode, ClientName AS Client, ClientPOC, CountryName AS Country, 
        StateNames AS State, CityNames AS City, LocationText AS Location, 
        ExperienceText AS Experience, UrgencyCode AS Urgency, AssignToUserName AS AssignTo, 
        Vendor, PayRateMin, PayRateMax, CurrencyCode, StartDate, EndDate, 
        PositionsTotal AS ProfilesNeeded, ExpensePaid, VisaTypes, JobDescription,
        CreatedAtUtc, CreatedByUserName
      FROM recruit.Job
      WHERE 1=1
    `;
    
    const request = pool.request();
    
    if (status) {
      query += ` AND LegacyStatusLabel = @status`;
      request.input("status", sql.NVarChar, status);
    }
    
    if (client) {
      query += ` AND ClientName LIKE @client`;
      request.input("client", sql.NVarChar, `%${client}%`);
    }
    
    if (assignTo) {
      query += ` AND AssignToUserName = @assignTo`;
      request.input("assignTo", sql.NVarChar, assignTo);
    }
    
    query += ` ORDER BY CreatedAtUtc DESC OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY`;
    request.input("offset", sql.Int, parseInt(offset));
    request.input("limit", sql.Int, parseInt(limit));
    
    const result = await request.query(query);
    
    const countResult = await pool.request().query(`
      SELECT COUNT(*) AS TotalCount FROM recruit.Job
    `);
    
    res.status(200).json({
      success: true,
      data: result.recordset,
      pagination: {
        total: countResult.recordset[0].TotalCount,
        limit: parseInt(limit),
        offset: parseInt(offset)
      }
    });
    
  } catch (error) {
    console.error("Error fetching jobs:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching jobs",
      error: error.message
    });
  }
};

/**
 * GET JOB BY ID
 */
const getJobById = async (req, res) => {
  try {
    const jobId = req.params.id;
    const pool = await poolPromise;
    
    const result = await pool.request()
      .input("jobId", sql.Int, jobId)
      .query(`
        SELECT 
          JobId, JobCode, SystemId, Title, RoleTypeCode, LegacyStatusLabel AS StatusCode,
          WorkModeCode, ClientName AS Client, ClientPOC, CountryName AS Country, 
          StateNames AS State, CityNames AS City, LocationText AS Location, 
          ExperienceText AS Experience, UrgencyCode AS Urgency, AssignToUserName AS AssignTo, 
          Vendor, PayRateMin, PayRateMax, CurrencyCode, StartDate, EndDate, 
          PositionsTotal AS ProfilesNeeded, ExpensePaid, VisaTypes, JobDescription,
          SpecialNotes, CreatedAtUtc, CreatedByUserName, UpdatedAtUtc
        FROM recruit.Job
        WHERE JobId = @jobId
      `);
    
    if (result.recordset.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Job not found"
      });
    }
    
    res.status(200).json({
      success: true,
      data: result.recordset[0]
    });
    
  } catch (error) {
    console.error("Error fetching job:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching job",
      error: error.message
    });
  }
};

/**
 * UPDATE JOB
 */
const updateJob = async (req, res) => {
  try {
    const jobId = req.params.id;
    const pool = await poolPromise;
    
    // Check if job exists
    const existingJob = await pool.request()
      .input("jobId", sql.Int, jobId)
      .query(`SELECT JobId FROM recruit.Job WHERE JobId = @jobId`);
    
    if (existingJob.recordset.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Job not found"
      });
    }
    
    const {
      title,
      jobId: externalJobId,
      gbamsId,
      roleType,
      country,
      state,
      city,
      currency,
      minRate,
      maxRate,
      client,
      clientPOC,
      roleLocation,
      experience,
      urgency,
      status,
      assignTo,
      jobDescription,
      startDate,
      endDate,
      profilesNeeded,
      expensePaid,
      specialNotes,
      visaTypes,
      vendor
    } = req.body;
    
    // Process data
    const location = processLocation(city, state, country, roleLocation);
    const visaTypesString = processVisaTypes(visaTypes);
    const updatedByUserName = req.user?.username || 'System';
    
    // Build dynamic update query
    const updateFields = [];
    const request = pool.request();
    
    if (title !== undefined) {
      updateFields.push("Title = @title");
      request.input("title", sql.NVarChar, title);
    }
    if (externalJobId !== undefined) {
      updateFields.push("ExternalJobReference = @externalJobReference");
      request.input("externalJobReference", sql.NVarChar, externalJobId);
    }
    if (gbamsId !== undefined) {
      updateFields.push("GBAMSId = @gbamsId");
      request.input("gbamsId", sql.NVarChar, gbamsId);
    }
    if (roleType !== undefined) {
      updateFields.push("RoleTypeCode = @roleTypeCode");
      request.input("roleTypeCode", sql.NVarChar, roleType);
    }
    if (country !== undefined) {
      updateFields.push("CountryName = @countryName");
      request.input("countryName", sql.NVarChar, country);
    }
    if (state !== undefined) {
      updateFields.push("StateNames = @stateNames");
      request.input("stateNames", sql.NVarChar, state);
    }
    if (city !== undefined) {
      updateFields.push("CityNames = @cityNames");
      request.input("cityNames", sql.NVarChar, city);
    }
    if (currency !== undefined) {
      updateFields.push("CurrencyCode = @currencyCode");
      request.input("currencyCode", sql.NVarChar, currency);
    }
    if (minRate !== undefined) {
      updateFields.push("PayRateMin = @payRateMin");
      request.input("payRateMin", sql.Decimal(18, 2), minRate);
    }
    if (maxRate !== undefined) {
      updateFields.push("PayRateMax = @payRateMax");
      request.input("payRateMax", sql.Decimal(18, 2), maxRate);
    }
    if (client !== undefined) {
      updateFields.push("ClientName = @clientName");
      request.input("clientName", sql.NVarChar, client);
    }
    if (clientPOC !== undefined) {
      updateFields.push("ClientPOC = @clientPOC");
      request.input("clientPOC", sql.NVarChar, clientPOC);
    }
    if (roleLocation !== undefined) {
      updateFields.push("WorkModeCode = @workModeCode");
      request.input("workModeCode", sql.NVarChar, roleLocation);
    }
    if (experience !== undefined) {
      updateFields.push("ExperienceText = @experienceText");
      request.input("experienceText", sql.NVarChar, experience);
    }
    if (urgency !== undefined) {
      updateFields.push("UrgencyCode = @urgencyCode");
      request.input("urgencyCode", sql.NVarChar, urgency);
    }
    if (status !== undefined) {
      let newStatusCode = 'OPEN';
      if (status === 'Active') newStatusCode = 'OPEN';
      else if (status === 'On Hold') newStatusCode = 'ON_HOLD';
      else if (status === 'Inactive') newStatusCode = 'CLOSED';
      else if (status === 'Cancelled') newStatusCode = 'CANCELLED';
      else if (status === 'Filled') newStatusCode = 'CLOSED';
      
      updateFields.push("LegacyStatusLabel = @legacyStatusLabel");
      updateFields.push("StatusCode = @statusCode");
      request.input("legacyStatusLabel", sql.NVarChar, status);
      request.input("statusCode", sql.NVarChar, newStatusCode);
    }
    if (assignTo !== undefined) {
      updateFields.push("AssignToUserName = @assignToUserName");
      request.input("assignToUserName", sql.NVarChar, assignTo);
    }
    if (jobDescription !== undefined) {
      updateFields.push("JobDescription = @jobDescription");
      request.input("jobDescription", sql.NVarChar(sql.MAX), jobDescription);
    }
    if (startDate !== undefined) {
      updateFields.push("StartDate = @startDate");
      request.input("startDate", sql.Date, startDate);
    }
    if (endDate !== undefined) {
      updateFields.push("EndDate = @endDate");
      request.input("endDate", sql.Date, endDate);
    }
    if (profilesNeeded !== undefined) {
      updateFields.push("PositionsTotal = @positionsTotal");
      request.input("positionsTotal", sql.Int, profilesNeeded);
    }
    if (expensePaid !== undefined) {
      updateFields.push("ExpensePaid = @expensePaid");
      request.input("expensePaid", sql.Bit, expensePaid);
    }
    if (specialNotes !== undefined) {
      updateFields.push("SpecialNotes = @specialNotes");
      request.input("specialNotes", sql.NVarChar(sql.MAX), specialNotes);
    }
    if (visaTypes !== undefined) {
      updateFields.push("VisaTypes = @visaTypes");
      request.input("visaTypes", sql.NVarChar, visaTypesString);
    }
    if (vendor !== undefined) {
      updateFields.push("Vendor = @vendor");
      request.input("vendor", sql.NVarChar, vendor);
    }
    if (location) {
      updateFields.push("LocationText = @locationText");
      request.input("locationText", sql.NVarChar, location);
    }
    
    if (updateFields.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No fields to update"
      });
    }
    
    updateFields.push("UpdatedAtUtc = GETUTCDATE()");
    updateFields.push("UpdatedByUserName = @updatedByUserName");
    request.input("updatedByUserName", sql.NVarChar, updatedByUserName);
    request.input("jobId", sql.Int, jobId);
    
    const updateQuery = `
      UPDATE recruit.Job 
      SET ${updateFields.join(", ")}
      WHERE JobId = @jobId
    `;
    
    await request.query(updateQuery);
    
    res.status(200).json({
      success: true,
      message: "Job updated successfully",
      jobId: parseInt(jobId)
    });
    
  } catch (error) {
    console.error("Error updating job:", error);
    res.status(500).json({
      success: false,
      message: "Server error while updating job",
      error: error.message
    });
  }
};

/**
 * DELETE JOB
 */
const deleteJob = async (req, res) => {
  const jobId = req.params.id;
  const forceDelete = req.query.force === 'true';
  
  try {
    const pool = await poolPromise;
    
    // Check if user has permission
    if (req.user.role !== 'manager' && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: "Only managers and admins can delete jobs"
      });
    }
    
    // Check if job exists
    const jobCheck = await pool.request()
      .input("jobId", sql.Int, jobId)
      .query(`
        SELECT JobId, Title, JobCode FROM recruit.Job WHERE JobId = @jobId
      `);
    
    if (jobCheck.recordset.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Job not found"
      });
    }
    
    const job = jobCheck.recordset[0];
    
    // Check if there are any submissions
    const submissionCheck = await pool.request()
      .input("jobId", sql.Int, jobId)
      .query("SELECT COUNT(*) as count FROM recruit.Submission WHERE JobId = @jobId");
    
    const submissionCount = submissionCheck.recordset[0].count;
    
    if (submissionCount > 0 && !forceDelete) {
      return res.status(409).json({
        success: false,
        message: `Cannot delete job with ${submissionCount} existing submission(s). Use force=true to delete with submissions.`
      });
    }
    
    // Begin transaction
    const transaction = new sql.Transaction(pool);
    
    try {
      await transaction.begin();
      
      // Delete submissions if forceDelete
      if (forceDelete && submissionCount > 0) {
        // Get all submission IDs
        const submissionsResult = await transaction.request()
          .input("jobId", sql.Int, jobId)
          .query("SELECT SubmissionId FROM recruit.Submission WHERE JobId = @jobId");
        
        for (const sub of submissionsResult.recordset) {
          await transaction.request()
            .input("submissionId", sql.Int, sub.SubmissionId)
            .query("DELETE FROM recruit.SubmissionResume WHERE SubmissionId = @submissionId");
          
          await transaction.request()
            .input("submissionId", sql.Int, sub.SubmissionId)
            .query("DELETE FROM recruit.SubmissionStatusHistory WHERE SubmissionId = @submissionId");
          
          await transaction.request()
            .input("submissionId", sql.Int, sub.SubmissionId)
            .query("DELETE FROM recruit.SubmissionOwnerHistory WHERE SubmissionId = @submissionId");
          
          await transaction.request()
            .input("submissionId", sql.Int, sub.SubmissionId)
            .query("DELETE FROM recruit.SubmissionClientEvent WHERE SubmissionId = @submissionId");
        }
        
        await transaction.request()
          .input("jobId", sql.Int, jobId)
          .query("DELETE FROM recruit.Submission WHERE JobId = @jobId");
      }
      
      // Delete job assignments
      await transaction.request()
        .input("jobId", sql.Int, jobId)
        .query("DELETE FROM recruit.JobRecruiterAssignment WHERE JobId = @jobId");
      
      // Delete job status history
      await transaction.request()
        .input("jobId", sql.Int, jobId)
        .query("DELETE FROM recruit.JobStatusHistory WHERE JobId = @jobId");
      
      // Delete the job
      await transaction.request()
        .input("jobId", sql.Int, jobId)
        .query("DELETE FROM recruit.Job WHERE JobId = @jobId");
      
      await transaction.commit();
      
      res.status(200).json({
        success: true,
        message: forceDelete ?
          "Job and all associated submissions deleted successfully" :
          "Job deleted successfully",
        deletedJob: {
          id: job.JobId,
          jobCode: job.JobCode,
          title: job.Title
        },
        deletedBy: req.user.username
      });
      
    } catch (transactionError) {
      await transaction.rollback();
      throw transactionError;
    }
    
  } catch (error) {
    console.error("Error deleting job:", error);
    res.status(500).json({
      success: false,
      message: "Server error while deleting job",
      error: error.message
    });
  }
};

/**
 * UPDATE JOB STATUS
 */
const updateJobStatus = async (req, res) => {
  try {
    const jobId = req.params.id;
    const { status, reason } = req.body;
    const pool = await poolPromise;
    
    if (!status) {
      return res.status(400).json({
        success: false,
        message: "Status is required"
      });
    }
    
    // Check if job exists
    const jobCheck = await pool.request()
      .input("jobId", sql.Int, jobId)
      .query(`
        SELECT JobId, Title, LegacyStatusLabel FROM recruit.Job WHERE JobId = @jobId
      `);
    
    if (jobCheck.recordset.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Job not found"
      });
    }
    
    const job = jobCheck.recordset[0];
    const oldStatus = job.LegacyStatusLabel;
    
    if (oldStatus === status) {
      return res.status(200).json({
        success: true,
        message: "Status unchanged",
        currentStatus: status
      });
    }
    
    // Map status to StatusCode
    let statusCode = 'OPEN';
    if (status === 'Active') statusCode = 'OPEN';
    else if (status === 'On Hold') statusCode = 'ON_HOLD';
    else if (status === 'Inactive') statusCode = 'CLOSED';
    else if (status === 'Cancelled') statusCode = 'CANCELLED';
    else if (status === 'Filled') statusCode = 'CLOSED';
    
    const transaction = new sql.Transaction(pool);
    
    try {
      await transaction.begin();
      
      // Update job status
      await transaction.request()
        .input("jobId", sql.Int, jobId)
        .input("legacyStatusLabel", sql.NVarChar, status)
        .input("statusCode", sql.NVarChar, statusCode)
        .input("updatedByUserName", sql.NVarChar, req.user?.username || 'System')
        .query(`
          UPDATE recruit.Job
          SET LegacyStatusLabel = @legacyStatusLabel,
              StatusCode = @statusCode,
              UpdatedAtUtc = GETUTCDATE(),
              UpdatedByUserName = @updatedByUserName
          WHERE JobId = @jobId
        `);
      
      // Record status change in history
      await transaction.request()
        .input("jobId", sql.Int, jobId)
        .input("fromStatusCode", sql.NVarChar, oldStatus)
        .input("toStatusCode", sql.NVarChar, status)
        .input("changedByUserName", sql.NVarChar, req.user?.username || 'System')
        .input("reasonText", sql.NVarChar, reason || null)
        .query(`
          INSERT INTO recruit.JobStatusHistory (
            JobId, FromStatusCode, ToStatusCode, ChangedAtUtc,
            ChangedByUserName, ReasonText
          ) VALUES (
            @jobId, @fromStatusCode, @toStatusCode, GETUTCDATE(),
            @changedByUserName, @reasonText
          )
        `);
      
      await transaction.commit();
      
      res.status(200).json({
        success: true,
        message: "Job status updated successfully",
        jobId: parseInt(jobId),
        oldStatus: oldStatus,
        newStatus: status
      });
      
    } catch (transactionError) {
      await transaction.rollback();
      throw transactionError;
    }
    
  } catch (error) {
    console.error("Error updating job status:", error);
    res.status(500).json({
      success: false,
      message: "Server error while updating job status",
      error: error.message
    });
  }
};

/**
 * GET JOB STATUS HISTORY
 */
const getJobStatusHistory = async (req, res) => {
  try {
    const jobId = req.params.id;
    const pool = await poolPromise;
    
    const result = await pool.request()
      .input("jobId", sql.Int, jobId)
      .query(`
        SELECT 
          JobStatusHistoryId,
          FromStatusCode,
          ToStatusCode,
          ChangedAtUtc,
          ChangedByUserName,
          ReasonText
        FROM recruit.JobStatusHistory
        WHERE JobId = @jobId
        ORDER BY ChangedAtUtc DESC
      `);
    
    res.status(200).json({
      success: true,
      data: result.recordset
    });
    
  } catch (error) {
    console.error("Error fetching job status history:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching job history",
      error: error.message
    });
  }
};

// EXPORT ALL FUNCTIONS
module.exports = {
  createJob,
  getAllJobs,
  getJobById,
  updateJob,
  deleteJob,
  updateJobStatus,
  getJobStatusHistory
};