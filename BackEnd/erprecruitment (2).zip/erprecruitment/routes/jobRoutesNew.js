// BackEnd/erprecruitment/routes/jobRoutesNew.js

const express = require("express");
const router = express.Router();
const {
  createJob,
  getAllJobs,
  getJobById,
  updateJob,
  deleteJob,
  getJobStatusHistory,
  updateJobStatus
} = require("../controllers/jobControllerNew");
const { authenticateToken } = require("../../Recruitment/middleWare/authMiddleware");

/**
 * @swagger
 * tags:
 *   name: Jobs
 *   description: Job management API
 */

/**
 * @swagger
 * components:
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 *   schemas:
 *     JobInput:
 *       type: object
 *       required:
 *         - title
 *         - client
 *         - country
 *       properties:
 *         title:
 *           type: string
 *           example: "Senior Frontend Developer"
 *         jobId:
 *           type: string
 *           example: "REQ-001"
 *         gbamsId:
 *           type: string
 *           example: "GBAMS-12345"
 *         roleType:
 *           type: string
 *           enum: ["Full-time", "Part-time", "Contract", "C2C"]
 *           example: "Full-time"
 *         country:
 *           type: string
 *           example: "United States"
 *         state:
 *           type: string
 *           example: "Texas"
 *         city:
 *           type: string
 *           example: "Austin"
 *         currency:
 *           type: string
 *           enum: ["USD", "INR", "CAD", "EUR", "GBP"]
 *           example: "USD"
 *         minRate:
 *           type: number
 *           example: 50
 *         maxRate:
 *           type: number
 *           example: 75
 *         client:
 *           type: string
 *           example: "TechCorp Inc"
 *         clientPOC:
 *           type: string
 *           example: "John Smith"
 *         roleLocation:
 *           type: string
 *           enum: ["Onsite", "Remote", "Hybrid"]
 *           example: "Remote"
 *         experience:
 *           type: string
 *           example: "5-8 years"
 *         urgency:
 *           type: string
 *           enum: ["Normal", "High", "Medium", "Low"]
 *           example: "High"
 *         status:
 *           type: string
 *           enum: ["Active", "Inactive", "On Hold", "Cancelled", "Filled"]
 *           example: "Active"
 *         assignTo:
 *           type: string
 *           example: "recruiter1"
 *         assignedRecruiters:
 *           type: array
 *           items:
 *             type: integer
 *           example: [1, 2, 3]
 *         jobDescription:
 *           type: string
 *           example: "<ul><li>Develop React applications</li></ul>"
 *         startDate:
 *           type: string
 *           format: date
 *           example: "2024-04-01"
 *         endDate:
 *           type: string
 *           format: date
 *           example: "2024-12-31"
 *         profilesNeeded:
 *           type: integer
 *           example: 2
 *         expensePaid:
 *           type: boolean
 *           example: false
 *         specialNotes:
 *           type: string
 *           example: "Need immediate joiners"
 *         visaTypes:
 *           type: array
 *           items:
 *             type: string
 *           example: ["H1B", "Green Card"]
 *         vendor:
 *           type: string
 *           example: "Vendor Name"
 *         createdBy:
 *           type: string
 *           example: "admin"
 *     
 *     JobUpdateInput:
 *       type: object
 *       properties:
 *         title:
 *           type: string
 *         client:
 *           type: string
 *         status:
 *           type: string
 *           enum: ["Active", "Inactive", "On Hold", "Cancelled", "Filled"]
 *     
 *     JobOutput:
 *       type: object
 *       properties:
 *         JobId:
 *           type: integer
 *         JobCode:
 *           type: string
 *         Title:
 *           type: string
 *         Client:
 *           type: string
 *         StatusCode:
 *           type: string
 *         CreatedAtUtc:
 *           type: string
 *           format: date-time
 *     
 *     JobDetailOutput:
 *       type: object
 *       properties:
 *         JobId:
 *           type: integer
 *         JobCode:
 *           type: string
 *         SystemId:
 *           type: string
 *         Title:
 *           type: string
 *         EmploymentTypeCode:
 *           type: string
 *         StatusCode:
 *           type: string
 *         WorkModeCode:
 *           type: string
 *         Client:
 *           type: string
 *         ClientPOC:
 *           type: string
 *         Country:
 *           type: string
 *         State:
 *           type: string
 *         City:
 *           type: string
 *         Location:
 *           type: string
 *         Experience:
 *           type: string
 *         Urgency:
 *           type: string
 *         AssignTo:
 *           type: string
 *         Vendor:
 *           type: string
 *         PayRateMin:
 *           type: number
 *         PayRateMax:
 *           type: number
 *         CurrencyCode:
 *           type: string
 *         TargetStartDate:
 *           type: string
 *           format: date
 *         TargetEndDate:
 *           type: string
 *           format: date
 *         PositionsTotal:
 *           type: integer
 *         ProfilesNeeded:
 *           type: integer
 *         ExpensePaid:
 *           type: boolean
 *         VisaTypes:
 *           type: string
 *         JobDescription:
 *           type: string
 *         AssignedRecruiters:
 *           type: array
 *           items:
 *             type: object
 *         RecentSubmissions:
 *           type: array
 *           items:
 *             type: object
 *     
 *     StatusUpdateInput:
 *       type: object
 *       required:
 *         - status
 *       properties:
 *         status:
 *           type: string
 *           enum: ["Active", "Inactive", "On Hold", "Cancelled", "Filled"]
 *         reason:
 *           type: string
 *           example: "Position filled"
 */

// All routes require authentication
router.use(authenticateToken);

/**
 * @swagger
 * /api/jobs:
 *   post:
 *     summary: Create a new job
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/JobInput'
 *     responses:
 *       201:
 *         description: Job created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 message:
 *                   type: string
 *                 jobId:
 *                   type: integer
 *                 jobCode:
 *                   type: string
 *                 systemId:
 *                   type: string
 *       400:
 *         description: Validation error
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.post("/", createJob);

/**
 * @swagger
 * /api/jobs:
 *   get:
 *     summary: Get all jobs with pagination and filters
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *         description: Filter by job status
 *       - in: query
 *         name: client
 *         schema:
 *           type: string
 *         description: Filter by client name
 *       - in: query
 *         name: assignTo
 *         schema:
 *           type: string
 *         description: Filter by assigned recruiter
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 100
 *         description: Number of records per page
 *       - in: query
 *         name: offset
 *         schema:
 *           type: integer
 *           default: 0
 *         description: Pagination offset
 *     responses:
 *       200:
 *         description: List of jobs with pagination
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/JobOutput'
 *                 pagination:
 *                   type: object
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.get("/", getAllJobs);

/**
 * @swagger
 * /api/jobs/{id}:
 *   get:
 *     summary: Get job by ID with full details
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Job ID
 *     responses:
 *       200:
 *         description: Job details with assigned recruiters and recent submissions
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/JobDetailOutput'
 *       404:
 *         description: Job not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.get("/:id", getJobById);

/**
 * @swagger
 * /api/jobs/{id}:
 *   put:
 *     summary: Update an existing job
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Job ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/JobInput'
 *     responses:
 *       200:
 *         description: Job updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 message:
 *                   type: string
 *                 jobId:
 *                   type: integer
 *       404:
 *         description: Job not found
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden - insufficient permissions
 *       500:
 *         description: Server error
 */
router.put("/:id", updateJob);

/**
 * @swagger
 * /api/jobs/{id}:
 *   delete:
 *     summary: Delete a job
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Job ID
 *       - in: query
 *         name: force
 *         schema:
 *           type: boolean
 *           default: false
 *         description: Force delete with all associated submissions
 *     responses:
 *       200:
 *         description: Job deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 message:
 *                   type: string
 *                 deletedJob:
 *                   type: object
 *       404:
 *         description: Job not found
 *       403:
 *         description: Forbidden - only managers and admins can delete
 *       409:
 *         description: Conflict - job has submissions, use force=true
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.delete("/:id", deleteJob);

/**
 * @swagger
 * /api/jobs/{id}/status:
 *   patch:
 *     summary: Update job status only
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Job ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/StatusUpdateInput'
 *     responses:
 *       200:
 *         description: Job status updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 message:
 *                   type: string
 *                 jobId:
 *                   type: integer
 *                 oldStatus:
 *                   type: string
 *                 newStatus:
 *                   type: string
 *       404:
 *         description: Job not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.patch("/:id/status", updateJobStatus);

/**
 * @swagger
 * /api/jobs/{id}/history:
 *   get:
 *     summary: Get job status change history
 *     tags: [Jobs]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Job ID
 *     responses:
 *       200:
 *         description: Status history
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       FromStatusCode:
 *                         type: string
 *                       ToStatusCode:
 *                         type: string
 *                       ChangedAtUtc:
 *                         type: string
 *                       ChangedByUserName:
 *                         type: string
 *                       ReasonText:
 *                         type: string
 *       404:
 *         description: Job not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.get("/:id/history", getJobStatusHistory);

module.exports = router;