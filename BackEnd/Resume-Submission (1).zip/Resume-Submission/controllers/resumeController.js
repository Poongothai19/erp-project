const { poolPromise, sql } = require("../../config/db");
const path = require("path");
const fs = require('fs');
const mammoth = require('mammoth');
const https = require('https');

// ─── Helpers ──────────────────────────────────────────────────────────────────

const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

const getUsernameFromRequest = (req) => {
  if (req.user) {
    return req.user.username || req.user.name || req.user.email ||
           req.user.Username || req.user.Name || req.user.Email || 'Unknown User';
  }
  return 'Unknown User';
};

// Convert DOC/DOCX buffer to HTML for preview
const convertDocumentToHtml = async (buffer, fileType) => {
  try {
    if (
      fileType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
      fileType === 'application/msword'
    ) {
      const result = await mammoth.convertToHtml({ buffer });
      return { success: true, html: result.value, messages: result.messages };
    }
    return { success: false, error: 'Unsupported document type' };
  } catch (error) {
    console.error('Document conversion error:', error);
    return { success: false, error: error.message };
  }
};

// ─── GET ALL CANDIDATES (list view) ──────────────────────────────────────────

exports.getAllResumes = async (req, res) => {
  try {
    const pool = await poolPromise;

    const result = await pool.request().query(`
      SELECT
        c.CandidateId,
        c.CandidateCode,
        c.FirstName,
        c.MiddleName,
        c.LastName,
        c.DateOfBirth,
        c.Phone,
        c.Mobile,
        c.JobTitle,
        c.YearsOfExperience,
        c.CandidateStatus,
        c.WorkAuthorization,
        c.SecurityClearance,
        c.WillingToRelocate,
        c.RemoteStatus,
        c.EmploymentType,
        c.ExpectedRateFrom,
        c.ExpectedRateTo,
        c.ExpectedRateType,
        c.CurrentRate,
        c.CurrentRateType,
        c.Gender,
        c.MaritalStatus,
        c.Industry,
        c.ProfileSummary,
        c.LinkedInUrl,
        c.GitHubUrl,
        c.TwitterUrl,
        c.VideoResumeUrl,
        c.CreatedOn,
        c.ModifiedOn,
        -- primary email
        ci_email.IdentityValue  AS Email,
        -- primary document info (without binary data)
        d.DocumentId,
        d.FileNameOriginal,
        d.FileExtension,
        d.MimeType,
        d.FileSizeBytes,
        d.ParseStatus,
        d.UploadedOn,
        loc.CityName,
        loc.StateCode,
        loc.CountryName,
        loc.CountryIso2
      FROM [Jobpost].[recruit].[Candidate] c
      LEFT JOIN (
        SELECT CandidateId, IdentityValue
        FROM [Jobpost].[recruit].[CandidateIdentity]
        WHERE IdentityType = 'Email' AND IsPrimary = 1
      ) ci_email ON ci_email.CandidateId = c.CandidateId
      LEFT JOIN (
        SELECT CandidateId, DocumentId, FileNameOriginal, FileExtension,
               MimeType, FileSizeBytes, ParseStatus, UploadedOn,
               ROW_NUMBER() OVER (PARTITION BY CandidateId ORDER BY IsPrimaryResume DESC, UploadedOn DESC) rn
        FROM [Jobpost].[recruit].[CandidateDocument]
        WHERE IsDeleted = 0
      ) d ON d.CandidateId = c.CandidateId AND d.rn = 1
      LEFT JOIN (
        SELECT ea.EntityId,
               city.Name AS CityName,
               state.Code AS StateCode,
               country.Name AS CountryName,
               country.Iso2 AS CountryIso2,
               ROW_NUMBER() OVER(PARTITION BY ea.EntityId ORDER BY ea.IsPrimary DESC, ea.CreatedOn DESC) as rn
        FROM [Jobpost].[core].[EntityAddress] ea
        INNER JOIN [Jobpost].[core].[Address] a ON ea.AddressId = a.AddressId
        LEFT JOIN [Jobpost].[core].[City] city ON a.CityId = city.CityId
        LEFT JOIN [Jobpost].[core].[StateProvince] state ON city.StateId = state.StateId
        LEFT JOIN [Jobpost].[core].[Country] country ON state.CountryId = country.CountryId
        WHERE ea.EntityType = 'Candidate'
      ) loc ON loc.EntityId = c.CandidateId AND loc.rn = 1
      WHERE c.IsDeleted = 0
      ORDER BY c.CreatedOn DESC
    `);

    // Fetch all skills in a single query and group by CandidateId
    const skillsResult = await pool.request().query(`
      SELECT cs.CandidateId, s.SkillName
      FROM [Jobpost].[recruit].[CandidateSkill] cs
      INNER JOIN [Jobpost].[recruit].[Skill] s ON s.SkillId = cs.SkillId
    `);

    const skillsMap = {};
    for (const row of skillsResult.recordset) {
      if (!skillsMap[row.CandidateId]) skillsMap[row.CandidateId] = [];
      skillsMap[row.CandidateId].push(row.SkillName);
    }

    // Build the response
    const candidates = result.recordset.map(c => ({
      candidate_id:         c.CandidateId,
      candidate_code:       c.CandidateCode,
      first_name:           c.FirstName,
      middle_name:          c.MiddleName,
      last_name:            c.LastName,
      date_of_birth:        c.DateOfBirth,
      phone:                c.Phone || c.Mobile,
      mobile:               c.Mobile || '',
      job_title:            c.JobTitle,
      years_exp:            c.YearsOfExperience,
      status:               c.CandidateStatus,
      work_authorization:   c.WorkAuthorization,
      security_clearance:   c.SecurityClearance,
      willing_to_relocate:  c.WillingToRelocate,
      remote_status:        c.RemoteStatus,
      employment_type:      c.EmploymentType,
      expected_rate_from:   c.ExpectedRateFrom,
      expected_rate_to:     c.ExpectedRateTo,
      expected_rate_type:   c.ExpectedRateType,
      current_rate:         c.CurrentRate,
      current_rate_type:    c.CurrentRateType,
      gender:               c.Gender,
      marital_status:       c.MaritalStatus,
      industry:             c.Industry,
      profile_summary:      c.ProfileSummary,
      linkedin_url:         c.LinkedInUrl,
      github_url:           c.GitHubUrl,
      twitter_url:          c.TwitterUrl || '',
      video_resume_url:     c.VideoResumeUrl || '',
      created_on:           c.CreatedOn,
      modified_on:          c.ModifiedOn,
      current_location:     c.CurrentLocation || (c.CityName ? [c.CityName, c.StateCode, c.CountryIso2].filter(Boolean).join(', ') : ''),
      email:                c.Email,
      skills:               (skillsMap[c.CandidateId] || []),
      document: c.DocumentId ? {
        DocumentId:       c.DocumentId,
        FileNameOriginal: c.FileNameOriginal,
        FileExtension:    c.FileExtension,
        MimeType:         c.MimeType,
        FileSizeBytes:    c.FileSizeBytes,
        ParseStatus:      c.ParseStatus,
        UploadedOn:       c.UploadedOn,
      } : null,
    }));

    console.log(`Returning ${candidates.length} candidates`);
    res.status(200).json(candidates);

  } catch (error) {
    console.error("DB error in getAllResumes:", error.message);
    res.status(500).json({
      success: false,
      error: "Could not fetch candidates",
      details: process.env.NODE_ENV === 'development' ? error.message : undefined,
      data: []
    });
  }
};

// ─── GET SINGLE CANDIDATE BY ID (full detail) ───────────────────────────────

exports.getResumeById = async (req, res) => {
  const { id } = req.params;

  if (!id || isNaN(parseInt(id))) {
    return res.status(400).json({ success: false, error: "Invalid candidate ID" });
  }

  const candidateId = parseInt(id);

  try {
    const pool = await poolPromise;

    // 1) Candidate
    const cResult = await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        SELECT *
        FROM [Jobpost].[recruit].[Candidate]
        WHERE CandidateId = @CandidateId AND IsDeleted = 0
      `);

    if (!cResult.recordset.length) {
      return res.status(404).json({ success: false, error: "Candidate not found" });
    }
    const c = cResult.recordset[0];

    // 1.5) Location
    const locResult = await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        SELECT TOP 1
               city.Name AS CityName,
               state.Code AS StateCode,
               country.Name AS CountryName,
               country.Iso2 AS CountryIso2
        FROM [Jobpost].[core].[EntityAddress] ea
        INNER JOIN [Jobpost].[core].[Address] a ON ea.AddressId = a.AddressId
        LEFT JOIN [Jobpost].[core].[City] city ON a.CityId = city.CityId
        LEFT JOIN [Jobpost].[core].[StateProvince] state ON city.StateId = state.StateId
        LEFT JOIN [Jobpost].[core].[Country] country ON state.CountryId = country.CountryId
        WHERE ea.EntityType = 'Candidate' AND ea.EntityId = @CandidateId
        ORDER BY ea.IsPrimary DESC, ea.CreatedOn DESC
      `);
    const loc = locResult.recordset.length ? locResult.recordset[0] : null;
    if (loc) {
      c.CityName    = loc.CityName;
      c.StateCode   = loc.StateCode;
      c.CountryName = loc.CountryName;
      c.CountryIso2 = loc.CountryIso2;
    }

    // 2) Identity (email / phone)
    const idResult = await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        SELECT IdentityType, IdentityValue, IsPrimary
        FROM [Jobpost].[recruit].[CandidateIdentity]
        WHERE CandidateId = @CandidateId
      `);

    const primaryEmail = idResult.recordset.find(i => i.IdentityType === 'Email' && i.IsPrimary);
    const primaryPhone = idResult.recordset.find(i => i.IdentityType === 'Phone' && i.IsPrimary);
    // Collect ALL phones (from identity table + candidate table)
    const allPhones = idResult.recordset
      .filter(i => i.IdentityType === 'Phone')
      .map(i => i.IdentityValue);
    // Also include Phone/Mobile from Candidate table if not already listed
    if (c.Phone && !allPhones.includes(c.Phone)) allPhones.unshift(c.Phone);
    if (c.Mobile && c.Mobile !== c.Phone && !allPhones.includes(c.Mobile)) allPhones.push(c.Mobile);
    // Collect ALL emails
    const allEmails = idResult.recordset
      .filter(i => i.IdentityType === 'Email')
      .map(i => i.IdentityValue);

    // 3) Skills
    const skillsResult = await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        SELECT s.SkillId, s.SkillName
        FROM [Jobpost].[recruit].[CandidateSkill] cs
        INNER JOIN [Jobpost].[recruit].[Skill] s ON s.SkillId = cs.SkillId
        WHERE cs.CandidateId = @CandidateId
      `);

    // 4) Education
    const eduResult = await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        SELECT EducationId, Institution, Degree, FieldOfStudy, StartDate, EndDate, GPA, Notes
        FROM [Jobpost].[recruit].[CandidateEducation]
        WHERE CandidateId = @CandidateId
      `);

    // 5) Work Experience
    const workResult = await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        SELECT WorkExperienceId, Company, JobTitle, StartDate, EndDate, IsCurrent, Description
        FROM [Jobpost].[recruit].[CandidateWorkExperience]
        WHERE CandidateId = @CandidateId
      `);

    // 6) Certifications
    const certResult = await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        SELECT CertificationId, CertificationName, IssuingOrganization,
               IssueDate, ExpiryDate, CredentialId, CredentialUrl
        FROM [Jobpost].[recruit].[CandidateCertification]
        WHERE CandidateId = @CandidateId
      `);

    // 7) ALL Documents (not just primary — return every version)
    const docResult = await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        SELECT DocumentId, DocumentType, VersionNo, IsPrimaryResume,
               FileNameOriginal, FileExtension, MimeType, FileSizeBytes,
               StorageProvider, StorageLocator, ParseStatus, UploadedOn
        FROM [Jobpost].[recruit].[CandidateDocument]
        WHERE CandidateId = @CandidateId AND IsDeleted = 0
        ORDER BY IsPrimaryResume DESC, UploadedOn DESC
      `);

    const primaryDoc = docResult.recordset.length ? docResult.recordset[0] : null;
    const allDocuments = docResult.recordset.map(d => ({
      DocumentId:       d.DocumentId,
      DocumentType:     d.DocumentType,
      FileNameOriginal: d.FileNameOriginal,
      FileExtension:    d.FileExtension,
      MimeType:         d.MimeType,
      FileSizeBytes:    d.FileSizeBytes,
      StorageLocator:   d.StorageLocator,
      ParseStatus:      d.ParseStatus,
      UploadedOn:       d.UploadedOn,
      VersionNo:        d.VersionNo,
      IsPrimary:        d.IsPrimaryResume,
    }));

    // Build response
    const candidate = {
      candidate_id:         c.CandidateId,
      candidate_code:       c.CandidateCode,
      first_name:           c.FirstName,
      middle_name:          c.MiddleName,
      last_name:            c.LastName,
      date_of_birth:        c.DateOfBirth,
      phone:                primaryPhone?.IdentityValue || c.Phone || c.Mobile,
      phones:               allPhones,
      email:                primaryEmail?.IdentityValue || '',
      emails:               allEmails,
      job_title:            c.JobTitle,
      years_exp:            c.YearsOfExperience,
      status:               c.CandidateStatus,
      work_authorization:   c.WorkAuthorization,
      security_clearance:   c.SecurityClearance,
      willing_to_relocate:  c.WillingToRelocate,
      remote_status:        c.RemoteStatus,
      employment_type:      c.EmploymentType,
      expected_rate_from:   c.ExpectedRateFrom,
      expected_rate_to:     c.ExpectedRateTo,
      expected_rate_type:   c.ExpectedRateType,
      current_rate:         c.CurrentRate,
      current_rate_type:    c.CurrentRateType,
      gender:               c.Gender,
      marital_status:       c.MaritalStatus,
      industry:             c.Industry,
      profile_summary:      c.ProfileSummary,
      linkedin_url:         c.LinkedInUrl,
      github_url:           c.GitHubUrl,
      twitter_url:          c.TwitterUrl || '',
      video_resume_url:     c.VideoResumeUrl || '',
      created_on:           c.CreatedOn,
      modified_on:          c.ModifiedOn,
      current_location:     c.CurrentLocation || (c.CityName ? [c.CityName, c.StateCode, c.CountryIso2].filter(Boolean).join(', ') : ''),

      skills: skillsResult.recordset.map(s => ({
        skill_name: s.SkillName,
        skill_id:   s.SkillId,
      })),
      education: eduResult.recordset.map(e => ({
        EducationId:  e.EducationId,
        Institution:  e.Institution,
        Degree:       e.Degree,
        FieldOfStudy: e.FieldOfStudy,
        StartDate:    e.StartDate,
        EndDate:      e.EndDate,
        GPA:          e.GPA,
        Notes:        e.Notes,
      })),
      work_experience: workResult.recordset.map(w => ({
        WorkExperienceId: w.WorkExperienceId,
        Company:          w.Company,
        JobTitle:         w.JobTitle,
        StartDate:        w.StartDate,
        EndDate:          w.EndDate,
        IsCurrent:        w.IsCurrent,
        Description:      w.Description,
      })),
      certifications: certResult.recordset.map(ct => ({
        CertificationId:    ct.CertificationId,
        CertificationName:  ct.CertificationName,
        IssuingOrganization: ct.IssuingOrganization,
        IssueDate:          ct.IssueDate,
        ExpiryDate:         ct.ExpiryDate,
        CredentialId:       ct.CredentialId,
        CredentialUrl:      ct.CredentialUrl,
      })),
      // Primary document (backwards compat)
      document: primaryDoc ? {
        DocumentId:       primaryDoc.DocumentId,
        FileNameOriginal: primaryDoc.FileNameOriginal,
        FileExtension:    primaryDoc.FileExtension,
        MimeType:         primaryDoc.MimeType,
        FileSizeBytes:    primaryDoc.FileSizeBytes,
        StorageLocator:   primaryDoc.StorageLocator,
        ParseStatus:      primaryDoc.ParseStatus,
        UploadedOn:       primaryDoc.UploadedOn,
      } : null,
      // ALL documents (for multi-resume display)
      documents: allDocuments,
    };

    res.status(200).json(candidate);

  } catch (error) {
    console.error("DB error in getResumeById:", error);
    res.status(500).json({
      success: false,
      error: "Could not fetch candidate",
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// ─── CREATE CANDIDATE ────────────────────────────────────────────────────────

exports.createResume = async (req, res) => {
  console.log('=== Create Candidate Request ===');
  let transaction;

  try {
    const pool = await poolPromise;
    transaction = new sql.Transaction(pool);
    await transaction.begin();

    const {
      FirstName, LastName, MiddleName, EmailID,
      Phone, Mobile, JobTitle, YearsOfExperience,
      CandidateStatus, WorkAuthorization, SecurityClearance,
      WillingToRelocate, RemoteStatus, EmploymentType,
      ExpectedRateFrom, ExpectedRateTo, ExpectedRateType,
      CurrentRate, CurrentRateType, Gender, MaritalStatus,
      Industry, ProfileSummary, LinkedInProfile, GitHubUrl,
      TwitterUrl, VideoResumeUrl,
      Dob,
      Skills, Education, WorkExperience, Certifications, CurrentLocation
    } = req.body;

    // Validate required fields
    if (!FirstName || !LastName) {
      await transaction.rollback();
      return res.status(400).json({ success: false, error: "FirstName and LastName are required" });
    }

    // Parse DOB
    let dobValue = null;
    if (Dob && String(Dob).trim() !== '') {
      dobValue = new Date(Dob);
      if (isNaN(dobValue)) dobValue = null;
    }

    // Parse boolean values
    const willingToRelocate = WillingToRelocate === 'true' || WillingToRelocate === true ? 1 : 0;

    // Parse numeric values
    const yearsExp = YearsOfExperience ? parseFloat(YearsOfExperience) : null;
    const expectedRateFrom = ExpectedRateFrom ? parseFloat(ExpectedRateFrom) : null;
    const expectedRateTo = ExpectedRateTo ? parseFloat(ExpectedRateTo) : null;
    const currentRate = CurrentRate ? parseFloat(CurrentRate) : null;

    // ────────────────────────────────────────────────────────────
    // CHECK FOR EXISTING CANDIDATE BY EMAIL
    // ────────────────────────────────────────────────────────────
    let existingCandidateId = null;
    let existingCandidateCode = null;
    const emailTrimmed = EmailID?.trim();

    if (emailTrimmed) {
      const dupCheck = await new sql.Request(transaction)
        .input('Email', sql.NVarChar(255), emailTrimmed)
        .query(`
          SELECT TOP 1 c.CandidateId, c.CandidateCode
          FROM [Jobpost].[recruit].[CandidateIdentity] ci
          INNER JOIN [Jobpost].[recruit].[Candidate] c ON ci.CandidateId = c.CandidateId
          WHERE ci.IdentityType = 'Email'
            AND ci.IdentityValue = @Email
            AND c.IsDeleted = 0
          ORDER BY c.CandidateId ASC
        `);

      if (dupCheck.recordset.length > 0) {
        existingCandidateId = dupCheck.recordset[0].CandidateId;
        existingCandidateCode = dupCheck.recordset[0].CandidateCode;
        console.log(`🔄 Duplicate detected — email "${emailTrimmed}" already belongs to ${existingCandidateCode} (ID: ${existingCandidateId})`);
      }
    }

    // ────────────────────────────────────────────────────────────
    // PATH A: EXISTING CANDIDATE — merge data + add new resume
    // ────────────────────────────────────────────────────────────
    if (existingCandidateId) {
      const candidateId = existingCandidateId;

      // A1) Fill only NULL fields — never overwrite existing data
      await new sql.Request(transaction)
        .input('CandidateId',           sql.Int,            candidateId)
        .input('FirstName',             sql.NVarChar(100),  FirstName.trim())
        .input('MiddleName',            sql.NVarChar(100),  MiddleName?.trim() || null)
        .input('LastName',              sql.NVarChar(100),  LastName.trim())
        .input('DateOfBirth',           sql.Date,           dobValue)
        .input('Phone',                 sql.NVarChar(50),   Phone?.trim() || null)
        .input('Mobile',                sql.NVarChar(50),   Mobile?.trim() || null)
        .input('JobTitle',              sql.NVarChar(200),  JobTitle?.trim() || null)
        .input('YearsOfExperience',     sql.Decimal(5,1),   yearsExp)
        .input('CandidateStatus',       sql.NVarChar(50),   CandidateStatus || 'Available')
        .input('WorkAuthorization',     sql.NVarChar(50),   WorkAuthorization || null)
        .input('SecurityClearance',     sql.NVarChar(50),   SecurityClearance || null)
        .input('WillingToRelocate',     sql.Bit,            willingToRelocate)
        .input('RemoteStatus',          sql.NVarChar(50),   RemoteStatus || null)
        .input('EmploymentType',        sql.NVarChar(50),   EmploymentType || null)
        .input('ExpectedRateFrom',      sql.Decimal(18,2),  expectedRateFrom)
        .input('ExpectedRateTo',        sql.Decimal(18,2),  expectedRateTo)
        .input('ExpectedRateType',      sql.NVarChar(20),   ExpectedRateType || null)
        .input('CurrentRate',           sql.Decimal(18,2),  currentRate)
        .input('CurrentRateType',       sql.NVarChar(20),   CurrentRateType || null)
        .input('Gender',                sql.NVarChar(20),   Gender || null)
        .input('MaritalStatus',         sql.NVarChar(20),   MaritalStatus || null)
        .input('Industry',              sql.NVarChar(100),  Industry || null)
        .input('ProfileSummary',        sql.NVarChar(sql.MAX), ProfileSummary?.trim() || null)
        .input('LinkedInUrl',           sql.NVarChar(500),  LinkedInProfile?.trim() || null)
        .input('GitHubUrl',             sql.NVarChar(500),  GitHubUrl?.trim() || null)
        .input('TwitterUrl',            sql.NVarChar(500),  TwitterUrl?.trim() || null)
        .input('VideoResumeUrl',        sql.NVarChar(500),  VideoResumeUrl?.trim() || null)
        .query(`
          UPDATE [Jobpost].[recruit].[Candidate] SET
            FirstName           = ISNULL(FirstName,           @FirstName),
            MiddleName          = ISNULL(MiddleName,          @MiddleName),
            LastName            = ISNULL(LastName,            @LastName),
            DateOfBirth         = ISNULL(DateOfBirth,         @DateOfBirth),
            Phone               = ISNULL(Phone,               @Phone),
            Mobile              = ISNULL(Mobile,              @Mobile),
            JobTitle            = ISNULL(JobTitle,            @JobTitle),
            YearsOfExperience   = ISNULL(YearsOfExperience,   @YearsOfExperience),
            CandidateStatus     = ISNULL(CandidateStatus,     @CandidateStatus),
            WorkAuthorization   = ISNULL(WorkAuthorization,   @WorkAuthorization),
            SecurityClearance   = ISNULL(SecurityClearance,   @SecurityClearance),
            WillingToRelocate   = ISNULL(WillingToRelocate,   @WillingToRelocate),
            RemoteStatus        = ISNULL(RemoteStatus,        @RemoteStatus),
            EmploymentType      = ISNULL(EmploymentType,      @EmploymentType),
            ExpectedRateFrom    = ISNULL(ExpectedRateFrom,    @ExpectedRateFrom),
            ExpectedRateTo      = ISNULL(ExpectedRateTo,      @ExpectedRateTo),
            ExpectedRateType    = ISNULL(ExpectedRateType,    @ExpectedRateType),
            CurrentRate         = ISNULL(CurrentRate,         @CurrentRate),
            CurrentRateType     = ISNULL(CurrentRateType,     @CurrentRateType),
            Gender              = ISNULL(Gender,              @Gender),
            MaritalStatus       = ISNULL(MaritalStatus,       @MaritalStatus),
            Industry            = ISNULL(Industry,            @Industry),
            ProfileSummary      = ISNULL(ProfileSummary,      @ProfileSummary),
            LinkedInUrl         = ISNULL(LinkedInUrl,         @LinkedInUrl),
            GitHubUrl           = ISNULL(GitHubUrl,           @GitHubUrl),
            TwitterUrl          = ISNULL(TwitterUrl,          @TwitterUrl),
            VideoResumeUrl      = ISNULL(VideoResumeUrl,      @VideoResumeUrl)
          WHERE CandidateId = @CandidateId
        `);

      // A1b) Add new phone/mobile as identity records (don't replace existing)
      const newPhone = Phone?.trim();
      const newMobile = Mobile?.trim();

      if (newPhone) {
        const phoneExists = await new sql.Request(transaction)
          .input('CandidateId', sql.Int, candidateId)
          .input('IdentityValue', sql.NVarChar(255), newPhone)
          .query(`
            SELECT TOP 1 1 AS Found FROM [Jobpost].[recruit].[CandidateIdentity]
            WHERE CandidateId = @CandidateId AND IdentityType = 'Phone' AND IdentityValue = @IdentityValue
          `);
        if (phoneExists.recordset.length === 0) {
          await new sql.Request(transaction)
            .input('CandidateId',   sql.Int,            candidateId)
            .input('IdentityType',  sql.NVarChar(50),   'Phone')
            .input('IdentityValue', sql.NVarChar(255),  newPhone)
            .input('IsPrimary',     sql.Bit,            0)
            .input('IsVerified',    sql.Bit,            0)
            .query(`
              INSERT INTO [Jobpost].[recruit].[CandidateIdentity]
                (CandidateId, IdentityType, IdentityValue, IsPrimary, IsVerified, CreatedOn)
              VALUES
                (@CandidateId, @IdentityType, @IdentityValue, @IsPrimary, @IsVerified, GETDATE())
            `);
          console.log(`📞 New phone identity added: ${newPhone}`);
        }
      }

      if (newMobile && newMobile !== newPhone) {
        const mobileExists = await new sql.Request(transaction)
          .input('CandidateId', sql.Int, candidateId)
          .input('IdentityValue', sql.NVarChar(255), newMobile)
          .query(`
            SELECT TOP 1 1 AS Found FROM [Jobpost].[recruit].[CandidateIdentity]
            WHERE CandidateId = @CandidateId AND IdentityType = 'Phone' AND IdentityValue = @IdentityValue
          `);
        if (mobileExists.recordset.length === 0) {
          await new sql.Request(transaction)
            .input('CandidateId',   sql.Int,            candidateId)
            .input('IdentityType',  sql.NVarChar(50),   'Phone')
            .input('IdentityValue', sql.NVarChar(255),  newMobile)
            .input('IsPrimary',     sql.Bit,            0)
            .input('IsVerified',    sql.Bit,            0)
            .query(`
              INSERT INTO [Jobpost].[recruit].[CandidateIdentity]
                (CandidateId, IdentityType, IdentityValue, IsPrimary, IsVerified, CreatedOn)
              VALUES
                (@CandidateId, @IdentityType, @IdentityValue, @IsPrimary, @IsVerified, GETDATE())
            `);
          console.log(`📱 New mobile identity added: ${newMobile}`);
        }
      }

      // A2) Merge Skills (add only new ones, keep existing)
      const skillsList = parseJsonField(Skills);
      for (const skillName of skillsList) {
        if (!skillName || !String(skillName).trim()) continue;
        const name = String(skillName).trim();

        const skillRes = await new sql.Request(transaction)
          .input('SkillName', sql.NVarChar(200), name)
          .query(`
            IF NOT EXISTS (SELECT 1 FROM [Jobpost].[recruit].[Skill] WHERE SkillName = @SkillName)
              INSERT INTO [Jobpost].[recruit].[Skill] (SkillName) VALUES (@SkillName);
            SELECT SkillId FROM [Jobpost].[recruit].[Skill] WHERE SkillName = @SkillName;
          `);
        const skillId = skillRes.recordset[0].SkillId;

        await new sql.Request(transaction)
          .input('CandidateId', sql.Int, candidateId)
          .input('SkillId', sql.Int, skillId)
          .query(`
            IF NOT EXISTS (
              SELECT 1 FROM [Jobpost].[recruit].[CandidateSkill]
              WHERE CandidateId = @CandidateId AND SkillId = @SkillId
            )
            INSERT INTO [Jobpost].[recruit].[CandidateSkill] (CandidateId, SkillId)
            VALUES (@CandidateId, @SkillId)
          `);
      }

      // A3) Append Education (skip if exact same institution+degree already exists)
      const eduList = parseJsonField(Education);
      for (const edu of eduList) {
        if (!edu || typeof edu !== 'object') continue;
        const inst = edu.Institution || edu.institution || '';
        const deg = edu.Degree || edu.degree || '';
        if (!inst && !deg) continue;

        const exists = await new sql.Request(transaction)
          .input('CandidateId', sql.Int, candidateId)
          .input('Institution', sql.NVarChar(200), inst)
          .input('Degree',      sql.NVarChar(200), deg)
          .query(`
            SELECT TOP 1 1 AS Found FROM [Jobpost].[recruit].[CandidateEducation]
            WHERE CandidateId = @CandidateId
              AND ISNULL(Institution,'') = ISNULL(@Institution,'')
              AND ISNULL(Degree,'') = ISNULL(@Degree,'')
          `);
        if (exists.recordset.length > 0) continue;

        await new sql.Request(transaction)
          .input('CandidateId',  sql.Int,            candidateId)
          .input('Institution',  sql.NVarChar(200),  inst || null)
          .input('Degree',       sql.NVarChar(200),  deg || null)
          .input('FieldOfStudy', sql.NVarChar(200),  edu.FieldOfStudy || edu.fieldOfStudy || null)
          .input('StartDate',    sql.Date,           parseDate(edu.StartDate || edu.startDate))
          .input('EndDate',      sql.Date,           parseDate(edu.EndDate   || edu.endDate))
          .input('GPA',          sql.NVarChar(20),   edu.GPA || edu.gpa || null)
          .input('Notes',        sql.NVarChar(sql.MAX), edu.Notes || edu.notes || null)
          .query(`
            INSERT INTO [Jobpost].[recruit].[CandidateEducation]
              (CandidateId, Institution, Degree, FieldOfStudy, StartDate, EndDate, GPA, Notes)
            VALUES
              (@CandidateId, @Institution, @Degree, @FieldOfStudy, @StartDate, @EndDate, @GPA, @Notes)
          `);
      }

      // A4) Append Work Experience (skip if same company+jobTitle already exists)
      const workList = parseJsonField(WorkExperience);
      for (const w of workList) {
        if (!w || typeof w !== 'object') continue;
        const company = w.Company || w.company || '';
        const jobT = w.JobTitle || w.jobTitle || '';
        if (!company && !jobT) continue;

        const exists = await new sql.Request(transaction)
          .input('CandidateId', sql.Int, candidateId)
          .input('Company',     sql.NVarChar(200), company)
          .input('JobTitle',    sql.NVarChar(200), jobT)
          .query(`
            SELECT TOP 1 1 AS Found FROM [Jobpost].[recruit].[CandidateWorkExperience]
            WHERE CandidateId = @CandidateId
              AND ISNULL(Company,'') = ISNULL(@Company,'')
              AND ISNULL(JobTitle,'') = ISNULL(@JobTitle,'')
          `);
        if (exists.recordset.length > 0) continue;

        await new sql.Request(transaction)
          .input('CandidateId',  sql.Int,            candidateId)
          .input('Company',      sql.NVarChar(200),  company || null)
          .input('JobTitle',     sql.NVarChar(200),  jobT || null)
          .input('StartDate',    sql.Date,           parseDate(w.StartDate || w.startDate))
          .input('EndDate',      sql.Date,           parseDate(w.EndDate   || w.endDate))
          .input('IsCurrent',    sql.Bit,            w.IsCurrent ?? w.isCurrent ?? 0)
          .input('Description',  sql.NVarChar(sql.MAX), w.Description || w.description || null)
          .query(`
            INSERT INTO [Jobpost].[recruit].[CandidateWorkExperience]
              (CandidateId, Company, JobTitle, StartDate, EndDate, IsCurrent, Description)
            VALUES
              (@CandidateId, @Company, @JobTitle, @StartDate, @EndDate, @IsCurrent, @Description)
          `);
      }

      // A5) Append Certifications (skip if same name already exists)
      const certList = parseJsonField(Certifications);
      for (const cert of certList) {
        if (!cert || typeof cert !== 'object') continue;
        const certName = cert.CertificationName || cert.name || '';
        if (!certName) continue;

        const exists = await new sql.Request(transaction)
          .input('CandidateId',       sql.Int, candidateId)
          .input('CertificationName', sql.NVarChar(200), certName)
          .query(`
            SELECT TOP 1 1 AS Found FROM [Jobpost].[recruit].[CandidateCertification]
            WHERE CandidateId = @CandidateId
              AND ISNULL(CertificationName,'') = ISNULL(@CertificationName,'')
          `);
        if (exists.recordset.length > 0) continue;

        await new sql.Request(transaction)
          .input('CandidateId',         sql.Int,            candidateId)
          .input('CertificationName',   sql.NVarChar(200),  certName)
          .input('IssuingOrganization', sql.NVarChar(200),  cert.IssuingOrganization || cert.issuingOrg || null)
          .input('IssueDate',           sql.Date,           parseDate(cert.IssueDate  || cert.issueDate))
          .input('ExpiryDate',          sql.Date,           parseDate(cert.ExpiryDate || cert.expiryDate))
          .input('CredentialId',        sql.NVarChar(100),  cert.CredentialId || cert.credentialId || null)
          .input('CredentialUrl',       sql.NVarChar(500),  cert.CredentialUrl || cert.credentialUrl || null)
          .query(`
            INSERT INTO [Jobpost].[recruit].[CandidateCertification]
              (CandidateId, CertificationName, IssuingOrganization, IssueDate, ExpiryDate, CredentialId, CredentialUrl)
            VALUES
              (@CandidateId, @CertificationName, @IssuingOrganization, @IssueDate, @ExpiryDate, @CredentialId, @CredentialUrl)
          `);
      }

      // A6) Add new Resume as a new VERSION (don't replace old ones)
      if (req.file && req.file.buffer) {
        // Mark existing primary resumes as non-primary
        await new sql.Request(transaction)
          .input('CandidateId', sql.Int, candidateId)
          .query(`
            UPDATE [Jobpost].[recruit].[CandidateDocument]
            SET IsPrimaryResume = 0
            WHERE CandidateId = @CandidateId AND IsPrimaryResume = 1
          `);

        // Get next version number
        const versionRes = await new sql.Request(transaction)
          .input('CandidateId', sql.Int, candidateId)
          .query(`SELECT ISNULL(MAX(VersionNo), 0) + 1 AS NextVer FROM [Jobpost].[recruit].[CandidateDocument] WHERE CandidateId = @CandidateId`);
        const nextVer = versionRes.recordset[0].NextVer;

        const ext = path.extname(req.file.originalname).toLowerCase();
        await new sql.Request(transaction)
          .input('CandidateId',      sql.Int,            candidateId)
          .input('DocumentType',     sql.NVarChar(50),   'Resume')
          .input('VersionNo',        sql.Int,            nextVer)
          .input('IsPrimaryResume',  sql.Bit,            1)
          .input('FileNameOriginal', sql.NVarChar(255),  req.file.originalname)
          .input('FileExtension',    sql.NVarChar(10),   ext)
          .input('MimeType',         sql.NVarChar(100),  req.file.mimetype)
          .input('FileSizeBytes',    sql.BigInt,         req.file.buffer.length)
          .input('StorageProvider',  sql.NVarChar(50),   'DATABASE')
          .input('StorageLocator',   sql.NVarChar(500),  'inline')
          .input('StorageRegion',    sql.NVarChar(50),   'local')
          .input('ResumeFileData',   sql.VarBinary(sql.MAX), req.file.buffer)
          .input('IsDeleted',        sql.Bit,            0)
          .query(`
            INSERT INTO [Jobpost].[recruit].[CandidateDocument] (
              CandidateId, DocumentType, VersionNo, IsPrimaryResume,
              FileNameOriginal, FileExtension, MimeType, FileSizeBytes,
              StorageProvider, StorageLocator, StorageRegion,
              ResumeFileData, UploadedOn, IsDeleted
            ) VALUES (
              @CandidateId, @DocumentType, @VersionNo, @IsPrimaryResume,
              @FileNameOriginal, @FileExtension, @MimeType, @FileSizeBytes,
              @StorageProvider, @StorageLocator, @StorageRegion,
              @ResumeFileData, GETDATE(), @IsDeleted
            )
          `);
        console.log(`📎 New resume v${nextVer} added to existing candidate ${existingCandidateCode}`);
      }

      // A7) Handle Additional Documents
      const additionalDocsCount = parseInt(req.body.AdditionalDocsCount || '0', 10);
      for (let i = 0; i < additionalDocsCount; i++) {
        const docFile = req.files && req.files[`AdditionalDoc_${i}`] && req.files[`AdditionalDoc_${i}`][0]
          ? req.files[`AdditionalDoc_${i}`][0]
          : null;
        const docName = req.body[`AdditionalDoc_${i}_Name`] || null;
        const docType = req.body[`AdditionalDoc_${i}_Type`] || 'Certificate';

        if (docFile && docFile.buffer) {
          const ext = path.extname(docFile.originalname).toLowerCase();
          console.log(`📎 Inserting additional document ${i}:`, docFile.originalname, 'Type:', docType);
          await new sql.Request(transaction)
            .input('CandidateId',      sql.Int,            candidateId)
            .input('DocumentType',     sql.NVarChar(50),   docType)
            .input('VersionNo',        sql.Int,            1)
            .input('IsPrimaryResume',  sql.Bit,            0)
            .input('FileNameOriginal', sql.NVarChar(255),  docName || docFile.originalname)
            .input('FileExtension',    sql.NVarChar(10),   ext)
            .input('MimeType',         sql.NVarChar(100),  docFile.mimetype)
            .input('FileSizeBytes',    sql.BigInt,         docFile.buffer.length)
            .input('StorageProvider',  sql.NVarChar(50),   'DATABASE')
            .input('StorageLocator',   sql.NVarChar(500),  'inline')
            .input('StorageRegion',    sql.NVarChar(50),   'local')
            .input('ResumeFileData',   sql.VarBinary(sql.MAX), docFile.buffer)
            .input('IsDeleted',        sql.Bit,            0)
            .query(`
              INSERT INTO [Jobpost].[recruit].[CandidateDocument] (
                CandidateId, DocumentType, VersionNo, IsPrimaryResume,
                FileNameOriginal, FileExtension, MimeType, FileSizeBytes,
                StorageProvider, StorageLocator, StorageRegion,
                ResumeFileData, UploadedOn, IsDeleted
              ) VALUES (
                @CandidateId, @DocumentType, @VersionNo, @IsPrimaryResume,
                @FileNameOriginal, @FileExtension, @MimeType, @FileSizeBytes,
                @StorageProvider, @StorageLocator, @StorageRegion,
                @ResumeFileData, GETDATE(), @IsDeleted
              )
            `);
        }
      }

      // ────────────────────────────────────────────────────────────
      // 📍 HANDLE CURRENT LOCATION (core.EntityAddress) - IMPROVED
      // ────────────────────────────────────────────────────────────
      const locString = (CurrentLocation || '').trim();
      if (locString) {
        await handleLocationUpdate(transaction, candidateId, locString);
      }

      await transaction.commit();
      transaction = null;

      console.log(`✅ Existing candidate ${existingCandidateCode} updated (merged duplicate)`);

      return res.status(200).json({
        success: true,
        merged: true,
        message: `Candidate already exists with this email. Profile updated and new resume added as version.`,
        CandidateId: candidateId,
        CandidateCode: existingCandidateCode,
      });
    }

    // ────────────────────────────────────────────────────────────
    // PATH B: NEW CANDIDATE — create from scratch
    // ────────────────────────────────────────────────────────────

    // Generate CandidateCode
    const codeResult = await new sql.Request(transaction).query(`
      SELECT ISNULL(MAX(CandidateId), 0) + 1 AS NextId FROM [Jobpost].[recruit].[Candidate]
    `);
    const nextId = codeResult.recordset[0].NextId;
    const candidateCode = `CAN-${String(nextId).padStart(6, '0')}`;

    // B1) Insert Candidate
    const insertResult = await new sql.Request(transaction)
      .input('CandidateCode',        sql.NVarChar(50),    candidateCode)
      .input('FirstName',            sql.NVarChar(100),   FirstName.trim())
      .input('MiddleName',           sql.NVarChar(100),   MiddleName?.trim() || null)
      .input('LastName',             sql.NVarChar(100),   LastName.trim())
      .input('DateOfBirth',          sql.Date,            dobValue)
      .input('Phone',                sql.NVarChar(50),    Phone?.trim() || null)
      .input('Mobile',               sql.NVarChar(50),    Mobile?.trim() || null)
      .input('WhatsAppEnabled',      sql.Bit,             0)
      .input('JobTitle',             sql.NVarChar(200),   JobTitle?.trim() || null)
      .input('YearsOfExperience',    sql.Decimal(5,1),    yearsExp)
      .input('CandidateStatus',      sql.NVarChar(50),    CandidateStatus || 'Available')
      .input('WorkAuthorization',    sql.NVarChar(50),    WorkAuthorization || null)
      .input('SecurityClearance',    sql.NVarChar(50),    SecurityClearance || null)
      .input('WillingToRelocate',    sql.Bit,             willingToRelocate)
      .input('RemoteStatus',         sql.NVarChar(50),    RemoteStatus || 'Remote')
      .input('EmploymentType',       sql.NVarChar(50),    EmploymentType || null)
      .input('ExpectedRateFrom',     sql.Decimal(18,2),   expectedRateFrom)
      .input('ExpectedRateTo',       sql.Decimal(18,2),   expectedRateTo)
      .input('ExpectedRateType',     sql.NVarChar(20),    ExpectedRateType || 'Hourly')
      .input('CurrentRate',          sql.Decimal(18,2),   currentRate)
      .input('CurrentRateType',      sql.NVarChar(20),    CurrentRateType || 'Hourly')
      .input('Gender',               sql.NVarChar(20),    Gender || null)
      .input('MaritalStatus',        sql.NVarChar(20),    MaritalStatus || null)
      .input('Industry',             sql.NVarChar(100),   Industry || null)
      .input('ProfileSummary',       sql.NVarChar(sql.MAX), ProfileSummary?.trim() || null)
      .input('LinkedInUrl',          sql.NVarChar(500),   LinkedInProfile?.trim() || null)
      .input('GitHubUrl',            sql.NVarChar(500),   GitHubUrl?.trim() || null)
      .input('TwitterUrl',           sql.NVarChar(500),   TwitterUrl?.trim() || null)
      .input('VideoResumeUrl',       sql.NVarChar(500),   VideoResumeUrl?.trim() || null)
      .input('IsDeleted',            sql.Bit,             0)
      .query(`
        INSERT INTO [Jobpost].[recruit].[Candidate] (
          CandidateCode, FirstName, MiddleName, LastName, DateOfBirth,
          Phone, Mobile, WhatsAppEnabled, JobTitle, YearsOfExperience,
          CandidateStatus, WorkAuthorization, SecurityClearance, WillingToRelocate,
          RemoteStatus, EmploymentType, ExpectedRateFrom, ExpectedRateTo,
          ExpectedRateType, CurrentRate, CurrentRateType,
          Gender, MaritalStatus, Industry, ProfileSummary,
          LinkedInUrl, GitHubUrl, TwitterUrl, VideoResumeUrl, CreatedOn, IsDeleted
        ) VALUES (
          @CandidateCode, @FirstName, @MiddleName, @LastName, @DateOfBirth,
          @Phone, @Mobile, @WhatsAppEnabled, @JobTitle, @YearsOfExperience,
          @CandidateStatus, @WorkAuthorization, @SecurityClearance, @WillingToRelocate,
          @RemoteStatus, @EmploymentType, @ExpectedRateFrom, @ExpectedRateTo,
          @ExpectedRateType, @CurrentRate, @CurrentRateType,
          @Gender, @MaritalStatus, @Industry, @ProfileSummary,
          @LinkedInUrl, @GitHubUrl, @TwitterUrl, @VideoResumeUrl, GETDATE(), @IsDeleted
        );
        SELECT SCOPE_IDENTITY() AS CandidateId;
      `);

    const candidateId = insertResult.recordset[0].CandidateId;

    // B2) Insert primary email identity
    if (emailTrimmed) {
      await new sql.Request(transaction)
        .input('CandidateId',  sql.Int,            candidateId)
        .input('IdentityType', sql.NVarChar(50),   'Email')
        .input('IdentityValue', sql.NVarChar(255), emailTrimmed)
        .input('IsPrimary',    sql.Bit,            1)
        .input('IsVerified',   sql.Bit,            0)
        .query(`
          INSERT INTO [Jobpost].[recruit].[CandidateIdentity]
            (CandidateId, IdentityType, IdentityValue, IsPrimary, IsVerified, CreatedOn)
          VALUES
            (@CandidateId, @IdentityType, @IdentityValue, @IsPrimary, @IsVerified, GETDATE())
        `);
    }

    // B3) Insert Skills
    const skillsList = parseJsonField(Skills);
    for (const skillName of skillsList) {
      if (!skillName || !String(skillName).trim()) continue;
      const name = String(skillName).trim();

      const skillRes = await new sql.Request(transaction)
        .input('SkillName', sql.NVarChar(200), name)
        .query(`
          IF NOT EXISTS (SELECT 1 FROM [Jobpost].[recruit].[Skill] WHERE SkillName = @SkillName)
            INSERT INTO [Jobpost].[recruit].[Skill] (SkillName) VALUES (@SkillName);
          SELECT SkillId FROM [Jobpost].[recruit].[Skill] WHERE SkillName = @SkillName;
        `);
      const skillId = skillRes.recordset[0].SkillId;

      await new sql.Request(transaction)
        .input('CandidateId', sql.Int, candidateId)
        .input('SkillId', sql.Int, skillId)
        .query(`
          IF NOT EXISTS (
            SELECT 1 FROM [Jobpost].[recruit].[CandidateSkill]
            WHERE CandidateId = @CandidateId AND SkillId = @SkillId
          )
          INSERT INTO [Jobpost].[recruit].[CandidateSkill] (CandidateId, SkillId)
          VALUES (@CandidateId, @SkillId)
        `);
    }

    // B4) Insert Education
    const eduList = parseJsonField(Education);
    for (const edu of eduList) {
      if (!edu || typeof edu !== 'object') continue;
      await new sql.Request(transaction)
        .input('CandidateId',  sql.Int,            candidateId)
        .input('Institution',  sql.NVarChar(200),  edu.Institution  || edu.institution  || null)
        .input('Degree',       sql.NVarChar(200),  edu.Degree       || edu.degree       || null)
        .input('FieldOfStudy', sql.NVarChar(200),  edu.FieldOfStudy || edu.fieldOfStudy || null)
        .input('StartDate',    sql.Date,           parseDate(edu.StartDate || edu.startDate))
        .input('EndDate',      sql.Date,           parseDate(edu.EndDate   || edu.endDate))
        .input('GPA',          sql.NVarChar(20),   edu.GPA          || edu.gpa          || null)
        .input('Notes',        sql.NVarChar(sql.MAX), edu.Notes     || edu.notes        || null)
        .query(`
          INSERT INTO [Jobpost].[recruit].[CandidateEducation]
            (CandidateId, Institution, Degree, FieldOfStudy, StartDate, EndDate, GPA, Notes)
          VALUES
            (@CandidateId, @Institution, @Degree, @FieldOfStudy, @StartDate, @EndDate, @GPA, @Notes)
        `);
    }

    // B5) Insert Work Experience
    const workList = parseJsonField(WorkExperience);
    for (const w of workList) {
      if (!w || typeof w !== 'object') continue;
      await new sql.Request(transaction)
        .input('CandidateId',  sql.Int,            candidateId)
        .input('Company',      sql.NVarChar(200),  w.Company     || w.company     || null)
        .input('JobTitle',     sql.NVarChar(200),  w.JobTitle    || w.jobTitle    || null)
        .input('StartDate',    sql.Date,           parseDate(w.StartDate || w.startDate))
        .input('EndDate',      sql.Date,           parseDate(w.EndDate   || w.endDate))
        .input('IsCurrent',    sql.Bit,            w.IsCurrent ?? w.isCurrent ?? 0)
        .input('Description',  sql.NVarChar(sql.MAX), w.Description || w.description || null)
        .query(`
          INSERT INTO [Jobpost].[recruit].[CandidateWorkExperience]
            (CandidateId, Company, JobTitle, StartDate, EndDate, IsCurrent, Description)
          VALUES
            (@CandidateId, @Company, @JobTitle, @StartDate, @EndDate, @IsCurrent, @Description)
        `);
    }

    // B6) Insert Certifications
    const certList = parseJsonField(Certifications);
    for (const cert of certList) {
      if (!cert || typeof cert !== 'object') continue;
      await new sql.Request(transaction)
        .input('CandidateId',         sql.Int,            candidateId)
        .input('CertificationName',   sql.NVarChar(200),  cert.CertificationName   || cert.name          || null)
        .input('IssuingOrganization', sql.NVarChar(200),  cert.IssuingOrganization || cert.issuingOrg    || null)
        .input('IssueDate',           sql.Date,           parseDate(cert.IssueDate  || cert.issueDate))
        .input('ExpiryDate',          sql.Date,           parseDate(cert.ExpiryDate || cert.expiryDate))
        .input('CredentialId',        sql.NVarChar(100),  cert.CredentialId        || cert.credentialId  || null)
        .input('CredentialUrl',       sql.NVarChar(500),  cert.CredentialUrl       || cert.credentialUrl || null)
        .query(`
          INSERT INTO [Jobpost].[recruit].[CandidateCertification]
            (CandidateId, CertificationName, IssuingOrganization, IssueDate, ExpiryDate, CredentialId, CredentialUrl)
          VALUES
            (@CandidateId, @CertificationName, @IssuingOrganization, @IssueDate, @ExpiryDate, @CredentialId, @CredentialUrl)
        `);
    }

    // B7) Insert Resume File (if uploaded)
    if (req.file && req.file.buffer) {
      const ext = path.extname(req.file.originalname).toLowerCase();
      await new sql.Request(transaction)
        .input('CandidateId',      sql.Int,            candidateId)
        .input('DocumentType',     sql.NVarChar(50),   'Resume')
        .input('VersionNo',        sql.Int,            1)
        .input('IsPrimaryResume',  sql.Bit,            1)
        .input('FileNameOriginal', sql.NVarChar(255),  req.file.originalname)
        .input('FileExtension',    sql.NVarChar(10),   ext)
        .input('MimeType',         sql.NVarChar(100),  req.file.mimetype)
        .input('FileSizeBytes',    sql.BigInt,         req.file.buffer.length)
        .input('StorageProvider',  sql.NVarChar(50),   'DATABASE')
        .input('StorageLocator',   sql.NVarChar(500),  'inline')
        .input('StorageRegion',    sql.NVarChar(50),   'local')
        .input('ResumeFileData',   sql.VarBinary(sql.MAX), req.file.buffer)
        .input('IsDeleted',        sql.Bit,            0)
        .query(`
          INSERT INTO [Jobpost].[recruit].[CandidateDocument] (
            CandidateId, DocumentType, VersionNo, IsPrimaryResume,
            FileNameOriginal, FileExtension, MimeType, FileSizeBytes,
            StorageProvider, StorageLocator, StorageRegion,
            ResumeFileData, UploadedOn, IsDeleted
          ) VALUES (
            @CandidateId, @DocumentType, @VersionNo, @IsPrimaryResume,
            @FileNameOriginal, @FileExtension, @MimeType, @FileSizeBytes,
            @StorageProvider, @StorageLocator, @StorageRegion,
            @ResumeFileData, GETDATE(), @IsDeleted
          )
        `);
    }

    // B8) Insert Additional Documents (if any uploaded via AdditionalDoc_N fields)
    const additionalDocsCount = parseInt(req.body.AdditionalDocsCount || '0', 10);
    for (let i = 0; i < additionalDocsCount; i++) {
      const docFile = req.files && req.files[`AdditionalDoc_${i}`] && req.files[`AdditionalDoc_${i}`][0]
        ? req.files[`AdditionalDoc_${i}`][0]
        : null;
      const docName = req.body[`AdditionalDoc_${i}_Name`] || null;
      const docType = req.body[`AdditionalDoc_${i}_Type`] || 'Certificate';

      if (docFile && docFile.buffer) {
        const ext = path.extname(docFile.originalname).toLowerCase();
        console.log(`📎 Inserting additional document ${i}:`, docFile.originalname, 'Type:', docType);
        await new sql.Request(transaction)
          .input('CandidateId',      sql.Int,            candidateId)
          .input('DocumentType',     sql.NVarChar(50),   docType)
          .input('VersionNo',        sql.Int,            1)
          .input('IsPrimaryResume',  sql.Bit,            0)
          .input('FileNameOriginal', sql.NVarChar(255),  docName || docFile.originalname)
          .input('FileExtension',    sql.NVarChar(10),   ext)
          .input('MimeType',         sql.NVarChar(100),  docFile.mimetype)
          .input('FileSizeBytes',    sql.BigInt,         docFile.buffer.length)
          .input('StorageProvider',  sql.NVarChar(50),   'DATABASE')
          .input('StorageLocator',   sql.NVarChar(500),  'inline')
          .input('StorageRegion',    sql.NVarChar(50),   'local')
          .input('ResumeFileData',   sql.VarBinary(sql.MAX), docFile.buffer)
          .input('IsDeleted',        sql.Bit,            0)
          .query(`
            INSERT INTO [Jobpost].[recruit].[CandidateDocument] (
              CandidateId, DocumentType, VersionNo, IsPrimaryResume,
              FileNameOriginal, FileExtension, MimeType, FileSizeBytes,
              StorageProvider, StorageLocator, StorageRegion,
              ResumeFileData, UploadedOn, IsDeleted
            ) VALUES (
              @CandidateId, @DocumentType, @VersionNo, @IsPrimaryResume,
              @FileNameOriginal, @FileExtension, @MimeType, @FileSizeBytes,
              @StorageProvider, @StorageLocator, @StorageRegion,
              @ResumeFileData, GETDATE(), @IsDeleted
            )
          `);
      }
    }

    // ────────────────────────────────────────────────────────────
    // 📍 HANDLE CURRENT LOCATION (core.EntityAddress) - IMPROVED
    // ────────────────────────────────────────────────────────────
    const locString = (CurrentLocation || '').trim();
    if (locString) {
      await handleLocationUpdate(transaction, candidateId, locString);
    }

    await transaction.commit();
    transaction = null;

    console.log('✅ New candidate created with ID:', candidateId, 'Code:', candidateCode);

    return res.status(201).json({
      success: true,
      merged: false,
      message: "Candidate created successfully!",
      CandidateId: candidateId,
      CandidateCode: candidateCode,
    });

  } catch (error) {
    console.error("Create error:", error);
    if (transaction) {
      try { await transaction.rollback(); } catch (e) { console.error('Rollback error:', e); }
    }
    return res.status(500).json({
      success: false,
      error: "Failed to create candidate",
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// ─── UPDATE CANDIDATE ────────────────────────────────────────────────────────

exports.updateResume = async (req, res) => {
  console.log('=== Update Candidate Request ===');
  const { id } = req.params;
  let transaction;

  if (!id || isNaN(parseInt(id))) {
    return res.status(400).json({ success: false, error: "Invalid candidate ID" });
  }

  const candidateId = parseInt(id);

  try {
    const pool = await poolPromise;

    // Check existence
    const check = await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`SELECT CandidateId FROM [Jobpost].[recruit].[Candidate] WHERE CandidateId = @CandidateId AND IsDeleted = 0`);

    if (!check.recordset.length) {
      return res.status(404).json({ success: false, error: "Candidate not found" });
    }

    transaction = new sql.Transaction(pool);
    await transaction.begin();

    const {
      FirstName, LastName, MiddleName, EmailID,
      Phone, Mobile, JobTitle, YearsOfExperience,
      CandidateStatus, WorkAuthorization, SecurityClearance,
      WillingToRelocate, RemoteStatus, EmploymentType,
      ExpectedRateFrom, ExpectedRateTo, ExpectedRateType,
      CurrentRate, CurrentRateType, Gender, MaritalStatus,
      Industry, ProfileSummary, LinkedInProfile, GitHubUrl,
      TwitterUrl, VideoResumeUrl,
      Dob,
      Skills, Education, WorkExperience, Certifications, CurrentLocation
    } = req.body;

    // Parse DOB
    let dobValue = null;
    if (Dob && String(Dob).trim() !== '') {
      dobValue = new Date(Dob);
      if (isNaN(dobValue)) dobValue = null;
    }

    // Parse boolean values
    const willingToRelocate = WillingToRelocate === 'true' || WillingToRelocate === true ? 1 : 0;

    // Parse numeric values
    const yearsExp = YearsOfExperience ? parseFloat(YearsOfExperience) : null;
    const expectedRateFrom = ExpectedRateFrom ? parseFloat(ExpectedRateFrom) : null;
    const expectedRateTo = ExpectedRateTo ? parseFloat(ExpectedRateTo) : null;
    const currentRate = CurrentRate ? parseFloat(CurrentRate) : null;

    // 1) Update Candidate row
    let setClauses = [];
    const request = new sql.Request(transaction);
    request.input('CandidateId', sql.Int, candidateId);

    const addField = (name, col, val, type) => {
      if (val !== undefined) {
        setClauses.push(`${col} = @${name}`);
        request.input(name, type, val === '' ? null : val);
      }
    };

    addField('FirstName',           'FirstName',            FirstName?.trim(),           sql.NVarChar(100));
    addField('MiddleName',          'MiddleName',           MiddleName?.trim(),          sql.NVarChar(100));
    addField('LastName',            'LastName',             LastName?.trim(),            sql.NVarChar(100));
    addField('DateOfBirth',         'DateOfBirth',          dobValue,                    sql.Date);
    addField('Phone',               'Phone',                Phone?.trim(),               sql.NVarChar(50));
    addField('Mobile',              'Mobile',               Mobile?.trim(),              sql.NVarChar(50));
    addField('JobTitle',            'JobTitle',             JobTitle?.trim(),            sql.NVarChar(200));
    addField('YearsOfExperience',   'YearsOfExperience',    yearsExp,                    sql.Decimal(5,1));
    addField('CandidateStatus',     'CandidateStatus',      CandidateStatus,             sql.NVarChar(50));
    addField('WorkAuthorization',   'WorkAuthorization',    WorkAuthorization,           sql.NVarChar(50));
    addField('SecurityClearance',   'SecurityClearance',    SecurityClearance,           sql.NVarChar(50));
    addField('WillingToRelocate',   'WillingToRelocate',    willingToRelocate,           sql.Bit);
    addField('RemoteStatus',        'RemoteStatus',         RemoteStatus,                sql.NVarChar(50));
    addField('EmploymentType',      'EmploymentType',       EmploymentType,              sql.NVarChar(50));
    addField('ExpectedRateFrom',    'ExpectedRateFrom',     expectedRateFrom,            sql.Decimal(18,2));
    addField('ExpectedRateTo',      'ExpectedRateTo',       expectedRateTo,              sql.Decimal(18,2));
    addField('ExpectedRateType',    'ExpectedRateType',     ExpectedRateType,            sql.NVarChar(20));
    addField('CurrentRate',         'CurrentRate',          currentRate,                 sql.Decimal(18,2));
    addField('CurrentRateType',     'CurrentRateType',      CurrentRateType,             sql.NVarChar(20));
    addField('Gender',              'Gender',               Gender,                      sql.NVarChar(20));
    addField('MaritalStatus',       'MaritalStatus',        MaritalStatus,               sql.NVarChar(20));
    addField('Industry',            'Industry',             Industry,                    sql.NVarChar(100));
    addField('ProfileSummary',      'ProfileSummary',       ProfileSummary?.trim(),      sql.NVarChar(sql.MAX));
    addField('LinkedInUrl',         'LinkedInUrl',          LinkedInProfile?.trim(),     sql.NVarChar(500));
    addField('GitHubUrl',           'GitHubUrl',            GitHubUrl?.trim(),           sql.NVarChar(500));
    addField('TwitterUrl',          'TwitterUrl',           TwitterUrl?.trim(),          sql.NVarChar(500));
    addField('VideoResumeUrl',      'VideoResumeUrl',       VideoResumeUrl?.trim(),      sql.NVarChar(500));

    if (setClauses.length > 0) {
      setClauses.push('ModifiedOn = GETDATE()');
      await request.query(`
        UPDATE [Jobpost].[recruit].[Candidate]
        SET ${setClauses.join(', ')}
        WHERE CandidateId = @CandidateId
      `);
    }

    // 2) Update Email identity
    if (EmailID !== undefined && EmailID.trim()) {
      await new sql.Request(transaction)
        .input('CandidateId', sql.Int, candidateId)
        .input('IdentityValue', sql.NVarChar(255), EmailID.trim())
        .query(`
          IF EXISTS (
            SELECT 1 FROM [Jobpost].[recruit].[CandidateIdentity]
            WHERE CandidateId = @CandidateId AND IdentityType = 'Email' AND IsPrimary = 1
          )
            UPDATE [Jobpost].[recruit].[CandidateIdentity]
            SET IdentityValue = @IdentityValue
            WHERE CandidateId = @CandidateId AND IdentityType = 'Email' AND IsPrimary = 1
          ELSE
            INSERT INTO [Jobpost].[recruit].[CandidateIdentity]
              (CandidateId, IdentityType, IdentityValue, IsPrimary, IsVerified, CreatedOn)
            VALUES (@CandidateId, 'Email', @IdentityValue, 1, 0, GETDATE())
        `);
    }

    // 3) Replace Skills (delete + re-insert)
    if (Skills !== undefined) {
      await new sql.Request(transaction)
        .input('CandidateId', sql.Int, candidateId)
        .query(`DELETE FROM [Jobpost].[recruit].[CandidateSkill] WHERE CandidateId = @CandidateId`);

      const skillsList = parseJsonField(Skills);
      for (const skillName of skillsList) {
        if (!skillName || !String(skillName).trim()) continue;
        const name = String(skillName).trim();
        const skillRes = await new sql.Request(transaction)
          .input('SkillName', sql.NVarChar(200), name)
          .query(`
            IF NOT EXISTS (SELECT 1 FROM [Jobpost].[recruit].[Skill] WHERE SkillName = @SkillName)
              INSERT INTO [Jobpost].[recruit].[Skill] (SkillName) VALUES (@SkillName);
            SELECT SkillId FROM [Jobpost].[recruit].[Skill] WHERE SkillName = @SkillName;
          `);
        const skillId = skillRes.recordset[0].SkillId;
        await new sql.Request(transaction)
          .input('CandidateId', sql.Int, candidateId)
          .input('SkillId', sql.Int, skillId)
          .query(`INSERT INTO [Jobpost].[recruit].[CandidateSkill] (CandidateId, SkillId) VALUES (@CandidateId, @SkillId)`);
      }
    }

    // 4) Replace Education
    if (Education !== undefined) {
      await new sql.Request(transaction)
        .input('CandidateId', sql.Int, candidateId)
        .query(`DELETE FROM [Jobpost].[recruit].[CandidateEducation] WHERE CandidateId = @CandidateId`);

      for (const edu of parseJsonField(Education)) {
        if (!edu || typeof edu !== 'object') continue;
        await new sql.Request(transaction)
          .input('CandidateId',  sql.Int,            candidateId)
          .input('Institution',  sql.NVarChar(200),  edu.Institution  || edu.institution  || null)
          .input('Degree',       sql.NVarChar(200),  edu.Degree       || edu.degree       || null)
          .input('FieldOfStudy', sql.NVarChar(200),  edu.FieldOfStudy || edu.fieldOfStudy || null)
          .input('StartDate',    sql.Date,           parseDate(edu.StartDate || edu.startDate))
          .input('EndDate',      sql.Date,           parseDate(edu.EndDate   || edu.endDate))
          .input('GPA',          sql.NVarChar(20),   edu.GPA          || edu.gpa          || null)
          .input('Notes',        sql.NVarChar(sql.MAX), edu.Notes     || edu.notes        || null)
          .query(`
            INSERT INTO [Jobpost].[recruit].[CandidateEducation]
              (CandidateId, Institution, Degree, FieldOfStudy, StartDate, EndDate, GPA, Notes)
            VALUES
              (@CandidateId, @Institution, @Degree, @FieldOfStudy, @StartDate, @EndDate, @GPA, @Notes)
          `);
      }
    }

    // 5) Replace Work Experience
    if (WorkExperience !== undefined) {
      await new sql.Request(transaction)
        .input('CandidateId', sql.Int, candidateId)
        .query(`DELETE FROM [Jobpost].[recruit].[CandidateWorkExperience] WHERE CandidateId = @CandidateId`);

      for (const w of parseJsonField(WorkExperience)) {
        if (!w || typeof w !== 'object') continue;
        await new sql.Request(transaction)
          .input('CandidateId',  sql.Int,            candidateId)
          .input('Company',      sql.NVarChar(200),  w.Company     || w.company     || null)
          .input('JobTitle',     sql.NVarChar(200),  w.JobTitle    || w.jobTitle    || null)
          .input('StartDate',    sql.Date,           parseDate(w.StartDate || w.startDate))
          .input('EndDate',      sql.Date,           parseDate(w.EndDate   || w.endDate))
          .input('IsCurrent',    sql.Bit,            w.IsCurrent ?? w.isCurrent ?? 0)
          .input('Description',  sql.NVarChar(sql.MAX), w.Description || w.description || null)
          .query(`
            INSERT INTO [Jobpost].[recruit].[CandidateWorkExperience]
              (CandidateId, Company, JobTitle, StartDate, EndDate, IsCurrent, Description)
            VALUES
              (@CandidateId, @Company, @JobTitle, @StartDate, @EndDate, @IsCurrent, @Description)
          `);
      }
    }

    // 6) Replace Certifications
    if (Certifications !== undefined) {
      await new sql.Request(transaction)
        .input('CandidateId', sql.Int, candidateId)
        .query(`DELETE FROM [Jobpost].[recruit].[CandidateCertification] WHERE CandidateId = @CandidateId`);

      for (const cert of parseJsonField(Certifications)) {
        if (!cert || typeof cert !== 'object') continue;
        await new sql.Request(transaction)
          .input('CandidateId',         sql.Int,            candidateId)
          .input('CertificationName',   sql.NVarChar(200),  cert.CertificationName   || cert.name          || null)
          .input('IssuingOrganization', sql.NVarChar(200),  cert.IssuingOrganization || cert.issuingOrg    || null)
          .input('IssueDate',           sql.Date,           parseDate(cert.IssueDate  || cert.issueDate))
          .input('ExpiryDate',          sql.Date,           parseDate(cert.ExpiryDate || cert.expiryDate))
          .input('CredentialId',        sql.NVarChar(100),  cert.CredentialId        || cert.credentialId  || null)
          .input('CredentialUrl',       sql.NVarChar(500),  cert.CredentialUrl       || cert.credentialUrl || null)
          .query(`
            INSERT INTO [Jobpost].[recruit].[CandidateCertification]
              (CandidateId, CertificationName, IssuingOrganization, IssueDate, ExpiryDate, CredentialId, CredentialUrl)
            VALUES
              (@CandidateId, @CertificationName, @IssuingOrganization, @IssueDate, @ExpiryDate, @CredentialId, @CredentialUrl)
          `);
      }
    }

    // 7) Upload new Resume File (add as new version)
    if (req.file && req.file.buffer) {
      // Mark existing primary resume as non-primary
      await new sql.Request(transaction)
        .input('CandidateId', sql.Int, candidateId)
        .query(`
          UPDATE [Jobpost].[recruit].[CandidateDocument]
          SET IsPrimaryResume = 0
          WHERE CandidateId = @CandidateId AND IsPrimaryResume = 1
        `);

      // Get next version number
      const versionRes = await new sql.Request(transaction)
        .input('CandidateId', sql.Int, candidateId)
        .query(`SELECT ISNULL(MAX(VersionNo), 0) + 1 AS NextVer FROM [Jobpost].[recruit].[CandidateDocument] WHERE CandidateId = @CandidateId`);
      const nextVer = versionRes.recordset[0].NextVer;

      const ext = path.extname(req.file.originalname).toLowerCase();
      await new sql.Request(transaction)
        .input('CandidateId',      sql.Int,            candidateId)
        .input('DocumentType',     sql.NVarChar(50),   'Resume')
        .input('VersionNo',        sql.Int,            nextVer)
        .input('IsPrimaryResume',  sql.Bit,            1)
        .input('FileNameOriginal', sql.NVarChar(255),  req.file.originalname)
        .input('FileExtension',    sql.NVarChar(10),   ext)
        .input('MimeType',         sql.NVarChar(100),  req.file.mimetype)
        .input('FileSizeBytes',    sql.BigInt,         req.file.buffer.length)
        .input('StorageProvider',  sql.NVarChar(50),   'DATABASE')
        .input('StorageLocator',   sql.NVarChar(500),  'inline')
        .input('StorageRegion',    sql.NVarChar(50),   'local')
        .input('ResumeFileData',   sql.VarBinary(sql.MAX), req.file.buffer)
        .input('IsDeleted',        sql.Bit,            0)
        .query(`
          INSERT INTO [Jobpost].[recruit].[CandidateDocument] (
            CandidateId, DocumentType, VersionNo, IsPrimaryResume,
            FileNameOriginal, FileExtension, MimeType, FileSizeBytes,
            StorageProvider, StorageLocator, StorageRegion,
            ResumeFileData, UploadedOn, IsDeleted
          ) VALUES (
            @CandidateId, @DocumentType, @VersionNo, @IsPrimaryResume,
            @FileNameOriginal, @FileExtension, @MimeType, @FileSizeBytes,
            @StorageProvider, @StorageLocator, @StorageRegion,
            @ResumeFileData, GETDATE(), @IsDeleted
          )
        `);

      console.log('📎 New resume uploaded:', req.file.originalname);
    }

    // 8) Insert Additional Documents (if any uploaded via AdditionalDoc_N fields)
    const additionalDocsCount = parseInt(req.body.AdditionalDocsCount || '0', 10);
    for (let i = 0; i < additionalDocsCount; i++) {
      const docFile = req.files && req.files[`AdditionalDoc_${i}`] && req.files[`AdditionalDoc_${i}`][0]
        ? req.files[`AdditionalDoc_${i}`][0]
        : null;
      const docName = req.body[`AdditionalDoc_${i}_Name`] || null;
      const docType = req.body[`AdditionalDoc_${i}_Type`] || 'Certificate';

      if (docFile && docFile.buffer) {
        const ext = path.extname(docFile.originalname).toLowerCase();
        console.log(`📎 Inserting additional document ${i}:`, docFile.originalname, 'Type:', docType);
        await new sql.Request(transaction)
          .input('CandidateId',      sql.Int,            candidateId)
          .input('DocumentType',     sql.NVarChar(50),   docType)
          .input('VersionNo',        sql.Int,            1)
          .input('IsPrimaryResume',  sql.Bit,            0)
          .input('FileNameOriginal', sql.NVarChar(255),  docName || docFile.originalname)
          .input('FileExtension',    sql.NVarChar(10),   ext)
          .input('MimeType',         sql.NVarChar(100),  docFile.mimetype)
          .input('FileSizeBytes',    sql.BigInt,         docFile.buffer.length)
          .input('StorageProvider',  sql.NVarChar(50),   'DATABASE')
          .input('StorageLocator',   sql.NVarChar(500),  'inline')
          .input('StorageRegion',    sql.NVarChar(50),   'local')
          .input('ResumeFileData',   sql.VarBinary(sql.MAX), docFile.buffer)
          .input('IsDeleted',        sql.Bit,            0)
          .query(`
            INSERT INTO [Jobpost].[recruit].[CandidateDocument] (
              CandidateId, DocumentType, VersionNo, IsPrimaryResume,
              FileNameOriginal, FileExtension, MimeType, FileSizeBytes,
              StorageProvider, StorageLocator, StorageRegion,
              ResumeFileData, UploadedOn, IsDeleted
            ) VALUES (
              @CandidateId, @DocumentType, @VersionNo, @IsPrimaryResume,
              @FileNameOriginal, @FileExtension, @MimeType, @FileSizeBytes,
              @StorageProvider, @StorageLocator, @StorageRegion,
              @ResumeFileData, GETDATE(), @IsDeleted
            )
          `);
      }
    }

    // 9) Update Location (City / State / Country via core.EntityAddress)
    const locString = (CurrentLocation || '').trim();
    if (locString) {
      await handleLocationUpdate(transaction, candidateId, locString);
    }

    await transaction.commit();
    transaction = null;

    console.log('✅ Candidate updated:', candidateId);

    return res.status(200).json({
      success: true,
      message: "Candidate updated successfully!",
      CandidateId: candidateId,
    });

  } catch (error) {
    console.error("Update error:", error);
    if (transaction) {
      try { await transaction.rollback(); } catch (e) { console.error('Rollback error:', e); }
    }
    return res.status(500).json({
      success: false,
      error: "Failed to update candidate",
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// ─── DELETE CANDIDATE (soft delete) ──────────────────────────────────────────

exports.deleteResume = async (req, res) => {
  console.log('=== Delete Candidate Request ===');
  const { id } = req.params;

  if (!id || isNaN(parseInt(id))) {
    return res.status(400).json({ success: false, error: "Invalid candidate ID" });
  }

  const candidateId = parseInt(id);

  try {
    const pool = await poolPromise;

    // Check if exists
    const check = await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        SELECT CandidateId, FirstName, LastName
        FROM [Jobpost].[recruit].[Candidate]
        WHERE CandidateId = @CandidateId AND IsDeleted = 0
      `);

    if (!check.recordset.length) {
      return res.status(404).json({ success: false, error: "Candidate not found" });
    }

    const candidate = check.recordset[0];

    // Soft delete: set IsDeleted = 1
    await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        UPDATE [Jobpost].[recruit].[Candidate]
        SET IsDeleted = 1, ModifiedOn = GETDATE()
        WHERE CandidateId = @CandidateId
      `);

    // Also soft-delete documents
    await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        UPDATE [Jobpost].[recruit].[CandidateDocument]
        SET IsDeleted = 1
        WHERE CandidateId = @CandidateId
      `);

    console.log('✅ Candidate soft-deleted:', candidateId);

    return res.status(200).json({
      success: true,
      message: "Candidate deleted successfully",
      deletedId: candidateId,
      deletedCandidate: `${candidate.FirstName} ${candidate.LastName}`,
    });

  } catch (error) {
    console.error("Delete error:", error);
    return res.status(500).json({
      success: false,
      error: "Could not delete candidate",
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// ─── DOWNLOAD RESUME ─────────────────────────────────────────────────────────

exports.downloadResume = async (req, res) => {
  console.log('=== DOWNLOAD RESUME REQUEST ===');
  const { id } = req.params;

  if (!id || isNaN(parseInt(id))) {
    return res.status(400).json({ success: false, error: "Invalid document ID" });
  }

  const documentId = parseInt(id);

  try {
    const pool = await poolPromise;

    const result = await pool.request()
      .input('DocumentId', sql.Int, documentId)
      .query(`
        SELECT d.DocumentId, d.FileNameOriginal, d.MimeType, d.ResumeFileData,
               c.FirstName, c.LastName
        FROM [Jobpost].[recruit].[CandidateDocument] d
        INNER JOIN [Jobpost].[recruit].[Candidate] c ON c.CandidateId = d.CandidateId
        WHERE d.DocumentId = @DocumentId AND d.IsDeleted = 0
      `);

    if (!result.recordset.length) {
      return res.status(404).json({ success: false, error: "Document not found" });
    }

    const doc = result.recordset[0];

    if (!doc.ResumeFileData) {
      return res.status(404).json({ success: false, error: "No file data stored for this document" });
    }

    const fileName = doc.FileNameOriginal || `${doc.FirstName}_${doc.LastName}_Resume.pdf`;

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');
    res.setHeader('Content-Type', doc.MimeType || 'application/octet-stream');
    res.setHeader('Content-Length', doc.ResumeFileData.length);
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    res.setHeader('Cache-Control', 'no-cache');

    res.send(Buffer.from(doc.ResumeFileData));

  } catch (error) {
    console.error("Download error:", error);
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: "Could not download resume",
        details: process.env.NODE_ENV === 'development' ? error.message : undefined
      });
    }
  }
};

// ─── PREVIEW RESUME ──────────────────────────────────────────────────────────

exports.previewResume = async (req, res) => {
  console.log('=== PREVIEW RESUME REQUEST ===');
  const { id } = req.params;

  if (!id || isNaN(parseInt(id))) {
    return res.status(400).json({ success: false, error: "Invalid document ID" });
  }

  const documentId = parseInt(id);

  try {
    const pool = await poolPromise;

    const result = await pool.request()
      .input('DocumentId', sql.Int, documentId)
      .query(`
        SELECT d.DocumentId, d.FileNameOriginal, d.MimeType, d.ResumeFileData
        FROM [Jobpost].[recruit].[CandidateDocument] d
        WHERE d.DocumentId = @DocumentId AND d.IsDeleted = 0
      `);

    if (!result.recordset.length) {
      return res.status(404).json({ success: false, error: "Document not found" });
    }

    const doc = result.recordset[0];

    if (!doc.ResumeFileData) {
      return res.status(404).json({ success: false, error: "No file data stored" });
    }

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Type, Content-Length, Content-Disposition');

    const fileBuffer = Buffer.from(doc.ResumeFileData);

    if (doc.MimeType === 'application/pdf') {
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Length', fileBuffer.length);
      res.setHeader('Content-Disposition', `inline; filename="${doc.FileNameOriginal || 'resume.pdf'}"`);
      res.setHeader('X-Frame-Options', 'SAMEORIGIN');
      res.setHeader('Content-Security-Policy', "frame-ancestors 'self' http://localhost:* https://localhost:*");
      res.setHeader('Accept-Ranges', 'bytes');

      const range = req.headers.range;
      if (range) {
        const parts = range.replace(/bytes=/, "").split("-");
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : fileBuffer.length - 1;
        res.status(206);
        res.setHeader('Content-Range', `bytes ${start}-${end}/${fileBuffer.length}`);
        res.setHeader('Content-Length', end - start + 1);
        res.send(fileBuffer.slice(start, end + 1));
      } else {
        res.send(fileBuffer);
      }
    }
    else if (doc.MimeType === 'text/plain') {
      const textContent = fileBuffer.toString('utf-8');
      const htmlContent = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${doc.FileNameOriginal}</title>
        <style>body{font-family:'Courier New',monospace;padding:30px;background:#f5f5f5;line-height:1.6}
        .container{max-width:900px;margin:0 auto;background:#fff;padding:40px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}
        .header{background:#1a6f66;color:#fff;padding:15px 20px;margin:-40px -40px 30px -40px;border-radius:8px 8px 0 0}
        pre{white-space:pre-wrap;word-wrap:break-word;font-size:14px;color:#333}</style></head>
        <body><div class="container"><div class="header"><strong>${doc.FileNameOriginal}</strong></div>
        <pre>${textContent.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre></div></body></html>`;
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(htmlContent);
    }
    else if (
      doc.MimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
      doc.MimeType === 'application/msword'
    ) {
      const conversionResult = await convertDocumentToHtml(fileBuffer, doc.MimeType);
      if (!conversionResult.success) {
        return res.status(400).json({ success: false, error: "Failed to convert document", details: conversionResult.error });
      }
      const htmlContent = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${doc.FileNameOriginal}</title>
        <style>body{font-family:Calibri,Arial,sans-serif;padding:30px;background:#f5f5f5;line-height:1.6}
        .container{max-width:900px;margin:0 auto;background:#fff;padding:40px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}
        .header{background:#1a6f66;color:#fff;padding:15px 20px;margin:-40px -40px 30px -40px;border-radius:8px 8px 0 0}
        .content{font-size:14px;color:#333} .content p{margin-bottom:12px} .content h1,.content h2,.content h3{color:#1a6f66;margin:20px 0 10px}
        </style></head><body><div class="container"><div class="header"><strong>${doc.FileNameOriginal}</strong></div>
        <div class="content">${conversionResult.html}</div></div></body></html>`;
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(htmlContent);
    }
    else {
      return res.status(400).json({ success: false, error: "Preview not supported for this file type" });
    }

  } catch (error) {
    console.error("Preview error:", error);
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: "Could not preview resume",
        details: process.env.NODE_ENV === 'development' ? error.message : undefined
      });
    }
  }
};

// ─── GET RESUME FILE INFO ────────────────────────────────────────────────────

exports.getResumeFileInfo = async (req, res) => {
  const { id } = req.params;

  if (!id || isNaN(parseInt(id))) {
    return res.status(400).json({ success: false, error: "Invalid document ID" });
  }

  const documentId = parseInt(id);

  try {
    const pool = await poolPromise;

    const result = await pool.request()
      .input('DocumentId', sql.Int, documentId)
      .query(`
        SELECT DocumentId, FileNameOriginal, FileExtension, MimeType, FileSizeBytes
        FROM [Jobpost].[recruit].[CandidateDocument]
        WHERE DocumentId = @DocumentId AND IsDeleted = 0
      `);

    if (!result.recordset.length) {
      return res.status(200).json({ success: true, fileAvailable: false, message: "Document not found" });
    }

    const doc = result.recordset[0];
    const previewableTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/msword',
      'text/plain'
    ];
    const canPreview = previewableTypes.includes(doc.MimeType);

    return res.status(200).json({
      success: true,
      fileAvailable: true,
      fileInfo: {
        fileName:      doc.FileNameOriginal,
        fileSize:      doc.FileSizeBytes,
        fileExtension: doc.FileExtension,
        canPreview,
        fileType:      doc.MimeType,
      },
      downloadUrl: `/api/resumes/${documentId}/download`,
      previewUrl:  canPreview ? `/api/resumes/${documentId}/preview` : null,
    });

  } catch (error) {
    console.error("File info error:", error);
    res.status(500).json({
      success: false,
      error: "Could not get file information",
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// ─── GET CANDIDATE DOCUMENTS ─────────────────────────────────────────────────

exports.getCandidateDocuments = async (req, res) => {
  const { id } = req.params;

  if (!id || isNaN(parseInt(id))) {
    return res.status(400).json({ success: false, error: "Invalid candidate ID" });
  }

  const candidateId = parseInt(id);

  try {
    const pool = await poolPromise;

    const result = await pool.request()
      .input('CandidateId', sql.Int, candidateId)
      .query(`
        SELECT 
          DocumentId,
          DocumentType,
          FileNameOriginal,
          FileExtension,
          MimeType,
          FileSizeBytes,
          IsPrimaryResume,
          UploadedOn,
          FileNameOriginal as DocumentName
        FROM [Jobpost].[recruit].[CandidateDocument]
        WHERE CandidateId = @CandidateId 
          AND IsDeleted = 0
        ORDER BY 
          IsPrimaryResume DESC,
          UploadedOn DESC
      `);

    res.status(200).json(result.recordset);

  } catch (error) {
    console.error("Error fetching candidate documents:", error);
    res.status(500).json({
      success: false,
      error: "Could not fetch documents",
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// ─── DEBUG: TABLE STRUCTURE ──────────────────────────────────────────────────

exports.testTableStructure = async (req, res) => {
  try {
    const pool = await poolPromise;

    const schemaResult = await pool.request().query(`
      SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, DATA_TYPE, IS_NULLABLE, CHARACTER_MAXIMUM_LENGTH
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = 'recruit'
      ORDER BY TABLE_NAME, ORDINAL_POSITION
    `);

    const sampleResult = await pool.request().query(`
      SELECT TOP 5 CandidateId, CandidateCode, FirstName, LastName
      FROM [Jobpost].[recruit].[Candidate]
      WHERE IsDeleted = 0
      ORDER BY CandidateId DESC
    `);

    res.json({
      success: true,
      tableSchema: schemaResult.recordset,
      sampleData: sampleResult.recordset,
      totalColumns: schemaResult.recordset.length,
      sampleCount: sampleResult.recordset.length
    });

  } catch (error) {
    console.error('Table structure test failed:', error);
    res.status(500).json({ success: false, error: 'Failed to get table structure', details: error.message });
  }
};

// ============================================
// SENDGRID EMAIL HELPER
// ============================================
const sendEmailViaSendGrid = async (emailData) => {
  try {
    const apiKey = process.env.SENDGRID_API_KEY;
    
    if (!apiKey) {
      console.error('❌ SENDGRID_API_KEY not set in environment variables');
      return { success: false, error: 'SendGrid API key not configured' };
    }

    console.log('📧 Preparing to send email via SendGrid to:', emailData.to);
    console.log('Subject:', emailData.subject);

    const formatRecipients = (recips) => {
        if (!recips) return undefined;
        if (Array.isArray(recips)) return recips.map(e => ({ email: e }));
        return [{ email: recips }];
    };

    const personalizations = {
      to: formatRecipients(emailData.to),
      subject: emailData.subject
    };
    if (emailData.cc && emailData.cc.length > 0) personalizations.cc = formatRecipients(emailData.cc);
    if (emailData.bcc && emailData.bcc.length > 0) personalizations.bcc = formatRecipients(emailData.bcc);

    const payload = {
      personalizations: [personalizations],
      from: {
        email: process.env.SENDGRID_FROM_EMAIL || 'no-reply@prophecytechs.com',
        name: process.env.SENDGRID_FROM_NAME || 'Prophecy Tech'
      },
      content: [
        {
          type: 'text/html',
          value: emailData.html
        }
      ]
    };

    if (emailData.attachments && emailData.attachments.length > 0) {
      payload.attachments = emailData.attachments;
    }

    const payloadString = JSON.stringify(payload);

    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'api.sendgrid.com',
        port: 443,
        path: '/v3/mail/send',
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payloadString)
        }
      };

      console.log('📡 Sending request to SendGrid API...');

      const reqH = https.request(options, (res) => {
        let data = '';
        
        console.log('SendGrid Response Status:', res.statusCode);
        console.log('SendGrid Response Headers:', res.headers);

        res.on('data', (chunk) => {
          data += chunk;
        });

        res.on('end', () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            console.log('✅ Email sent successfully via SendGrid');
            resolve({ success: true });
          } else {
            console.error('❌ SendGrid error:', res.statusCode);
            console.error('SendGrid response:', data);
            resolve({ 
              success: false, 
              error: `SendGrid returned ${res.statusCode}: ${data}` 
            });
          }
        });
      });

      reqH.on('error', (error) => {
        console.error('❌ SendGrid request error:', error.message);
        reject(error);
      });

      reqH.write(payloadString);
      reqH.end();
    });
  } catch (error) {
    console.error('❌ Error in sendEmailViaSendGrid:', error.message);
    return { success: false, error: error.message };
  }
};

// ─── SHARE RESUME (Email via SendGrid) ───────────────────────────────────────

exports.shareResume = async (req, res) => {
  console.log('=== Share Resume Request ===');
  const { candidateId, candidateIds, to, cc, bcc, subject, body, documentIds } = req.body;

  if (!to || !to.trim()) {
    return res.status(400).json({ success: false, error: 'Recipient email is required' });
  }
  if (!documentIds || !Array.isArray(documentIds) || documentIds.length === 0) {
    return res.status(400).json({ success: false, error: 'At least one document must be selected to share' });
  }
  if (!process.env.SENDGRID_API_KEY) {
    return res.status(500).json({ success: false, error: 'SendGrid API Key is not configured on the server' });
  }

  try {
    const pool = await poolPromise;

    // Resolve candidateIds: can be array or single ID
    let finalCandidateIds = [];
    if (candidateIds && Array.isArray(candidateIds) && candidateIds.length > 0) {
      finalCandidateIds = candidateIds;
    } else if (candidateId) {
      finalCandidateIds = [candidateId];
    } else {
      return res.status(400).json({ success: false, error: 'Candidate ID(s) is required' });
    }

    // Fetch the specific documents from the DB for attachments
    let candPlaceholders = [];
    let docPlaceholders = [];
    const request = pool.request();
    
    for (let i = 0; i < finalCandidateIds.length; i++) {
        const pName = `cId${i}`;
        candPlaceholders.push(`@${pName}`);
        request.input(pName, sql.Int, finalCandidateIds[i]);
    }
    
    for (let i = 0; i < documentIds.length; i++) {
        const pName = `docId${i}`;
        docPlaceholders.push(`@${pName}`);
        request.input(pName, sql.Int, documentIds[i]);
    }

    const docResult = await request.query(`
      SELECT DocumentId, FileNameOriginal, MimeType, ResumeFileData
      FROM [Jobpost].[recruit].[CandidateDocument]
      WHERE CandidateId IN (${candPlaceholders.join(', ')})
        AND DocumentId IN (${docPlaceholders.join(', ')})
        AND IsDeleted = 0
    `);

    if (!docResult.recordset.length) {
      return res.status(404).json({ success: false, error: 'Selected documents not found' });
    }

    // Prepare SendGrid Attachments
    const attachments = docResult.recordset.map(doc => {
      return {
        content: doc.ResumeFileData.toString('base64'),
        filename: doc.FileNameOriginal || `Resume_Attachment_${doc.DocumentId}.pdf`,
        type: doc.MimeType || 'application/pdf',
        disposition: 'attachment'
      };
    });

    // Helper functions for recipients
    const parseRecipients = (input) => {
      if (!input) return undefined;
      if (Array.isArray(input)) return input.filter(i => validateEmail(i));
      return input.split(/[,;\s]+/).map(i => i.trim()).filter(i => validateEmail(i));
    };

    const toArray = parseRecipients(to);
    const ccArray = parseRecipients(cc);
    const bccArray = parseRecipients(bcc);

    if (toArray.length === 0) {
      return res.status(400).json({ success: false, error: 'No valid recipient email provided' });
    }

    const emailData = {
      to: toArray,
      cc: ccArray,
      bcc: bccArray,
      subject: subject || 'Candidate Resume',
      html: body || '<p>Please find the attached candidate resume.</p>',
      attachments: attachments
    };

    const emailResult = await sendEmailViaSendGrid(emailData);

    if (emailResult.success) {
      res.status(200).json({ success: true, message: 'Resume shared successfully' });
    } else {
      res.status(500).json({ success: false, error: 'Failed to send email', details: emailResult.error });
    }
  } catch (error) {
    console.error('Share resume error:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Failed to share resume', 
      details: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// ─── SCHEDULE INTERVIEW (Email via SendGrid) ─────────────────────────────────

exports.scheduleInterview = async (req, res) => {
  console.log('=== Schedule Interview Request ===');
  const { to, cc, bcc, subject, body } = req.body;

  if (!to || !to.trim()) {
    return res.status(400).json({ success: false, error: 'Recipient email is required' });
  }

  try {
    // Helper function for recipients inline (similar to shareResume)
    const parseRecipients = (input) => {
      if (!input) return undefined;
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const validateEmail = (email) => re.test(email);

      if (Array.isArray(input)) return input.filter(i => validateEmail(i));
      return input.split(/[,;\s]+/).map(i => i.trim()).filter(i => validateEmail(i));
    };

    const toArray = parseRecipients(to);
    const ccArray = parseRecipients(cc);
    const bccArray = parseRecipients(bcc);

    if (toArray.length === 0) {
      return res.status(400).json({ success: false, error: 'No valid recipient email provided' });
    }

    const emailData = {
      to: toArray,
      cc: ccArray,
      bcc: bccArray,
      subject: subject || 'Interview Scheduled',
      html: body || '<p>An interview has been scheduled with Prophecy Tech.</p>'
    };

    const emailResult = await sendEmailViaSendGrid(emailData);

    if (emailResult.success) {
      res.status(200).json({ success: true, message: 'Interview scheduled and email sent successfully' });
    } else {
      res.status(500).json({ success: false, error: 'Failed to send interview email', details: emailResult.error });
    }
  } catch (error) {
    console.error('Schedule interview error:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Failed to schedule interview email', 
      details: process.env.NODE_ENV === 'development' ? error.message : undefined 
    });
  }
};

// ─── Utility helpers ─────────────────────────────────────────────────────────

function parseJsonField(field) {
  if (!field) return [];
  if (Array.isArray(field)) return field;
  if (typeof field === 'string') {
    try { return JSON.parse(field); } catch { return []; }
  }
  return [];
}

function parseDate(value) {
  if (!value) return null;
  const d = new Date(value);
  return isNaN(d) ? null : d;
}

// ─── HANDLE LOCATION UPDATE (Helper Function) ───────────────────────────────

async function handleLocationUpdate(transaction, candidateId, locString) {
  try {
    const parts = locString.split(',').map(s => s.trim()).filter(Boolean);
    let cityName = '', stateCodeOrName = '', countryIso2 = '';

    if (parts.length === 1) {
      cityName = parts[0];
    } else if (parts.length === 2) {
      cityName = parts[0];
      stateCodeOrName = parts[1];
    } else if (parts.length >= 3) {
      cityName = parts[0];
      stateCodeOrName = parts[1];
      countryIso2 = parts[2];
    }

    if (!cityName) {
      console.log('No city name provided, skipping location');
      return;
    }

    let countryId = null;
    let stateId = null;
    let cityId = null;

    // 1. Resolve Country by ISO2 code (e.g. "US", "IN", "GB")
    if (countryIso2) {
      const iso2 = countryIso2.toUpperCase().substring(0, 2);
      const countryCheck = await new sql.Request(transaction)
        .input('Iso2', sql.Char(2), iso2)
        .query(`SELECT CountryId FROM [Jobpost].[core].[Country] WHERE Iso2 = @Iso2`);

      if (countryCheck.recordset.length > 0) {
        countryId = countryCheck.recordset[0].CountryId;
      } else {
        try {
          const ci = await new sql.Request(transaction)
            .input('Iso2', sql.Char(2), iso2)
            .input('Name', sql.NVarChar(100), iso2)
            .query(`INSERT INTO [Jobpost].[core].[Country] (Iso2, Name) OUTPUT INSERTED.CountryId VALUES (@Iso2, @Name)`);
          if (ci.recordset.length > 0) countryId = ci.recordset[0].CountryId;
        } catch (e) {
          const rc = await new sql.Request(transaction)
            .input('Iso2', sql.Char(2), iso2)
            .query(`SELECT CountryId FROM [Jobpost].[core].[Country] WHERE Iso2 = @Iso2`);
          if (rc.recordset.length > 0) countryId = rc.recordset[0].CountryId;
        }
      }
    }

    // 2. Resolve State by Code (short ≤3 chars) or Name, scoped to country
    if (stateCodeOrName) {
      const isCode = stateCodeOrName.length <= 3;
      const stateField = isCode ? 'Code' : 'Name';
      const stateVal = stateCodeOrName.toUpperCase();

      let stateQuery = `SELECT StateId FROM [Jobpost].[core].[StateProvince] WHERE ${stateField} = @StateVal`;
      if (countryId) stateQuery += ' AND CountryId = @CountryId';
      const stateReq = new sql.Request(transaction).input('StateVal', sql.NVarChar(100), stateVal);
      if (countryId) stateReq.input('CountryId', sql.Int, countryId);
      const stateCheck = await stateReq.query(stateQuery);

      if (stateCheck.recordset.length > 0) {
        stateId = stateCheck.recordset[0].StateId;
      } else {
        // Try without country restriction
        const stateCheck2 = await new sql.Request(transaction)
          .input('StateVal', sql.NVarChar(100), stateVal)
          .query(`SELECT TOP 1 StateId FROM [Jobpost].[core].[StateProvince] WHERE ${stateField} = @StateVal`);
        if (stateCheck2.recordset.length > 0) {
          stateId = stateCheck2.recordset[0].StateId;
        } else {
          try {
            const si = await new sql.Request(transaction)
              .input('Name', sql.NVarChar(100), stateCodeOrName)
              .input('Code', sql.NVarChar(10), stateCodeOrName.substring(0, 10).toUpperCase())
              .input('CountryId', sql.Int, countryId)
              .query(`INSERT INTO [Jobpost].[core].[StateProvince] (Name, Code, CountryId) OUTPUT INSERTED.StateId VALUES (@Name, @Code, @CountryId)`);
            if (si.recordset.length > 0) stateId = si.recordset[0].StateId;
          } catch (e) {
            const rs = await new sql.Request(transaction)
              .input('StateVal', sql.NVarChar(100), stateVal)
              .query(`SELECT TOP 1 StateId FROM [Jobpost].[core].[StateProvince] WHERE Code = @StateVal OR Name = @StateVal`);
            if (rs.recordset.length > 0) stateId = rs.recordset[0].StateId;
          }
        }
      }
    }

    // 3. Resolve City, scoped to state when available
    let cityQuery = `SELECT CityId FROM [Jobpost].[core].[City] WHERE Name = @CityName`;
    if (stateId) cityQuery += ' AND StateId = @StateId';
    const cityReq = new sql.Request(transaction).input('CityName', sql.NVarChar(100), cityName);
    if (stateId) cityReq.input('StateId', sql.Int, stateId);
    const cityCheck = await cityReq.query(cityQuery);

    if (cityCheck.recordset.length > 0) {
      cityId = cityCheck.recordset[0].CityId;
    } else {
      const cityCheck2 = await new sql.Request(transaction)
        .input('CityName', sql.NVarChar(100), cityName)
        .query(`SELECT TOP 1 CityId FROM [Jobpost].[core].[City] WHERE Name = @CityName`);
      if (cityCheck2.recordset.length > 0) {
        cityId = cityCheck2.recordset[0].CityId;
      } else {
        try {
          const ci2 = await new sql.Request(transaction)
            .input('CityName', sql.NVarChar(100), cityName)
            .input('StateId', sql.Int, stateId)
            .query(`INSERT INTO [Jobpost].[core].[City] (Name, StateId) OUTPUT INSERTED.CityId VALUES (@CityName, @StateId)`);
          if (ci2.recordset.length > 0) cityId = ci2.recordset[0].CityId;
        } catch (e) {
          console.log('City insert skipped (non-critical):', e.message);
        }
      }
    }

    // 4. Update existing Address row, or create Address + EntityAddress
    if (cityId) {
      const eaRes = await new sql.Request(transaction)
        .input('CandidateId', sql.Int, candidateId)
        .query(`
          SELECT TOP 1 ea.EntityAddressId, ea.AddressId
          FROM [Jobpost].[core].[EntityAddress] ea
          WHERE ea.EntityType = 'Candidate' AND ea.EntityId = @CandidateId
          ORDER BY ea.IsPrimary DESC, ea.CreatedOn DESC
        `);

      if (eaRes.recordset.length > 0) {
        await new sql.Request(transaction)
          .input('AddressId', sql.Int, eaRes.recordset[0].AddressId)
          .input('CityId', sql.Int, cityId)
          .query(`UPDATE [Jobpost].[core].[Address] SET CityId = @CityId WHERE AddressId = @AddressId`);
      } else {
        const addrRes = await new sql.Request(transaction)
          .input('CityId', sql.Int, cityId)
          .query(`INSERT INTO [Jobpost].[core].[Address] (CityId) OUTPUT INSERTED.AddressId VALUES (@CityId)`);
        const newAddressId = addrRes.recordset[0].AddressId;
        await new sql.Request(transaction)
          .input('CandidateId', sql.Int, candidateId)
          .input('AddressId', sql.Int, newAddressId)
          .query(`
            INSERT INTO [Jobpost].[core].[EntityAddress]
              (EntityType, EntityId, AddressId, AddressType, IsPrimary, CreatedOn)
            VALUES
              ('Candidate', @CandidateId, @AddressId, 'Current', 1, GETDATE())
          `);
      }
      console.log(`📍 Location updated: ${cityName}, ${stateCodeOrName}, ${countryIso2} -> cityId=${cityId}`);
    }
  } catch (locErr) {
    console.error('Location update error (non-critical):', locErr.message);
  }
}