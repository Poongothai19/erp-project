// File: ./erprecruitment/routes/recruitmentRoutesPublic.js

const express = require("express");
const router = express.Router();

// ✅ IMPORT ONLY PUBLIC FUNCTIONS
const { getPublicRoles } = require("../controllers/recruitmentController");

// ✅ VERIFY FUNCTION IS IMPORTED
console.log('🔍 Checking public recruitment functions:');
console.log('  ✓ getPublicRoles:', typeof getPublicRoles === 'function' ? '✅' : '❌');

// ✅ PUBLIC ROUTES - NO AUTHENTICATION REQUIRED
// Used by job portal at /api/recruitment

// Route: GET /api/recruitment/public/roles
router.get("/public/roles", (req, res, next) => {
  console.log('📍 Public roles route hit:', req.method, req.path);
  next();
}, getPublicRoles);

console.log('✅ Public recruitment routes configured');

module.exports = router;
