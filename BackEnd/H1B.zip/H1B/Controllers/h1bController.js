// H1B/controllers/h1bController.js - UPDATED FOR S3 INTEGRATION
const { sql, poolPromise } = require("../../config/db");
const AWS = require("aws-sdk");

// ============================================
// ✅ AWS S3 CONFIGURATION
// ============================================
const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION
});

const S3_BUCKET = process.env.AWS_BUCKET_NAME;

// ============================================
// ✅ HELPER: Upload to S3
// ============================================
const uploadToS3 = async (fileBuffer, originalName, fileType, submissionId = 'temp') => {
  try {
    if (!S3_BUCKET) {
      throw new Error('AWS_BUCKET_NAME not configured in environment variables');
    }

    // Sanitize filename
    const cleanFileName = originalName.replace(/[^a-zA-Z0-9.-]/g, '_');
    const timestamp = Date.now();
    const path = require('path');
    const ext = path.extname(cleanFileName).toLowerCase();
    
    // Determine S3 folder based on file type
    let s3Folder = 'h1b/';
    if (fileType === 'passport') {
      s3Folder = 'passport/';
    } else if (fileType === 'visa_copy') {
      s3Folder = 'visa_copy/';
    } else if (fileType === 'resume') {
      s3Folder = 'resume/';
    } else {
      s3Folder = 'h1b/other/';
    }
    
    // Create S3 key with folder structure
    const s3Key = `${s3Folder}${submissionId}_${timestamp}_${cleanFileName}`;

    // Determine content type
    const contentType = getContentType(ext);

    const params = {
      Bucket: S3_BUCKET,
      Key: s3Key,
      Body: fileBuffer,
      ContentType: contentType,
      ServerSideEncryption: 'AES256',
      Metadata: {
        'submission-id': submissionId,
        'file-type': fileType,
        'upload-date': new Date().toISOString(),
        'original-name': originalName
      }
    };

    const result = await s3.upload(params).promise();
    console.log(`✅ File uploaded to S3: ${s3Key}`);
    
    return {
      success: true,
      s3Key: s3Key,
      s3Url: result.Location,
      fileName: originalName,
      fileType: fileType,
      size: fileBuffer.length
    };

  } catch (error) {
    console.error('❌ Error uploading file to S3:', error.message);
    return {
      success: false,
      error: error.message
    };
  }
};

// ✅ Helper: Get content type
const getContentType = (ext) => {
  const typeMap = {
    '.pdf': 'application/pdf',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.doc': 'application/msword',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.txt': 'text/plain'
  };
  return typeMap[ext] || 'application/octet-stream';
};

// ✅ Helper: Download from S3
const downloadFromS3 = async (s3Key) => {
  try {
    if (!S3_BUCKET) {
      throw new Error('AWS_BUCKET_NAME not configured in environment variables');
    }

    const params = {
      Bucket: S3_BUCKET,
      Key: s3Key
    };

    const data = await s3.getObject(params).promise();
    console.log(`✅ File downloaded from S3: ${s3Key}`);
    
    return {
      success: true,
      data: data.Body,
      contentType: data.ContentType,
      contentLength: data.ContentLength,
      metadata: data.Metadata
    };

  } catch (error) {
    console.error('❌ Error downloading file from S3:', error.message);
    return {
      success: false,
      error: error.message
    };
  }
};

// ✅ Helper: Delete from S3
const deleteFromS3 = async (s3Key) => {
  try {
    if (!S3_BUCKET) {
      throw new Error('AWS_BUCKET_NAME not configured in environment variables');
    }

    const params = {
      Bucket: S3_BUCKET,
      Key: s3Key
    };

    await s3.deleteObject(params).promise();
    console.log(`✅ File deleted from S3: ${s3Key}`);
    
    return {
      success: true
    };

  } catch (error) {
    console.error('❌ Error deleting file from S3:', error.message);
    return {
      success: false,
      error: error.message
    };
  }
};

// ============================================
// ✅ H1B CONTROLLER
// ============================================
const h1bController = {
  // CREATE H1B SUBMISSION (PUBLIC)
  createSubmissionPublic: async (req, res) => {
    let pool;
    try {
      console.log('=== CREATE PUBLIC H1B SUBMISSION ===');
      
      const {
        // Personal Information
        prefix, first_name, middle_name, last_name, gender, date_of_birth,
        
        // Contact
        phone, email,
        
        // Passport & Nationality
        passport_number, passport_expiry_date, nationality, 
        country_of_birth, place_of_birth,
        
        // Immigration
        current_status, i94_expiration,
        
        // Employment
        position_title, job_summary, expected_salary,
        worksite_address, home_address, offsite_details,
        
        // Education
        bachelors_degree, bachelors_field, 
        masters_degree, masters_field, masters_cap_quota_eligible,
        
        // Client & Vendor
        end_client, tier1_vendor, tier2_vendor, tier3_vendor,
        
        // Filing
        filing_type, employer_name, anticipated_start_date, h4_required,
        
        // Documents (S3 Keys)
        passport_copy_s3_key, visa_copy_s3_key, resume_s3_key,
        
        // Consent
        consent
      } = req.body;

      // Validate required fields
      if (!first_name || !last_name || !email || !filing_type) {
        return res.status(400).json({
          success: false,
          message: 'Missing required fields: first_name, last_name, email, filing_type'
        });
      }

      // Generate submission ID
      const timestamp = Date.now().toString(36).toUpperCase();
      const random = Math.random().toString(36).substr(2, 5).toUpperCase();
      const submission_id = `H1B-${timestamp}${random}`;

      pool = await poolPromise;
      const request = new sql.Request(pool);
      
      // Bind parameters (using PascalCase to match new schema)
      request.input('Prefix', sql.NVarChar, prefix || '');
      request.input('FirstName', sql.NVarChar, first_name);
      request.input('MiddleName', sql.NVarChar, middle_name || '');
      request.input('LastName', sql.NVarChar, last_name);
      request.input('Gender', sql.NVarChar, gender || '');
      request.input('DateOfBirth', sql.Date, date_of_birth || null);
      request.input('Phone', sql.NVarChar, phone || '');
      request.input('Email', sql.NVarChar, email);
      request.input('PassportNumber', sql.NVarChar, passport_number || '');
      request.input('PassportExpiryDate', sql.Date, passport_expiry_date || null);
      request.input('Nationality', sql.NVarChar, nationality || '');
      request.input('CountryOfBirth', sql.NVarChar, country_of_birth || '');
      request.input('PlaceOfBirth', sql.NVarChar, place_of_birth || '');
      request.input('CurrentStatus', sql.NVarChar, current_status || '');
      request.input('I94Expiration', sql.Date, i94_expiration || null);
      request.input('PositionTitle', sql.NVarChar, position_title || '');
      request.input('JobSummary', sql.NVarChar(sql.MAX), job_summary || '');
      request.input('ExpectedSalary', sql.NVarChar, expected_salary || '');
      request.input('WorksiteAddress', sql.NVarChar(sql.MAX), worksite_address || '');
      request.input('HomeAddress', sql.NVarChar(sql.MAX), home_address || '');
      request.input('OffsiteDetails', sql.NVarChar(sql.MAX), offsite_details || '');
      request.input('BachelorsDegree', sql.NVarChar, bachelors_degree || '');
      request.input('BachelorsField', sql.NVarChar, bachelors_field || '');
      request.input('MastersDegree', sql.NVarChar, masters_degree || '');
      request.input('MastersField', sql.NVarChar, masters_field || '');
      request.input('MastersCapQuotaEligible', sql.NVarChar, masters_cap_quota_eligible || '');
      request.input('EndClient', sql.NVarChar, end_client || '');
      request.input('Tier1Vendor', sql.NVarChar, tier1_vendor || '');
      request.input('Tier2Vendor', sql.NVarChar, tier2_vendor || '');
      request.input('Tier3Vendor', sql.NVarChar, tier3_vendor || '');
      request.input('FilingType', sql.NVarChar, filing_type);
      request.input('EmployerName', sql.NVarChar, employer_name || 'Prophecy Technologies');
      request.input('AnticipatedStartDate', sql.Date, anticipated_start_date || null);
      request.input('H4Required', sql.NVarChar, h4_required || '');
      
      // ✅ Store S3 Keys from uploaded files
      request.input('PassportCopyS3Key', sql.NVarChar, passport_copy_s3_key || '');
      request.input('VisaCopyS3Key', sql.NVarChar, visa_copy_s3_key || '');
      request.input('ResumeS3Key', sql.NVarChar, resume_s3_key || '');
      
      request.input('SubmissionId', sql.NVarChar, submission_id);
      request.input('PetitionStatus', sql.NVarChar, 'pending');
      request.input('ReviewStatus', sql.NVarChar, 'not_reviewed');
      request.input('Consent', sql.Bit, consent ? 1 : 0);
      request.input('CreatedBy', sql.Int, 1); // Default to system user for public submissions
      request.input('CreatedAt', sql.DateTime, new Date());

      const result = await request.query(`
        INSERT INTO [dbo].[h1b_submissions] (
          Prefix, FirstName, MiddleName, LastName, Gender, DateOfBirth,
          Phone, Email,
          PassportNumber, PassportExpiryDate, Nationality, CountryOfBirth, PlaceOfBirth,
          CurrentStatus, I94Expiration,
          PositionTitle, JobSummary, ExpectedSalary, WorksiteAddress, HomeAddress, OffsiteDetails,
          BachelorsDegree, BachelorsField, MastersDegree, MastersField, MastersCapQuotaEligible,
          EndClient, Tier1Vendor, Tier2Vendor, Tier3Vendor,
          FilingType, EmployerName, AnticipatedStartDate, H4Required,
          PassportCopyS3Key, VisaCopyS3Key, ResumeS3Key,
          SubmissionId, PetitionStatus, ReviewStatus, Consent, CreatedBy, CreatedAt
        )
        OUTPUT INSERTED.*
        VALUES (
          @Prefix, @FirstName, @MiddleName, @LastName, @Gender, @DateOfBirth,
          @Phone, @Email,
          @PassportNumber, @PassportExpiryDate, @Nationality, @CountryOfBirth, @PlaceOfBirth,
          @CurrentStatus, @I94Expiration,
          @PositionTitle, @JobSummary, @ExpectedSalary, @WorksiteAddress, @HomeAddress, @OffsiteDetails,
          @BachelorsDegree, @BachelorsField, @MastersDegree, @MastersField, @MastersCapQuotaEligible,
          @EndClient, @Tier1Vendor, @Tier2Vendor, @Tier3Vendor,
          @FilingType, @EmployerName, @AnticipatedStartDate, @H4Required,
          @PassportCopyS3Key, @VisaCopyS3Key, @ResumeS3Key,
          @SubmissionId, @PetitionStatus, @ReviewStatus, @Consent, @CreatedBy, @CreatedAt
        )
      `);

      const newSubmission = result.recordset[0];
      console.log('✅ H1B Submission created successfully!');
      console.log('   ID:', newSubmission.Id);
      console.log('   Submission ID:', newSubmission.SubmissionId);
      console.log('   Name:', `${newSubmission.FirstName} ${newSubmission.LastName}`);
      console.log('   Email:', newSubmission.Email);
      console.log('   Passport S3 Key:', newSubmission.PassportCopyS3Key);
      console.log('   Visa S3 Key:', newSubmission.VisaCopyS3Key);
      console.log('   Resume S3 Key:', newSubmission.ResumeS3Key);

      res.status(201).json({
        success: true,
        message: 'H1B application submitted successfully',
        data: {
          id: newSubmission.Id,
          submission_id: newSubmission.SubmissionId,
          first_name: newSubmission.FirstName,
          last_name: newSubmission.LastName,
          email: newSubmission.Email,
          filing_type: newSubmission.FilingType,
          petition_status: newSubmission.PetitionStatus,
          created_at: newSubmission.CreatedAt,
          passport_s3_key: newSubmission.PassportCopyS3Key,
          visa_s3_key: newSubmission.VisaCopyS3Key,
          resume_s3_key: newSubmission.ResumeS3Key
        }
      });

    } catch (error) {
      console.error('❌ Create public submission error:', error.message);
      res.status(500).json({
        success: false,
        message: 'Error creating H1B submission',
        error: error.message
      });
    }
  },

  // GET ALL SUBMISSIONS
  getAllSubmissions: async (req, res) => {
    let pool;
    try {
      console.log('=== GET ALL H1B SUBMISSIONS ===');
      
      const { filing_type, status, search, page = 1, limit = 20 } = req.query;

      pool = await poolPromise;

      let query = 'SELECT * FROM [dbo].[h1b_submissions] WHERE IsArchived = 0';
      const request = new sql.Request(pool);

      if (filing_type) {
        query += ` AND FilingType = @filing_type`;
        request.input('filing_type', sql.NVarChar, filing_type);
      }

      if (status) {
        query += ` AND PetitionStatus = @status`;
        request.input('status', sql.NVarChar, status);
      }

      if (search) {
        query += ` AND (FirstName LIKE @search OR LastName LIKE @search OR Email LIKE @search OR PassportNumber LIKE @search OR SubmissionId LIKE @search)`;
        request.input('search', sql.NVarChar, `%${search}%`);
      }

      query += ` ORDER BY CreatedAt DESC`;

      const pageNum = parseInt(page) || 1;
      const limitNum = parseInt(limit) || 20;
      const offset = (pageNum - 1) * limitNum;

      query += ` OFFSET ${offset} ROWS FETCH NEXT ${limitNum} ROWS ONLY`;

      const result = await request.query(query);

      // Get total count
      let countQuery = 'SELECT COUNT(*) as total FROM [dbo].[h1b_submissions] WHERE IsArchived = 0';
      const countRequest = new sql.Request(pool);
      
      if (filing_type) {
        countQuery += ` AND FilingType = @filing_type`;
        countRequest.input('filing_type', sql.NVarChar, filing_type);
      }
      if (status) {
        countQuery += ` AND PetitionStatus = @status`;
        countRequest.input('status', sql.NVarChar, status);
      }
      
      const countResult = await countRequest.query(countQuery);
      const total = countResult.recordset[0].total;

      console.log(`✅ Found ${result.recordset.length} submissions`);

      res.json({
        success: true,
        data: result.recordset,
        pagination: {
          page: pageNum,
          limit: limitNum,
          total: total,
          pages: Math.ceil(total / limitNum)
        }
      });

    } catch (error) {
      console.error('❌ Get all submissions error:', error.message);
      res.status(500).json({
        success: false,
        message: 'Error fetching submissions',
        error: error.message
      });
    }
  },

  // GET SUBMISSION BY ID
  getSubmissionById: async (req, res) => {
    let pool;
    try {
      const { id } = req.params;
      console.log('=== GET H1B SUBMISSION BY ID ===', id);

      pool = await poolPromise;

      const request = new sql.Request(pool);
      request.input('id', sql.Int, id);

      const result = await request.query(`
        SELECT * FROM [dbo].[h1b_submissions] WHERE Id = @id
      `);

      if (result.recordset.length === 0) {
        return res.status(404).json({
          success: false,
          message: 'Submission not found'
        });
      }

      const submission = result.recordset[0];

      console.log('✅ Submission found:', submission.FirstName, submission.LastName);
      console.log('   Passport S3 Key:', submission.PassportCopyS3Key);
      console.log('   Visa S3 Key:', submission.VisaCopyS3Key);
      console.log('   Resume S3 Key:', submission.ResumeS3Key);

      res.json({
        success: true,
        data: submission
      });

    } catch (error) {
      console.error('❌ Get submission by ID error:', error.message);
      res.status(500).json({
        success: false,
        message: 'Error fetching submission',
        error: error.message
      });
    }
  },

  // DOWNLOAD FILE FROM S3
  downloadFile: async (req, res) => {
    try {
      const { s3Key } = req.params;
      
      if (!s3Key) {
        return res.status(400).json({
          success: false,
          message: 'S3 key is required'
        });
      }

      console.log('=== DOWNLOAD FILE FROM S3 ===', s3Key);

      const decodedS3Key = decodeURIComponent(s3Key);
      
      // Download file from S3
      const s3Result = await downloadFromS3(decodedS3Key);

      if (!s3Result.success) {
        if (s3Result.error.code === 'NoSuchKey') {
          return res.status(404).json({
            success: false,
            message: 'File not found in S3'
          });
        }
        throw new Error(s3Result.error);
      }

      // Set headers for download
      const path = require('path');
      const ext = path.extname(decodedS3Key).toLowerCase();
      const contentType = getContentType(ext);
      const fileName = decodedS3Key.split('/').pop();

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.setHeader('Content-Length', s3Result.contentLength);
      res.setHeader('Cache-Control', 'no-cache');

      // Send file
      res.send(s3Result.data);
      console.log(`✅ File sent to client: ${fileName}`);

    } catch (error) {
      console.error('❌ Download file error:', error.message);
      res.status(500).json({
        success: false,
        message: 'Error downloading file',
        error: error.message
      });
    }
  },

  // UPLOAD FILE TO S3 (for H1B form)
  uploadFile: async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: 'No file uploaded'
        });
      }

      console.log('=== UPLOAD FILE TO S3 ===');
      console.log('   Original name:', req.file.originalname);
      console.log('   File size:', req.file.size);
      console.log('   MIME type:', req.file.mimetype);

      const { fileType, submissionId = 'temp' } = req.body;
      
      if (!fileType || !['passport', 'visa_copy', 'resume'].includes(fileType)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid file type. Must be: passport, visa_copy, or resume'
        });
      }

      // Upload to S3
      const s3Upload = await uploadToS3(
        req.file.buffer,
        req.file.originalname,
        fileType,
        submissionId
      );

      if (!s3Upload.success) {
        return res.status(500).json({
          success: false,
          message: 'Failed to upload file to S3',
          error: s3Upload.error
        });
      }

      // Return file info with S3 path
      res.status(200).json({
        success: true,
        message: 'File uploaded successfully to S3',
        file: {
          originalName: req.file.originalname,
          fileName: req.file.originalname,
          size: req.file.size,
          s3Key: s3Upload.s3Key,
          s3Url: s3Upload.s3Url,
          fileType: fileType,
          mimeType: req.file.mimetype,
          uploadedAt: new Date()
        }
      });

    } catch (error) {
      console.error('❌ Upload file error:', error.message);
      res.status(500).json({
        success: false,
        message: `Upload failed: ${error.message}`
      });
    }
  },

  // DELETE FILE FROM S3
  deleteFile: async (req, res) => {
    try {
      const { s3Key } = req.params;
      
      if (!s3Key) {
        return res.status(400).json({
          success: false,
          message: 'S3 key is required'
        });
      }

      console.log('=== DELETE FILE FROM S3 ===', s3Key);

      const decodedS3Key = decodeURIComponent(s3Key);
      
      // Delete file from S3
      const s3Result = await deleteFromS3(decodedS3Key);

      if (!s3Result.success) {
        return res.status(500).json({
          success: false,
          message: 'Failed to delete file from S3',
          error: s3Result.error
        });
      }

      res.status(200).json({
        success: true,
        message: 'File deleted successfully from S3'
      });

    } catch (error) {
      console.error('❌ Delete file error:', error.message);
      res.status(500).json({
        success: false,
        message: `Delete failed: ${error.message}`
      });
    }
  },

  // UPDATE SUBMISSION STATUS
  updateSubmission: async (req, res) => {
    let pool;
    try {
      const { id } = req.params;
      const { petition_status, review_status, notes } = req.body;

      console.log('=== UPDATE H1B SUBMISSION ===', id);

      if (!petition_status && !review_status && !notes) {
        return res.status(400).json({
          success: false,
          message: 'No fields to update'
        });
      }

      pool = await poolPromise;

      // Build update query dynamically
      let updateFields = [];
      const request = new sql.Request(pool);
      request.input('id', sql.Int, id);

      if (petition_status) {
        if (!['pending', 'approved', 'rejected'].includes(petition_status)) {
          return res.status(400).json({
            success: false,
            message: 'Invalid petition status. Must be: pending, approved, or rejected'
          });
        }
        updateFields.push('PetitionStatus = @petition_status');
        request.input('petition_status', sql.NVarChar, petition_status);
      }

      if (review_status) {
        updateFields.push('ReviewStatus = @review_status');
        request.input('review_status', sql.NVarChar, review_status);
      }

      if (notes) {
        updateFields.push('Notes = @notes');
        request.input('notes', sql.NVarChar, notes);
      }

      // Always update the modified date
      updateFields.push('UpdatedAt = @updated_at');
      request.input('updated_at', sql.DateTime, new Date());

      const updateQuery = `
        UPDATE [dbo].[h1b_submissions] 
        SET ${updateFields.join(', ')}
        OUTPUT INSERTED.*
        WHERE Id = @id
      `;

      const result = await request.query(updateQuery);

      if (result.rowsAffected[0] === 0) {
        return res.status(404).json({
          success: false,
          message: 'Submission not found'
        });
      }

      const updatedSubmission = result.recordset[0];
      console.log('✅ Submission updated successfully');

      res.json({
        success: true,
        message: 'Submission updated successfully',
        data: updatedSubmission
      });

    } catch (error) {
      console.error('❌ Update submission error:', error.message);
      res.status(500).json({
        success: false,
        message: 'Error updating submission',
        error: error.message
      });
    }
  },

  // GET STATISTICS
  getStatistics: async (req, res) => {
    let pool;
    try {
      console.log('=== GET H1B STATISTICS ===');

      pool = await poolPromise;

      // Total submissions
      const totalResult = await pool.request().query(`
        SELECT COUNT(*) as total FROM [dbo].[h1b_submissions] WHERE IsArchived = 0
      `);

      // By status
      const statusResult = await pool.request().query(`
        SELECT PetitionStatus, COUNT(*) as count 
        FROM [dbo].[h1b_submissions] 
        WHERE IsArchived = 0
        GROUP BY PetitionStatus
      `);

      // By filing type
      const filingTypeResult = await pool.request().query(`
        SELECT FilingType, COUNT(*) as count 
        FROM [dbo].[h1b_submissions] 
        WHERE IsArchived = 0
        GROUP BY FilingType
      `);

      // Recent submissions
      const recentResult = await pool.request().query(`
        SELECT TOP 10 Id, FirstName, LastName, Email, FilingType, PetitionStatus, CreatedAt
        FROM [dbo].[h1b_submissions] 
        WHERE IsArchived = 0
        ORDER BY CreatedAt DESC
      `);

      console.log('✅ Statistics retrieved');

      res.json({
        success: true,
        data: {
          total: totalResult.recordset[0].total,
          byStatus: statusResult.recordset,
          byFilingType: filingTypeResult.recordset,
          recentSubmissions: recentResult.recordset
        }
      });

    } catch (error) {
      console.error('❌ Get statistics error:', error.message);
      res.status(500).json({
        success: false,
        message: 'Error fetching statistics',
        error: error.message
      });
    }
  },

  // GET S3 FILE PREVIEW (returns file info without downloading)
  getFileInfo: async (req, res) => {
    try {
      const { s3Key } = req.params;
      
      if (!s3Key) {
        return res.status(400).json({
          success: false,
          message: 'S3 key is required'
        });
      }

      console.log('=== GET S3 FILE INFO ===', s3Key);

      const decodedS3Key = decodeURIComponent(s3Key);

      // Get file metadata from S3
      const params = {
        Bucket: S3_BUCKET,
        Key: decodedS3Key
      };

      const data = await s3.headObject(params).promise();
      
      const path = require('path');
      const fileName = decodedS3Key.split('/').pop();
      const ext = path.extname(fileName).toLowerCase();
      const fileType = getContentType(ext);

      res.json({
        success: true,
        data: {
          fileName: fileName,
          fileSize: data.ContentLength,
          contentType: data.ContentType || fileType,
          lastModified: data.LastModified,
          metadata: data.Metadata,
          s3Key: decodedS3Key
        }
      });

    } catch (error) {
      console.error('❌ Get file info error:', error.message);
      
      if (error.code === 'NotFound') {
        return res.status(404).json({
          success: false,
          message: 'File not found in S3'
        });
      }
      
      res.status(500).json({
        success: false,
        message: 'Error fetching file info',
        error: error.message
      });
    }
  },

  // Helper to get pool promise
  getPoolPromise: () => poolPromise
};

module.exports = h1bController;